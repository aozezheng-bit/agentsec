"""Reviewed deterministic combination-risk Capability Rule Pack v0.1.0."""

# ruff: noqa: E501

from __future__ import annotations

from collections.abc import Callable, Iterable

from agentsec.capability_rules.base import (
    CapabilityCorrelation,
    CapabilityRule,
    CapabilityRuleCandidate,
    CapabilityRuleContext,
    CapabilityRuleEvaluation,
    CapabilityRuleLanguage,
    CapabilityRuleMetadata,
    CapabilityRuleText,
)
from agentsec.domain import FindingCategory, ImpactLevel
from agentsec.manifests import (
    ManifestAuthenticationKind,
    ManifestControlKind,
    ManifestControlState,
    ManifestEnvironmentKind,
    ManifestPermission,
    ManifestPermissionAction,
    ManifestPermissionEffect,
    ManifestRelationKind,
    ManifestRelationState,
    ManifestSourceReference,
    ManifestToolAvailability,
    ManifestUnknownDimension,
)
from agentsec.risk import ImpactDimension, ImpactRating

BUILTIN_CAPABILITY_RULE_IDS = (
    "CAP-APPROVAL-001",
    "CAP-CHAIN-001",
    "CAP-COVERAGE-001",
    "CAP-DELEGATE-001",
    "CAP-EXTERNAL-001",
    "CAP-PERSIST-001",
)

_STATIC_LIMITATION = (
    "This is a static declaration finding; runtime reachability, successful execution, "
    "and actual authorization are not verified.",
)
_AGENT_WIDE_LIMITATION = (
    "The correlated facts are Agent-wide declarations; capability reachability between "
    "them is not verified.",
    *_STATIC_LIMITATION,
)
_INCOMPLETE_LIMITATION = (
    "Analysis Coverage or a relevant Manifest dimension is incomplete; the visible fact "
    "does not prove exploitability and the result is not exhaustive.",
)


def builtin_capability_rules() -> tuple[CapabilityRule, ...]:
    """Return the complete reviewed Capability Rule inventory."""

    rules: tuple[CapabilityRule, ...] = (
        _approval_rule(),
        _chain_rule(),
        _coverage_rule(),
        _delegation_rule(),
        _external_rule(),
        _persistence_rule(),
    )
    ordered = tuple(sorted(rules, key=lambda rule: rule.metadata.rule_id))
    if tuple(rule.metadata.rule_id for rule in ordered) != BUILTIN_CAPABILITY_RULE_IDS:
        raise RuntimeError("Built-in Capability Rule identity is invalid.")
    return ordered


type _Evaluator = Callable[
    ["_CapabilityRule", CapabilityRuleContext], CapabilityRuleEvaluation
]


class _CapabilityRule:
    def __init__(self, metadata: CapabilityRuleMetadata, evaluator: _Evaluator) -> None:
        self.metadata = metadata
        self._evaluator = evaluator

    def evaluate(self, context: CapabilityRuleContext) -> CapabilityRuleEvaluation:
        return self._evaluator(self, context)

    def _candidate(
        self,
        *,
        correlation: CapabilityCorrelation,
        related_ids: Iterable[str],
        references: Iterable[ManifestSourceReference],
        likelihood_basis: tuple[str, ...],
        limitations: tuple[str, ...],
    ) -> CapabilityRuleCandidate:
        return CapabilityRuleCandidate(
            correlation=correlation,
            related_ids=tuple(sorted(set(related_ids))),
            evidence=tuple(sorted(set(references), key=lambda item: item.sort_key())),
            likelihood_basis=likelihood_basis,
            limitations=limitations,
        )


def _approval_rule() -> CapabilityRule:
    return _CapabilityRule(
        CapabilityRuleMetadata(
            rule_id="CAP-APPROVAL-001",
            category=FindingCategory.HUMAN_APPROVAL,
            texts=_texts(
                "State-changing capability lacks an effective human approval control",
                "状态变更能力缺少有效人工审批控制",
                "A write, execute, deploy, publish, or admin capability is enabled or not explicitly disabled while the correlated target has no prompt or deny approval control.",
                "能力已启用或未明确禁用，但关联目标缺少 prompt 或 deny 人工审批控制。",
                "Require prompt or deny approval for state-changing capabilities and review inherited parent controls.",
                "为状态变更能力配置 prompt 或 deny 审批，并复核父级工具继承的控制。",
            ),
            impact_ratings=_impact(
                (
                    ImpactDimension.INTEGRITY,
                    ImpactLevel.VERY_HIGH,
                    "A state-changing capability without confirmation can modify code, configuration, or business state.",
                ),
                (
                    ImpactDimension.BUSINESS_COMPLIANCE,
                    ImpactLevel.HIGH,
                    "Unreviewed changes can bypass change-control, audit, or compliance decisions.",
                ),
            ),
        ),
        evaluator=_approval_evaluate,
    )


def _chain_rule() -> CapabilityRule:
    return _CapabilityRule(
        CapabilityRuleMetadata(
            rule_id="CAP-CHAIN-001",
            category=FindingCategory.SECRET_ACCESS,
            texts=_texts(
                "Execution, secret access, and external network form a potential chain",
                "代码执行、Secret 访问与外部网络形成潜在链路",
                "The same target family or Agent declaration combines execute, secret access, and external network permissions.",
                "同一目标族或 Agent 声明同时具备 execute、secret_access 和 external network 权限。",
                "Separate execution, secret access, and external network capabilities; require least privilege and review each trust boundary.",
                "拆分执行、Secret 访问和外部网络能力，遵循最小权限并分别复核信任边界。",
            ),
            impact_ratings=_impact(
                (
                    ImpactDimension.CONFIDENTIALITY,
                    ImpactLevel.VERY_HIGH,
                    "The combination can expose credentials or protected data to an external destination.",
                ),
                (
                    ImpactDimension.INTEGRITY,
                    ImpactLevel.VERY_HIGH,
                    "Execution can transform accessed secrets or data into downstream state changes.",
                ),
                (
                    ImpactDimension.DOWNSTREAM_BLAST_RADIUS,
                    ImpactLevel.HIGH,
                    "An external identity or service can extend the impact beyond the local Agent.",
                ),
            ),
        ),
        evaluator=_chain_evaluate,
    )


def _coverage_rule() -> CapabilityRule:
    return _CapabilityRule(
        CapabilityRuleMetadata(
            rule_id="CAP-COVERAGE-001",
            category=FindingCategory.SCAN_COVERAGE,
            texts=_texts(
                "High-impact capability is visible under incomplete analysis",
                "分析不完整时发现高影响能力",
                "A high-impact permission or relationship is visible while Coverage or a relevant Manifest dimension remains incomplete or Unknown.",
                "发现高影响权限或关系，但 Coverage 或相关 Manifest 维度仍不完整或 Unknown。",
                "Resolve skipped assets and Unknown dimensions before treating the capability assessment as exhaustive.",
                "先解决跳过的资产和 Unknown 维度，再将能力评估视为完整结果。",
            ),
            impact_ratings=_impact(
                (
                    ImpactDimension.INTEGRITY,
                    ImpactLevel.HIGH,
                    "Unknown controls or capabilities can hide a state-changing path.",
                ),
                (
                    ImpactDimension.DOWNSTREAM_BLAST_RADIUS,
                    ImpactLevel.VERY_HIGH,
                    "Incomplete scope can omit tools, identities, or relations outside the inspected inventory.",
                ),
            ),
        ),
        evaluator=_coverage_evaluate,
    )


def _delegation_rule() -> CapabilityRule:
    return _CapabilityRule(
        CapabilityRuleMetadata(
            rule_id="CAP-DELEGATE-001",
            category=FindingCategory.PRIVILEGED_ACCESS,
            texts=_texts(
                "Delegation reaches a powerful capability without approval evidence",
                "委派可触达高权限能力但缺少审批证据",
                "An explicit delegates_to relationship coexists with a powerful capability and no prompt or deny approval evidence.",
                "存在 delegates_to 关系，同时存在高权限能力且没有 prompt 或 deny 审批证据。",
                "Require explicit approval at the delegation boundary and independently analyze the delegated Agent before granting power.",
                "在委派边界要求明确审批，并在授予高权限前独立分析被委派 Agent。",
            ),
            impact_ratings=_impact(
                (
                    ImpactDimension.DOWNSTREAM_BLAST_RADIUS,
                    ImpactLevel.VERY_HIGH,
                    "Delegation can extend a powerful capability to another Agent or execution context.",
                ),
                (
                    ImpactDimension.INTEGRITY,
                    ImpactLevel.VERY_HIGH,
                    "A delegated powerful action can alter code, configuration, or production state.",
                ),
            ),
        ),
        evaluator=_delegation_evaluate,
    )


def _external_rule() -> CapabilityRule:
    return _CapabilityRule(
        CapabilityRuleMetadata(
            rule_id="CAP-EXTERNAL-001",
            category=FindingCategory.NETWORK_ACCESS,
            texts=_texts(
                "Required enabled external MCP uses a credentialed identity",
                "必选启用的外部 MCP 使用凭证化身份",
                "An enabled and required external MCP server has OAuth, ChatGPT, or environment-backed authentication.",
                "外部 MCP Server 已启用且必选，同时使用 OAuth、ChatGPT 或环境凭证认证。",
                "Make external integrations optional where possible, scope credentials, pin destinations, and retain human approval for side effects.",
                "尽量将外部集成设为可选，限制凭证范围、固定目标并保留副作用人工审批。",
            ),
            impact_ratings=_impact(
                (
                    ImpactDimension.CONFIDENTIALITY,
                    ImpactLevel.VERY_HIGH,
                    "A required credentialed external integration can access protected data across a trust boundary.",
                ),
                (
                    ImpactDimension.DOWNSTREAM_BLAST_RADIUS,
                    ImpactLevel.HIGH,
                    "The external service and identity can affect systems outside the Agent project.",
                ),
            ),
        ),
        evaluator=_external_evaluate,
    )


def _persistence_rule() -> CapabilityRule:
    return _CapabilityRule(
        CapabilityRuleMetadata(
            rule_id="CAP-PERSIST-001",
            category=FindingCategory.PERSISTENT_MEMORY,
            texts=_texts(
                "Persistent memory is combined with a sensitive capability",
                "持久化记忆与敏感能力组合出现",
                "A persists_memory relationship coexists with secret access, external network, write, or admin capability.",
                "存在 persists_memory 关系，同时存在 secret_access、外部网络、write 或 admin 能力。",
                "Limit retained data, set expiration and deletion controls, and exclude secrets and untrusted instructions from persistent memory.",
                "限制保留数据，设置过期和删除控制，并禁止将 Secret 与不可信指令写入持久化记忆。",
            ),
            impact_ratings=_impact(
                (
                    ImpactDimension.CONFIDENTIALITY,
                    ImpactLevel.VERY_HIGH,
                    "Persistent memory can extend the lifetime and exposure of sensitive data or credentials.",
                ),
                (
                    ImpactDimension.INTEGRITY,
                    ImpactLevel.HIGH,
                    "Persisted untrusted instructions can influence future Agent tasks.",
                ),
            ),
        ),
        evaluator=_persistence_evaluate,
    )


def _texts(
    en_title: str,
    zh_title: str,
    en_description: str,
    zh_description: str,
    en_recommendation: str,
    zh_recommendation: str,
) -> tuple[CapabilityRuleText, ...]:
    return (
        CapabilityRuleText(
            language=CapabilityRuleLanguage.EN,
            title=en_title,
            description=en_description,
            recommendations=(en_recommendation,),
        ),
        CapabilityRuleText(
            language=CapabilityRuleLanguage.ZH,
            title=zh_title,
            description=zh_description,
            recommendations=(zh_recommendation,),
        ),
    )


def _impact(
    *items: tuple[ImpactDimension, ImpactLevel, str],
) -> tuple[ImpactRating, ...]:
    return tuple(
        sorted(
            (
                ImpactRating(dimension=dimension, level=level, rationale=rationale)
                for dimension, level, rationale in items
            ),
            key=lambda item: item.dimension.value,
        )
    )


def _permissions_for_actions(
    context: CapabilityRuleContext, actions: set[ManifestPermissionAction]
) -> tuple[ManifestPermission, ...]:
    return tuple(
        permission
        for target in sorted(context.permissions_by_target)
        for permission in context.permissions_by_target[target]
        if permission.action in actions
        and permission.effect is not ManifestPermissionEffect.DENY
        and not context.target_is_disabled(permission.target or "")
    )


def _approval_status(
    context: CapabilityRuleContext, target: str
) -> ManifestControlState | None:
    controls = context.effective_controls(target)
    states = [
        control.state
        for control in controls
        if control.kind is ManifestControlKind.HUMAN_APPROVAL
    ]
    states.extend(
        {
            ManifestPermissionEffect.ALLOW: ManifestControlState.ALLOW,
            ManifestPermissionEffect.PROMPT: ManifestControlState.PROMPT,
            ManifestPermissionEffect.DENY: ManifestControlState.DENY,
        }.get(permission.effect, ManifestControlState.UNKNOWN)
        for permission in context.permissions_by_target.get(target, ())
    )
    if ManifestControlState.DENY in states:
        return ManifestControlState.DENY
    if ManifestControlState.PROMPT in states:
        return ManifestControlState.PROMPT
    if ManifestControlState.ALLOW in states:
        return ManifestControlState.ALLOW
    return ManifestControlState.UNKNOWN if controls else None


def _target_references(
    context: CapabilityRuleContext, target: str, *, include_parent: bool = True
) -> tuple[ManifestSourceReference, ...]:
    references: list[ManifestSourceReference] = []
    for permission in context.permissions_by_target.get(target, ()):
        references.extend(permission.sources)
    for control in context.effective_controls(target):
        references.extend(control.sources)
    for identity in context.identities_by_tool.get(target, ()):
        references.extend(identity.sources)
    tool = context.tools_by_id.get(target)
    if tool is not None:
        references.extend(tool.sources)
        if include_parent and tool.parent_tool_id is not None:
            references.extend(
                _target_references(context, tool.parent_tool_id, include_parent=False)
            )
    return tuple(sorted(set(references), key=lambda item: item.sort_key()))


def _same_target_candidates(
    context: CapabilityRuleContext,
    *,
    actions: set[ManifestPermissionAction],
    rule: _CapabilityRule,
    require_approval: bool = False,
) -> tuple[CapabilityRuleCandidate, ...]:
    candidates = []
    for target in sorted(context.permissions_by_target):
        permissions = tuple(
            permission
            for permission in context.permissions_by_target[target]
            if permission.action in actions
            and permission.effect is not ManifestPermissionEffect.DENY
            and not context.target_is_disabled(target)
        )
        present = {permission.action for permission in permissions}
        if present != actions:
            continue
        if require_approval and _approval_status(context, target) in {
            ManifestControlState.PROMPT,
            ManifestControlState.DENY,
        }:
            continue
        candidates.append(
            rule._candidate(
                correlation=CapabilityCorrelation.SAME_TARGET,
                related_ids=(target,),
                references=_target_references(context, target),
                likelihood_basis=(
                    "All required static permissions are correlated to one Manifest target.",
                    *_STATIC_LIMITATION,
                ),
                limitations=_STATIC_LIMITATION,
            )
        )
    return tuple(candidates)


def _parent_child_candidates(
    context: CapabilityRuleContext,
    *,
    actions: set[ManifestPermissionAction],
    rule: _CapabilityRule,
) -> tuple[CapabilityRuleCandidate, ...]:
    families: dict[str, list[ManifestPermission]] = {}
    for permission in _permissions_for_actions(context, actions):
        target = permission.target
        if target is None:
            continue
        family = context.tool_family(target)
        if family is None:
            continue
        families.setdefault(family, []).append(permission)

    candidates: list[CapabilityRuleCandidate] = []
    for family in sorted(families):
        permissions = tuple(families[family])
        if {permission.action for permission in permissions} != actions:
            continue
        targets = tuple(
            sorted(
                {permission.target for permission in permissions if permission.target}
            )
        )
        if len(targets) < 2:
            continue
        references = tuple(
            source for permission in permissions for source in permission.sources
        )
        candidates.append(
            rule._candidate(
                correlation=CapabilityCorrelation.PARENT_CHILD,
                related_ids=targets,
                references=references,
                likelihood_basis=(
                    "All required static permissions are correlated within one parent-child tool family.",
                    *_STATIC_LIMITATION,
                ),
                limitations=_STATIC_LIMITATION,
            )
        )
    return tuple(candidates)


def _chain_evaluate(
    self: _CapabilityRule, context: CapabilityRuleContext
) -> CapabilityRuleEvaluation:
    actions = {
        ManifestPermissionAction.EXECUTE,
        ManifestPermissionAction.SECRET_ACCESS,
        ManifestPermissionAction.NETWORK,
    }
    candidates = list(_same_target_candidates(context, actions=actions, rule=self))
    if not candidates:
        candidates.extend(_parent_child_candidates(context, actions=actions, rule=self))
    if not candidates:
        present = _permissions_for_actions(context, actions)
        if {permission.action for permission in present} == actions:
            references = tuple(
                source for permission in present for source in permission.sources
            )
            candidates.append(
                self._candidate(
                    correlation=CapabilityCorrelation.AGENT_WIDE,
                    related_ids=tuple(
                        permission.permission_id for permission in present
                    ),
                    references=references,
                    likelihood_basis=(
                        "All required static permissions are visible in the Agent Manifest.",
                        "The declarations are not proven to share a reachable target.",
                    ),
                    limitations=_AGENT_WIDE_LIMITATION,
                )
            )
    return CapabilityRuleEvaluation(
        candidates=tuple(sorted(candidates, key=lambda item: item.sort_key()))
    )


def _approval_evaluate(
    self: _CapabilityRule, context: CapabilityRuleContext
) -> CapabilityRuleEvaluation:
    actions = {
        ManifestPermissionAction.WRITE,
        ManifestPermissionAction.EXECUTE,
        ManifestPermissionAction.DEPLOY,
        ManifestPermissionAction.PUBLISH,
        ManifestPermissionAction.ADMIN,
    }
    candidates = []
    for target in sorted(context.permissions_by_target):
        permissions = tuple(
            permission
            for permission in context.permissions_by_target[target]
            if permission.action in actions
            and permission.effect is not ManifestPermissionEffect.DENY
            and not context.target_is_disabled(target)
        )
        if not permissions:
            continue
        if _approval_status(context, target) in {
            ManifestControlState.PROMPT,
            ManifestControlState.DENY,
        }:
            continue
        candidates.append(
            self._candidate(
                correlation=CapabilityCorrelation.SAME_TARGET,
                related_ids=(target,),
                references=_target_references(context, target),
                likelihood_basis=(
                    "A state-changing static permission is correlated to a target without prompt or deny approval.",
                    *_STATIC_LIMITATION,
                ),
                limitations=_STATIC_LIMITATION,
            )
        )
    return CapabilityRuleEvaluation(
        candidates=tuple(sorted(candidates, key=lambda item: item.sort_key()))
    )


def _persistence_evaluate(
    self: _CapabilityRule, context: CapabilityRuleContext
) -> CapabilityRuleEvaluation:
    relations = context.relations_by_kind.get(ManifestRelationKind.PERSISTS_MEMORY, ())
    sensitive = _permissions_for_actions(
        context,
        {
            ManifestPermissionAction.SECRET_ACCESS,
            ManifestPermissionAction.NETWORK,
            ManifestPermissionAction.WRITE,
            ManifestPermissionAction.ADMIN,
        },
    )
    if not relations or not sensitive:
        return CapabilityRuleEvaluation()
    references = tuple(
        source for relation in relations for source in relation.sources
    ) + tuple(source for permission in sensitive for source in permission.sources)
    return CapabilityRuleEvaluation(
        candidates=(
            self._candidate(
                correlation=CapabilityCorrelation.AGENT_WIDE,
                related_ids=(
                    *(relation.relation_id for relation in relations),
                    *(permission.permission_id for permission in sensitive),
                ),
                references=references,
                likelihood_basis=(
                    "A persistent-memory relation and sensitive permission are both declared.",
                    "The static model does not prove that the relation will carry the permission's data.",
                ),
                limitations=_AGENT_WIDE_LIMITATION,
            ),
        )
    )


def _delegation_evaluate(
    self: _CapabilityRule, context: CapabilityRuleContext
) -> CapabilityRuleEvaluation:
    relations = tuple(
        relation
        for relation in context.relations_by_kind.get(
            ManifestRelationKind.DELEGATES_TO, ()
        )
        if relation.state is ManifestRelationState.DECLARED
    )
    powerful = _permissions_for_actions(
        context,
        {
            ManifestPermissionAction.EXECUTE,
            ManifestPermissionAction.ADMIN,
            ManifestPermissionAction.DEPLOY,
            ManifestPermissionAction.PUBLISH,
            ManifestPermissionAction.PERSIST,
        },
    )
    if not relations or not powerful:
        return CapabilityRuleEvaluation()
    unapproved = tuple(
        permission
        for permission in powerful
        if _approval_status(context, permission.target or "")
        not in {ManifestControlState.PROMPT, ManifestControlState.DENY}
    )
    if not unapproved:
        return CapabilityRuleEvaluation()
    references = tuple(
        source for relation in relations for source in relation.sources
    ) + tuple(source for permission in unapproved for source in permission.sources)
    return CapabilityRuleEvaluation(
        candidates=(
            self._candidate(
                correlation=CapabilityCorrelation.AGENT_WIDE,
                related_ids=(
                    *(relation.relation_id for relation in relations),
                    *(permission.permission_id for permission in unapproved),
                ),
                references=references,
                likelihood_basis=(
                    "An explicit delegation relation and powerful permission coexist without prompt or deny evidence.",
                    "The delegated Agent's independent capability manifest is unavailable.",
                ),
                limitations=_AGENT_WIDE_LIMITATION,
            ),
        )
    )


def _external_evaluate(
    self: _CapabilityRule, context: CapabilityRuleContext
) -> CapabilityRuleEvaluation:
    candidates = []
    for target, identities in context.identities_by_tool.items():
        if context.target_is_disabled(target):
            continue
        tool = context.tools_by_id.get(target)
        if (
            tool is None
            or tool.kind.value != "mcp_server"
            or tool.availability is not ManifestToolAvailability.ENABLED
        ):
            continue
        if not any(
            identity.environment is ManifestEnvironmentKind.EXTERNAL
            for identity in identities
        ):
            continue
        if not any(
            identity.authentication
            in {
                ManifestAuthenticationKind.ENVIRONMENT,
                ManifestAuthenticationKind.OAUTH,
                ManifestAuthenticationKind.CHATGPT,
            }
            for identity in identities
        ):
            continue
        controls = context.effective_controls(target)
        if not any(
            control.kind is ManifestControlKind.REQUIRED
            and control.state is ManifestControlState.REQUIRED
            for control in controls
        ):
            continue
        candidates.append(
            self._candidate(
                correlation=CapabilityCorrelation.SAME_TARGET,
                related_ids=(target,),
                references=_target_references(context, target),
                likelihood_basis=(
                    "The MCP target is statically external, enabled, required, and credentialed.",
                    *_STATIC_LIMITATION,
                ),
                limitations=_STATIC_LIMITATION,
            )
        )
    return CapabilityRuleEvaluation(
        candidates=tuple(sorted(candidates, key=lambda item: item.sort_key()))
    )


def _coverage_evaluate(
    self: _CapabilityRule, context: CapabilityRuleContext
) -> CapabilityRuleEvaluation:
    candidates = []
    high_impact = {
        ManifestPermissionAction.EXECUTE,
        ManifestPermissionAction.NETWORK,
        ManifestPermissionAction.SECRET_ACCESS,
        ManifestPermissionAction.ADMIN,
        ManifestPermissionAction.DEPLOY,
        ManifestPermissionAction.PUBLISH,
        ManifestPermissionAction.PERSIST,
    }
    for target in sorted(context.permissions_by_target):
        permissions = tuple(
            permission
            for permission in context.permissions_by_target[target]
            if permission.action in high_impact
        )
        if not permissions:
            continue
        relevant_unknowns = context.relevant_unknowns(target, permissions)
        if context.manifest.coverage.complete and not relevant_unknowns:
            continue
        references = tuple(
            source for permission in permissions for source in permission.sources
        ) + tuple(source for unknown in relevant_unknowns for source in unknown.sources)
        candidates.append(
            self._candidate(
                correlation=CapabilityCorrelation.INCOMPLETE_COVERAGE,
                related_ids=(target,),
                references=references,
                likelihood_basis=(
                    "A high-impact permission is visible while Coverage or a relevant Manifest dimension is incomplete.",
                ),
                limitations=_INCOMPLETE_LIMITATION,
            )
        )
    for relation_kind in (
        ManifestRelationKind.PERSISTS_MEMORY,
        ManifestRelationKind.DELEGATES_TO,
    ):
        for relation in context.relations_by_kind.get(relation_kind, ()):
            relationship_unknowns = context.unknowns_by_dimension.get(
                ManifestUnknownDimension.RELATIONSHIPS, ()
            )
            if context.manifest.coverage.complete and not relationship_unknowns:
                continue
            candidates.append(
                self._candidate(
                    correlation=CapabilityCorrelation.INCOMPLETE_COVERAGE,
                    related_ids=(relation.relation_id,),
                    references=relation.sources,
                    likelihood_basis=(
                        "A high-impact relationship is visible while Framework Coverage is incomplete.",
                    ),
                    limitations=_INCOMPLETE_LIMITATION,
                )
            )
    return CapabilityRuleEvaluation(
        candidates=tuple(sorted(candidates, key=lambda item: item.sort_key()))
    )
