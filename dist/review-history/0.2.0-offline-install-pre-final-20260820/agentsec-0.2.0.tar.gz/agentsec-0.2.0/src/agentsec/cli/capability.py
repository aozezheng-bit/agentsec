"""CLI delivery for deterministic Capability assessment, Diff, and Rule inventory."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated

import typer

from agentsec.application import (
    AgentAnalysisError,
    AgentAnalysisRequest,
    CapabilityAssessmentEngine,
    CapabilityAssessmentError,
    ManifestCapabilityDiffEngine,
)
from agentsec.artifacts import (
    AgentManifestFileReader,
    AgentManifestReadError,
    ReportArtifactKind,
    ReportArtifactWriter,
)
from agentsec.capability_rules import (
    CapabilityRuleLanguage,
    builtin_capability_rules,
)
from agentsec.cli.exit_codes import (
    ExitCode,
    exit_code_for_capability_assessment,
    exit_code_for_capability_diff,
)
from agentsec.cli.manifest import (
    AgentIdOption,
    CapabilityFormatOption,
    CapabilityLanguageOption,
    CodexHomeOption,
    ManifestProjectArgument,
    ReportForceOption,
    ReportOutputOption,
    UserHomeOption,
    WorkingDirectoryOption,
    _emit_or_write,
    _require_output_for_force,
)
from agentsec.config import OutputFormat
from agentsec.manifests import CapabilityDiffError
from agentsec.reporting import (
    CapabilityAssessmentJsonRenderer,
    CapabilityAssessmentTextRenderer,
    CapabilityDiffJsonRenderer,
    CapabilityDiffTextRenderer,
)
from agentsec.versioning import CAPABILITY_RULE_PACK_VERSION

BeforeManifestOption = Annotated[
    Path,
    typer.Option(
        "--before",
        help="Validated before-state Agent Manifest JSON file.",
    ),
]
AfterManifestOption = Annotated[
    Path,
    typer.Option(
        "--after",
        help="Validated after-state Agent Manifest JSON file.",
    ),
]


def register_capability_commands(
    application: typer.Typer,
    assessment_engine: CapabilityAssessmentEngine,
    diff_engine: ManifestCapabilityDiffEngine,
    manifest_reader: AgentManifestFileReader,
    writer: ReportArtifactWriter,
    *,
    assessment_json_renderer: CapabilityAssessmentJsonRenderer | None = None,
    diff_json_renderer: CapabilityDiffJsonRenderer | None = None,
) -> None:
    """Register `agentsec capability assess|diff|rules list`."""

    capability_application = typer.Typer(
        help=(
            "Assess static Agent capabilities and drift; runtime reachability is "
            "not verified."
        ),
        add_completion=False,
        no_args_is_help=True,
        rich_markup_mode="rich",
        context_settings={"help_option_names": ["-h", "--help"]},
    )
    effective_assessment_json = (
        assessment_json_renderer or CapabilityAssessmentJsonRenderer()
    )
    effective_diff_json = diff_json_renderer or CapabilityDiffJsonRenderer()

    @capability_application.command("assess")
    def assess_command(
        project_root: ManifestProjectArgument = Path("."),
        working_directory: WorkingDirectoryOption = None,
        user_home: UserHomeOption = None,
        codex_home: CodexHomeOption = None,
        agent_id: AgentIdOption = None,
        output_format: CapabilityFormatOption = OutputFormat.TEXT,
        language: CapabilityLanguageOption = CapabilityRuleLanguage.EN,
        output_path: ReportOutputOption = None,
        force: ReportForceOption = False,
    ) -> None:
        """Run report-only deterministic Rules over the final static Manifest."""

        _require_output_for_force(output_path, force)
        request = AgentAnalysisRequest(
            project_root=project_root,
            working_directory=working_directory,
            user_home=user_home,
            codex_home=codex_home,
            agent_id=agent_id,
        )
        try:
            result = assessment_engine.assess(request)
        except (AgentAnalysisError, CapabilityAssessmentError) as error:
            typer.echo(f"Capability assessment failed: {error}", err=True)
            raise typer.Exit(code=ExitCode.REQUIRED_ANALYSIS_FAILED) from error
        except Exception as error:
            typer.echo("Capability assessment failed safely.", err=True)
            raise typer.Exit(code=ExitCode.REQUIRED_ANALYSIS_FAILED) from error

        rendered = (
            effective_assessment_json.render(result)
            if output_format is OutputFormat.JSON
            else CapabilityAssessmentTextRenderer(language=language).render(result)
        )
        _emit_or_write(
            rendered,
            output_path=output_path,
            force=force,
            output_format=output_format,
            kind=ReportArtifactKind.CAPABILITY_ASSESSMENT,
            writer=writer,
        )
        exit_code = exit_code_for_capability_assessment(result)
        if exit_code is not ExitCode.SUCCESS:
            raise typer.Exit(code=exit_code)

    @capability_application.command("diff")
    def diff_command(
        before_path: BeforeManifestOption,
        after_path: AfterManifestOption,
        output_format: CapabilityFormatOption = OutputFormat.TEXT,
        language: CapabilityLanguageOption = CapabilityRuleLanguage.EN,
        output_path: ReportOutputOption = None,
        force: ReportForceOption = False,
    ) -> None:
        """Compare two validated Manifests without exposing raw before/after values."""

        _require_output_for_force(output_path, force)
        try:
            before = manifest_reader.read(before_path)
            after = manifest_reader.read(after_path)
        except AgentManifestReadError as error:
            typer.echo(f"Capability Diff input error: {error}", err=True)
            raise typer.Exit(code=ExitCode.ARTIFACT_ERROR) from error
        try:
            result = diff_engine.compare(
                before=before.manifest,
                after=after.manifest,
            )
        except CapabilityDiffError as error:
            typer.echo(f"Capability Diff compatibility error: {error}", err=True)
            raise typer.Exit(code=ExitCode.ARTIFACT_ERROR) from error
        except Exception as error:
            typer.echo("Capability Diff failed safely.", err=True)
            raise typer.Exit(code=ExitCode.REQUIRED_ANALYSIS_FAILED) from error

        rendered = (
            effective_diff_json.render(result)
            if output_format is OutputFormat.JSON
            else CapabilityDiffTextRenderer(language=language).render(result)
        )
        _emit_or_write(
            rendered,
            output_path=output_path,
            force=force,
            output_format=output_format,
            kind=ReportArtifactKind.CAPABILITY_DIFF,
            writer=writer,
            protected_paths=(before.path, after.path),
        )
        exit_code = exit_code_for_capability_diff(result)
        if exit_code is not ExitCode.SUCCESS:
            raise typer.Exit(code=exit_code)

    rules_application = typer.Typer(
        help="Inspect the deterministic structured Capability Rule Pack.",
        add_completion=False,
        no_args_is_help=True,
        rich_markup_mode="rich",
        context_settings={"help_option_names": ["-h", "--help"]},
    )

    @rules_application.command("list")
    def rules_list_command(
        language: CapabilityLanguageOption = CapabilityRuleLanguage.EN,
    ) -> None:
        """List stable Capability Rule IDs and reviewed localized titles."""

        rules = builtin_capability_rules()
        if language is CapabilityRuleLanguage.ZH:
            typer.echo(
                f"能力规则包 {CAPABILITY_RULE_PACK_VERSION}："
                f"{len(rules)} 条确定性结构化规则"
            )
            typer.echo("规则ID\t风险类别\t中文标题")
        else:
            typer.echo(
                f"Capability Rule Pack {CAPABILITY_RULE_PACK_VERSION}: "
                f"{len(rules)} deterministic structured rules"
            )
            typer.echo("RULE_ID\tCATEGORY\tTITLE")
        for rule in rules:
            metadata = rule.metadata
            text = metadata.text_for(language)
            typer.echo(f"{metadata.rule_id}\t{metadata.category.value}\t{text.title}")

    capability_application.add_typer(rules_application, name="rules")
    application.add_typer(capability_application, name="capability")
