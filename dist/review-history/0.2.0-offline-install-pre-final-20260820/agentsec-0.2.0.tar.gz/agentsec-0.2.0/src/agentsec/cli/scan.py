"""Registration and safe final-report delivery for the scan command."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated

import typer

from agentsec.application import (
    AssessmentAnalysisError,
    AssessmentEngine,
    AssessmentEngineUnavailable,
    AssessmentRequest,
)
from agentsec.cli.exit_codes import ExitCode, exit_code_for_assessment
from agentsec.config import ConfigurationError, OutputFormat, load_project_config
from agentsec.reporting import AssessmentJsonRenderer, AssessmentTextRenderer

ProjectRootArgument = Annotated[
    Path,
    typer.Argument(
        help="Project root containing Agent control assets.",
        show_default=True,
    ),
]

ConfigOption = Annotated[
    Path | None,
    typer.Option(
        "--config",
        help=(
            "Explicit configuration file. Defaults to "
            "<project-root>/.agentsec/config.yaml when present."
        ),
    ),
]

ScanFormatOption = Annotated[
    OutputFormat | None,
    typer.Option(
        "--format",
        help="Override configured Assessment output format: text or json.",
        case_sensitive=False,
    ),
]


def register_scan_command(
    application: typer.Typer,
    assessment_engine: AssessmentEngine,
    *,
    text_renderer: AssessmentTextRenderer | None = None,
    json_renderer: AssessmentJsonRenderer | None = None,
) -> None:
    """Register the Phase 1 scan command and final report adapters."""

    effective_text_renderer = (
        text_renderer if text_renderer is not None else AssessmentTextRenderer()
    )
    effective_json_renderer = (
        json_renderer if json_renderer is not None else AssessmentJsonRenderer()
    )

    @application.command("scan")
    def scan(
        project_root: ProjectRootArgument = Path("."),
        config_path: ConfigOption = None,
        output_format: ScanFormatOption = None,
    ) -> None:
        """Scan a project for Agent security findings."""

        try:
            loaded_config = load_project_config(
                project_root,
                config_path=config_path,
            )
        except ConfigurationError as error:
            typer.echo(f"Configuration error: {error}", err=True)
            raise typer.Exit(code=ExitCode.CONFIGURATION_ERROR) from error

        request = AssessmentRequest(
            project_root=project_root,
            config=loaded_config.config,
            config_path=loaded_config.path,
        )

        try:
            assessment = assessment_engine.assess(request)
        except AssessmentEngineUnavailable as error:
            typer.echo(f"Scan unavailable: {error}", err=True)
            raise typer.Exit(code=ExitCode.REQUIRED_ANALYSIS_FAILED) from error
        except AssessmentAnalysisError as error:
            typer.echo(f"Scan analysis failed: {error}", err=True)
            raise typer.Exit(code=ExitCode.REQUIRED_ANALYSIS_FAILED) from error

        selected_format = output_format or loaded_config.config.output.format
        if selected_format is OutputFormat.JSON:
            rendered = effective_json_renderer.render(assessment)
        else:
            rendered = effective_text_renderer.render(assessment)
        typer.echo(rendered, nl=False)

        exit_code = exit_code_for_assessment(assessment)
        if exit_code is not ExitCode.SUCCESS:
            raise typer.Exit(code=exit_code)
