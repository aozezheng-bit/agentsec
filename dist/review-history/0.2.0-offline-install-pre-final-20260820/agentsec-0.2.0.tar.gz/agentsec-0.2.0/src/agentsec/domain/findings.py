"""Evidence and security finding domain models."""

from __future__ import annotations

from typing import Annotated

from pydantic import Field, field_validator, model_validator

from agentsec.domain.base import (
    DomainModel,
    NonEmptyString,
    Sha256Digest,
    validate_relative_path,
)
from agentsec.domain.enums import (
    EvidenceConfidence,
    EvidenceSource,
    FindingCategory,
    ImpactLevel,
    LikelihoodLevel,
    Severity,
)


class Evidence(DomainModel):
    """Source material supporting a security finding."""

    source_type: EvidenceSource
    asset_path: NonEmptyString | None = None
    start_line: Annotated[int, Field(ge=1)] | None = None
    end_line: Annotated[int, Field(ge=1)] | None = None
    field: NonEmptyString | None = None
    excerpt: NonEmptyString | None = None
    content_sha256: Sha256Digest | None = None

    @field_validator("asset_path")
    @classmethod
    def path_must_be_project_relative(cls, value: str | None) -> str | None:
        """Validate file-backed evidence paths when present."""

        if value is None:
            return None
        return validate_relative_path(value)

    @model_validator(mode="after")
    def location_must_be_coherent(self) -> Evidence:
        """Validate line ranges and require a useful evidence locator."""

        if self.end_line is not None and self.start_line is None:
            raise ValueError("end_line requires start_line")
        if (
            self.start_line is not None
            and self.end_line is not None
            and self.end_line < self.start_line
        ):
            raise ValueError("end_line must be greater than or equal to start_line")
        if self.asset_path is None and self.field is None:
            raise ValueError("evidence requires asset_path or field")
        if self.start_line is not None and self.asset_path is None:
            raise ValueError("line evidence requires asset_path")

        return self


class Finding(DomainModel):
    """An independently actionable, evidence-backed security result."""

    finding_id: NonEmptyString
    rule_id: NonEmptyString
    category: FindingCategory
    title: NonEmptyString
    description: NonEmptyString
    likelihood: LikelihoodLevel
    impact: ImpactLevel
    severity: Severity
    score: Annotated[float, Field(ge=0, le=10)]
    confidence: EvidenceConfidence
    hard_gate: bool = False
    evidence: Annotated[tuple[Evidence, ...], Field(min_length=1)]
    recommendations: Annotated[tuple[NonEmptyString, ...], Field(min_length=1)]
