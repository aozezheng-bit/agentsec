#!/usr/bin/env bash

set -euo pipefail

repository_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
base_python="${PYTHON_BASE:-$repository_root/.venv/bin/python}"
release_version="$(
  PYTHONPATH="$repository_root/src" "$base_python" - <<'PY'
from agentsec.versioning import PACKAGE_VERSION
print(PACKAGE_VERSION)
PY
)"
release_dir="$repository_root/dist/$release_version"
wheel="$(find "$release_dir" -maxdepth 1 -type f -name "agentsec-$release_version-*.whl" -print -quit)"

if [[ ! -x "$base_python" ]]; then
  echo "Python executable not found: $base_python" >&2
  exit 2
fi
if [[ -z "$wheel" ]]; then
  echo "AgentSec $release_version wheel not found; run scripts/build-release.sh first." >&2
  exit 2
fi

venv_dir="$(mktemp -d "${TMPDIR:-/tmp}/agentsec-release-install.XXXXXX")"
trap 'rm -rf "$venv_dir"' EXIT

"$base_python" -m venv --system-site-packages "$venv_dir"
"$venv_dir/bin/python" -m pip install \
  --no-deps \
  --force-reinstall \
  "$wheel"

version_output="$($venv_dir/bin/agentsec version)"
if [[ "$version_output" != "agentsec $release_version" ]]; then
  echo "Installed version mismatch: $version_output" >&2
  exit 1
fi

"$venv_dir/bin/agentsec" rules list >/dev/null
"$venv_dir/bin/agentsec" capability rules list >/dev/null
"$venv_dir/bin/agentsec" scan \
  "$repository_root/testdata/safe/minimal-agent" \
  --format json \
  > "$venv_dir/safe-scan.json"
"$venv_dir/bin/agentsec" manifest \
  "$repository_root/demos/capability-drift-agent/baseline" \
  --agent-id release-agent \
  --format json \
  > "$venv_dir/baseline.manifest.json"
"$venv_dir/bin/agentsec" manifest \
  "$repository_root/demos/capability-drift-agent/risky-drift" \
  --agent-id release-agent \
  --format json \
  > "$venv_dir/risky.manifest.json"
"$venv_dir/bin/agentsec" capability assess \
  "$repository_root/demos/capability-drift-agent/risky-drift" \
  --agent-id release-agent \
  --format json \
  > "$venv_dir/risky.assessment.json"
"$venv_dir/bin/agentsec" capability diff \
  --before "$venv_dir/baseline.manifest.json" \
  --after "$venv_dir/risky.manifest.json" \
  --format json \
  > "$venv_dir/risky.diff.json"

"$venv_dir/bin/python" - "$release_version" "$venv_dir" <<'PY'
import importlib.metadata
import json
from pathlib import Path
import sys

release_version = sys.argv[1]
root = Path(sys.argv[2])
assert importlib.metadata.version("agentsec") == release_version
scan = json.loads((root / "safe-scan.json").read_text(encoding="utf-8"))
manifest = json.loads((root / "baseline.manifest.json").read_text(encoding="utf-8"))
assessment = json.loads((root / "risky.assessment.json").read_text(encoding="utf-8"))
diff = json.loads((root / "risky.diff.json").read_text(encoding="utf-8"))
assert scan["format"] == "agentsec-assessment" and scan["status"] == "complete"
assert manifest["schema_version"] == "0.3.0"
assert assessment["format"] == "agentsec-capability-assessment"
assert assessment["status"] == "complete" and assessment["summary"]["findings"] == 7
assert assessment["policy"]["ci_blocking_enabled"] is False
assert diff["schema_version"] == "0.1.0" and diff["complete"] is True
assert diff["added_count"] > 0
print("Non-editable offline wheel installation verified")
PY
