"""Export the public JSON Schemas for the current AgentSec release."""

from __future__ import annotations

from pathlib import Path

from agentsec.baselines import export_baseline_json_schema
from agentsec.domain import export_json_schemas
from agentsec.manifests import (
    export_agent_manifest_json_schema,
    export_capability_diff_json_schema,
)
from agentsec.reporting import (
    export_assessment_json_schema,
    export_capability_assessment_json_schema,
)


def main() -> None:
    repository_root = Path(__file__).resolve().parents[1]
    schema_root = repository_root / "schemas"
    export_json_schemas(schema_root / "domain")
    export_baseline_json_schema(schema_root / "baseline")
    export_assessment_json_schema(schema_root / "assessment")
    export_agent_manifest_json_schema(schema_root / "manifest")
    export_capability_diff_json_schema(schema_root / "capability-diff")
    export_capability_assessment_json_schema(schema_root / "capability-assessment")


if __name__ == "__main__":
    main()
