# AgentSec Deterministic Capability Rules

- Task: `P2I-02`
- Status: Complete
- Completion date: 2026-08-20
- Capability Rule Pack: `0.1.0`
- Capability Risk Model: `0.1.0`
- Decision: `docs/decisions/0029-capability-rule-pack-risk-model.md`

## 1. Purpose

P2I-02 evaluates the final P2I-01 Agent Manifest with framework-neutral,
deterministic combination rules. It detects security-relevant combinations of
normalized tools, permissions, controls, identities, relationships, Coverage,
and Unknowns without reading source files again.

```text
AgentAnalysisPipeline
→ final AgentManifest
→ CapabilityRuleContext
→ DeterministicCapabilityRuleRunner
→ CapabilityRuleFinding / safe Rule failures
```

The Rule layer is not part of the Phase 1 Markdown `RuleContext` and does not
change the current `agentsec scan` command.

## 2. Public API

```python
from agentsec.capability_rules import (
    DeterministicCapabilityRuleRunner,
    builtin_capability_rules,
)

result = DeterministicCapabilityRuleRunner(builtin_capability_rules()).run(
    final_manifest
)

findings = result.findings
failures = result.failures
complete = result.complete
```

The runner consumes only a strict `AgentManifest`. It has no project root,
filesystem reader, command runner, environment reader, network client, MCP
client, memory-store client, import hook, or LLM dependency.

## 3. Context indexes

`CapabilityRuleContext.from_manifest()` creates immutable deterministic indexes:

```text
tools_by_id
permissions_by_target
controls_by_target
identities_by_tool
child_tools_by_parent
relations_by_kind
unknowns_by_dimension
sources_by_locator
```

Child tools inherit parent controls only for correlation. The context never
reads or dereferences the source path represented by a Manifest locator.

## 4. Correlation policy

Correlation prevents unrelated capabilities from being combined blindly:

| Correlation | Meaning | Confidence | Static likelihood |
|---|---|---|---|
| `same_target` | Facts use one Tool or policy target | B | Moderate |
| `parent_child` | Facts belong to one MCP parent/child family | C | Moderate |
| `same_source` | Facts share one reviewed declaration source | C | Moderate |
| `explicit_relation` | A typed Manifest relationship joins facts | C | Moderate |
| `agent_wide` | Facts coexist but reachability is unverified | D | Low |
| `incomplete_coverage` | Coverage or a relevant dimension is unresolved | D | Low |

The first built-in Rules currently emit same-target, parent/child, Agent-wide,
and incomplete correlations. Reserved correlation values do not automatically
create Findings.

Confidence is not multiplied into score or Severity. Correlation scope also
selects likelihood because it represents a reachability precondition; this is a
separate reviewed risk decision.

## 5. Risk calculation

Each Rule has a trusted impact vector. Overall impact is the maximum dimension,
never an average:

```text
Impact = max(confidentiality, integrity, availability,
             safety, business/compliance, downstream blast radius)
```

The engine then uses the existing explicit mappings:

```text
NIST SP 800-30 Rev. 1 Table I-2 likelihood-impact matrix
FIPS 199 high-water-mark principle adapted to AgentSec impact
AgentSec representative 0–10 scores
FIRST CVSS v4.0 qualitative Severity ranges
```

Capability-specific correlation policy is added to `mapping_basis`. The
independent version is:

```text
CAPABILITY_RISK_MODEL_VERSION = 0.1.0
```

No Finding is averaged with another Finding. High results therefore cannot be
diluted by lower findings.

## 6. Initial Rule Pack

### CAP-CHAIN-001

```text
execute + secret_access + external network
```

- same target: Confidence B, Moderate likelihood, High Severity;
- same MCP parent/child family: Confidence C, Moderate likelihood, High Severity;
- Agent-wide only: Confidence D, Low likelihood, Medium Severity;
- one fallback Finding is emitted rather than an Agent-wide Cartesian product.

### CAP-APPROVAL-001

```text
write / execute / deploy / publish / admin
+ target not disabled
+ no prompt or deny effect/control
```

Explicit permission effects and inherited parent human-approval controls are
both considered. Same-target matches are B-confidence High findings.

### CAP-PERSIST-001

```text
persists_memory
+ secret_access / external network / write / admin
```

The current Manifest does not prove that sensitive data flows into the memory
target, so this is an Agent-wide D-confidence Medium finding.

### CAP-DELEGATE-001

```text
delegates_to
+ execute / admin / deploy / publish / persist
+ no prompt or deny approval evidence
```

Only unapproved powerful permissions participate. Until the delegated Agent has
an independently resolved Manifest, the result is Agent-wide D-confidence and
Medium Severity.

### CAP-EXTERNAL-001

```text
MCP server explicitly enabled
+ required
+ external environment
+ OAuth / ChatGPT / environment-backed authentication
```

The exact target correlation produces a B-confidence High finding. A merely
declared or explicitly disabled server does not match.

### CAP-COVERAGE-001

```text
high-impact permission or relationship
+ incomplete Framework Coverage or relevant Manifest Unknown
```

This is a Coverage Finding, not proof of exploitation. It uses D Confidence,
Low likelihood, Very High potential impact, and Medium Severity. Complete file
Coverage can still match when the relevant Tool, Permission, Control, Runtime
Identity, or Relationship dimension remains explicitly unresolved.

## 7. Finding evidence

Capability Findings do not require source excerpts. Evidence contains only:

```text
scope
root_id
relative path
field_path
start_line / end_line
content_sha256
```

The source hash is resolved from `AgentManifest.sources`; Rules cannot choose a
hash or absolute host path. Finding IDs hash Rule ID, correlation, related IDs,
and evidence locators without plaintext source values.

## 8. Localization

Every built-in Rule contains trusted English and Simplified Chinese:

```text
title
description
recommendations
```

Localization affects presentation only. Rule conditions, Finding identity,
impact, likelihood, Confidence, score, and Severity remain identical.

## 9. Failure and determinism

The runner:

- validates and sorts the trusted Rule registry;
- rejects duplicate Rule IDs;
- validates bounded, sorted, unique candidates;
- materializes one Rule atomically;
- isolates one failed Rule without discarding other Rule Findings;
- exposes only the stable failed Rule ID;
- produces deterministic Finding and failure ordering;
- emits no partial Findings from a failed Rule.

`result.complete=false` means at least one registered Rule failed. It is separate
from Manifest Coverage completeness, which remains visible through the Manifest
and CAP-COVERAGE-001.

## 10. Report-only boundary

P2I-02 always produces:

```text
hard_gate=false
CI blocking=false
```

No first-release Rule is Critical or a production Hard Gate. Adding gate floors,
blocking, waivers, or threshold policy requires a separate ADR and Capability
Risk Model version change.

## 11. Security boundary

P2I-02 never:

- opens a Manifest source path;
- executes a Command, Hook, Skill, plugin, Sub-Agent, Rule, or MCP server;
- contacts an endpoint;
- reads environment, Header, token, credential, or memory values;
- serializes parsed Command or URL values into evidence;
- calls an LLM;
- changes Phase 1 Rule Pack, Risk Model, CLI, or enforcement behavior.

## 12. Verification

`tests/test_capability_rules.py` covers:

- version and stable registry identity;
- English and Chinese metadata;
- same-target, parent/child, Agent-wide, and incomplete correlations;
- positive and safe negative cases for all six Rules;
- explicit prompt and deny semantics;
- relevant Unknowns with complete file Coverage;
- incomplete Coverage behavior for the complete Rule Pack;
- value-free hash-backed evidence;
- deterministic ordering and no Cartesian Finding explosion;
- per-Rule and atomic materialization failure isolation;
- report-only and Severity/Confidence separation.

## 13. Next task

P2I-03 now defines the strict Capability Assessment JSON wrapper and
deterministic bilingual Manifest, Capability Assessment, and Capability Diff
Text/JSON renderers. P2I-04 will expose them through the production CLI.
