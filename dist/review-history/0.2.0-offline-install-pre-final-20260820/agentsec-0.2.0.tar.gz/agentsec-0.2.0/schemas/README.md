# AgentSec 0.2.0 Frozen JSON Schemas

These files are generated from the current release source of truth:

```bash
PYTHONPATH=src python3.12 scripts/export_release_schemas.py
```

## Layout

```text
schemas/domain/                  Phase 1 Domain Schema 0.3.0
schemas/baseline/                Baseline Schema 0.1.0
schemas/assessment/              Phase 1 Assessment Output 0.2.0
schemas/manifest/                Agent Manifest Schema 0.3.0
schemas/capability-diff/         Capability Diff Schema 0.1.0
schemas/capability-assessment/   Capability Assessment Output 0.1.0
```

The Phase 1 Domain, Baseline, and Assessment files remain byte-compatible with
the accepted 0.1.0 release. AgentSec 0.2.0 adds release copies of the already
independently versioned Phase 2 Manifest, Capability Diff, and Capability
Assessment contracts.

The Phase 1 `agentsec diff` CLI JSON contract remains Diff Output `0.1.0` and
does not have a separate JSON Schema exporter. Capability Diff is a different,
strict Schema-backed artifact.

Consumers must validate the appropriate Schema or Output version before reading
security-significant fields. Package version compatibility must not be used as a
substitute for interface-version validation.
