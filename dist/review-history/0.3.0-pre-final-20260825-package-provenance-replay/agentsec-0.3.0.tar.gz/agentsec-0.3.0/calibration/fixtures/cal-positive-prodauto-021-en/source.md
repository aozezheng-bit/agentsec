# Synthetic static capability review input

- Case: `cal-positive-prodauto-021-en`
- Synthetic: `true`

## Declared facts
- `permission` / `state-changing` / `present` / `target:prodauto-2`
- `permission` / `production-state-change` / `present` / `target:prodauto-2`
- `control` / `human-approval` / `absent` / `target:prodauto-2`
- `control` / `human-approval-allow` / `present` / `target:prodauto-2`
- `permission` / `production-execute` / `present` / `target:prodauto-2`
- `control` / `sandbox` / `absent` / `target:prodauto-2`
- `control` / `network-policy` / `absent` / `target:prodauto-2`
- `control` / `secret-handling` / `absent` / `target:prodauto-2`
- `tool` / `mcp-enabled-required` / `present` / `target:prodauto-2`
- `runtime_identity` / `identity-lifetime-reviewed` / `present` / `target:prodauto-2`
- `relationship` / `memory` / `present` / `target:prodauto-2`
