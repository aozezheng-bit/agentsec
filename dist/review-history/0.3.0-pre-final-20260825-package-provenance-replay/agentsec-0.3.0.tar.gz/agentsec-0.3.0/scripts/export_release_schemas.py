"""Export the public JSON Schemas for the current AgentSec release."""

from __future__ import annotations

from pathlib import Path

from agentsec.baselines import export_baseline_json_schema
from agentsec.calibration import (
    export_adjudication_resolution_set_json_schema,
    export_adjudication_review_set_json_schema,
    export_calibration_adjudication_report_json_schema,
    export_calibration_case_json_schema,
    export_calibration_corpus_json_schema,
    export_calibration_report_json_schema,
    export_confidence_calibration_report_json_schema,
    export_confidence_review_set_json_schema,
)
from agentsec.calibration.pilot_tuning import (
    export_rule_score_calibration_json_schema,
)
from agentsec.change_impact import export_capability_change_impact_json_schema
from agentsec.domain import export_json_schemas
from agentsec.manifests import (
    export_agent_manifest_json_schema,
    export_capability_diff_json_schema,
)
from agentsec.pilot import export_pilot_json_schemas
from agentsec.reporting import (
    export_assessment_fail_on_json_schema,
    export_assessment_json_schema,
    export_capability_assessment_json_schema,
    export_organization_assessment_json_schema,
    export_organization_policy_json_schema,
)
from agentsec.vulnerabilities import (
    export_vulnerability_catalog_json_schema,
    export_vulnerability_input_json_schema,
)


def main() -> None:
    repository_root = Path(__file__).resolve().parents[1]
    schema_root = repository_root / "schemas"
    export_json_schemas(schema_root / "domain")
    export_baseline_json_schema(schema_root / "baseline")
    export_assessment_json_schema(schema_root / "assessment")
    export_assessment_fail_on_json_schema(schema_root / "assessment")
    export_organization_policy_json_schema(schema_root / "policy")
    export_organization_assessment_json_schema(schema_root / "policy")
    export_agent_manifest_json_schema(schema_root / "manifest")
    export_capability_diff_json_schema(schema_root / "capability-diff")
    export_capability_assessment_json_schema(schema_root / "capability-assessment")
    export_capability_change_impact_json_schema(
        schema_root / "capability-change-impact"
    )
    export_vulnerability_input_json_schema(schema_root / "vulnerability-input")
    export_vulnerability_catalog_json_schema(schema_root / "vulnerability-catalog")
    export_calibration_case_json_schema(schema_root / "calibration")
    export_calibration_corpus_json_schema(schema_root / "calibration")
    export_calibration_report_json_schema(schema_root / "calibration")
    export_adjudication_review_set_json_schema(schema_root / "calibration")
    export_adjudication_resolution_set_json_schema(schema_root / "calibration")
    export_calibration_adjudication_report_json_schema(schema_root / "calibration")
    export_confidence_review_set_json_schema(schema_root / "calibration")
    export_confidence_calibration_report_json_schema(schema_root / "calibration")
    export_pilot_json_schemas(schema_root / "pilot")
    export_rule_score_calibration_json_schema(schema_root / "calibration")


if __name__ == "__main__":
    main()
