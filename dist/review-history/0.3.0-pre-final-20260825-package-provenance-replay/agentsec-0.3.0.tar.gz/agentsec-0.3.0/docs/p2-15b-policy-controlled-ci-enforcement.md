# P2-15B：Policy-controlled CI Enforcement

## 状态

- 实现状态：完成最小可控链路
- 日期：2026-08-24
- 当前可用 Gate：`HG-CAPCHAIN-001`
- 默认行为：不阻断

## 目标与边界

P2-15B 将“报告展示”与“CI 阻断”分离。只有用户显式提供并通过严格校验的
Policy，且 Gate 已通过人工证据 Qualification，才允许返回退出码 `1`。

- 确定性 Rule / 已接受 Gate 结果拥有 CI 决策权；
- LLM 输出不能作为授权或阻断依据；
- 不修改 Finding 的 `hard_gate`、Severity、Score、Confidence 或 Shadow Gate；
- 不证明运行时 Tool、OAuth、Permission 可达性；
- Coverage 不完整或 Unknown 不得被风险阻断覆盖，优先返回 `2`；
- 未通过 Qualification 的 Gate 在 enforce 模式下 fail closed，返回 `3`；
- 不自动生成 Waiver、发布 Rule 或修改规则库。

## Policy 文件

格式：`agentsec-capability-ci-policy`，Schema `0.1.0`。示例：

```json
{
  "format": "agentsec-capability-ci-policy",
  "schema_version": "0.1.0",
  "policy_id": "org-capchain-enforce",
  "policy_version": "0.1.0",
  "enabled": true,
  "enforcement_mode": "enforce",
  "fail_on": {"qualified_gates": ["HG-CAPCHAIN-001"]},
  "coverage": {"require_complete": true, "require_unknown_free": true},
  "safety": {"allow_llm_authority": false, "allow_runtime_unverified_authority": false}
}
```

仓库提供：

- `policies/capability-ci-policy.json`：默认关闭、report-only；
- `policies/capability-ci-enforce-example.json`：显式 enforce 示例。

Loader 拒绝未知字段、未知 Gate、重复 Gate、非法启用组合、LLM/runtime
authority、Symlink Policy 和非法 JSON。

## CLI

```bash
# 只做报告，不会因为 Finding 阻断
agentsec capability assess ./agent --format json

# 显式加载 Policy，输出 CI 决策报告
agentsec capability enforce ./agent \\
  --policy policies/capability-ci-policy.json \\
  --format json

# 输出中文文本报告
agentsec capability enforce ./agent \\
  --policy policies/capability-ci-enforce-example.json \\
  --language zh
```

`capability assess` 保持原有 report-only 行为；只有新的 `capability enforce`
命令会执行 Policy 决策。

## 退出码

| 条件 | 退出码 |
|---|---:|
| Policy report-only/disabled，未命中阻断 | `0` |
| 已 Qualification Gate 命中且显式 enforce | `1` |
| Assessment Coverage、Rule 执行或 Policy 要求的 Unknown-free 不满足 | `2` |
| Policy Schema 无效、未知 Gate、未 Qualification Gate | `3` |
| 必需分析失败 | `5` |

## JSON 决策证据

当前输出格式为 `agentsec-capability-ci-enforcement` / `0.3.0`；P2-27 在不改变 Gate 决策语义的前提下增加 Policy source format/schema/SHA-256。报告包含：

- `policy_id` / `policy_version`；
- `decision`、`exit_code`、Assessment 完整性；
- 每个 Gate 的 `qualification`、`matched`、`blocks`、匹配 Finding ID 和原因；
- `boundary`，明确 `hard_gate=false`、`llm_authority=false`、
  `runtime_verified=false`；
- 不输出原始 Secret 或扫描项目运行时内容。

## 验证

```bash
.venv/bin/ruff check src tests scripts
.venv/bin/mypy src tests
PYTHONPATH=src .venv/bin/python -m pytest -q
```

## P2-27 Organization Policy YAML

`capability enforce --policy` now also accepts `agentsec-organization-policy` YAML `0.1.0`. The Capability section is adapted to the same Qualification-aware Gate engine. CI Report Output `0.2.0` records Policy source format, schema version, and SHA-256. See `docs/organization-policy.md`.
