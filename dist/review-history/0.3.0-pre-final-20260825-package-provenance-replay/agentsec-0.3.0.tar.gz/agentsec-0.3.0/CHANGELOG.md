# Changelog

## Unreleased — 2026-08-25 — P2-30 Pilot Project Integration

- add strict versioned Pilot Plan and Pilot Report contracts at `0.1.0`;
- integrate an eight-scenario internal Release Agent pilot through the real
  P2-29 Organization Policy CI Runner;
- collect decision, Coverage, scenario-level unique-Rule FP/FN, JSON/SARIF
  artifact size, and local wall-clock performance evidence;
- add JSON/Markdown pilot reports, frozen Schemas, ADR-0059, acceptance tests,
  and an active GitHub Actions pilot replay workflow;
- label the evidence `internal_integration` and avoid production accuracy,
  remote-CI, or runtime exploitability claims.

## Unreleased — 2026-08-25 — P2-29 CI Examples

- add an executable GitHub Actions pull-request workflow with separate decision
  capture, always-run JSON/SARIF upload, and final fail-closed enforcement;
- add a shared CI Runner that verifies JSON/SARIF exit-code agreement and
  preserves the canonical `0/1/2/3/4/5/64` process outcome;
- add a GitLab CI example plus deterministic active/expired Waiver fixtures;
- add local static validation and replay for safe, blocked, incomplete, invalid
  Policy, active-Waiver, and expired-Waiver scenarios;
- keep deterministic Organization Policy as the only blocking authority and
  defer real pilot-repository rollout evidence to P2-30.

## Unreleased — 2026-08-25 — P2-28 Risk Waivers

- add required Owner/Reason/Expiry Waivers scoped to Finding, Rule, or Gate;
- keep waived Findings/Gates visible while removing only blocking authority;
- automatically expire Waivers and record evaluation date plus applied/expired IDs;
- advance Organization Policy/Report to `0.2.0`, SARIF Reporter to `0.4.0`, and Capability CI Output to `0.3.0`;
- add ADR-0058, waiver example, schemas, tests, and documentation.

## Unreleased — 2026-08-25 — P2-27 Organization Policy

### Added

- add strict explicit `agentsec-organization-policy` YAML `0.1.0`;
- configure Scan High/Critical thresholds and blocking Rule IDs without disabling Findings;
- configure qualified Capability Gate IDs through the existing enforcement engine;
- add Policy SHA-256 provenance, Text/JSON/SARIF Scan reporting, frozen Schemas, and examples;
- add ADR-0057 and organization Policy tests.

### Changed

- advance SARIF Reporter `0.2.0` → `0.3.0`;
- advance Capability CI Enforcement Output `0.1.0` → `0.2.0` with source provenance;
- keep `--policy` explicit and mutually exclusive with `--fail-on`;
- defer waivers to P2-28.

## Unreleased — 2026-08-25 — P2-26 Explicit `--fail-on`

### Added

- add `agentsec scan --fail-on high|critical` with explicit CLI-only policy;
- add deterministic `FailOnDecision` `0.1.0` with Coverage precedence, stable
  matched Finding IDs, trusted rationale, and exit `0/1/2`;
- add `agentsec-assessment-fail-on` JSON Output `0.1.0`, strict decoder, frozen
  Schema, and schema exporter integration;
- add Text decision summary and explicit Assessment Policy header;
- extend SARIF with fail-on run/invocation/Result properties and advance SARIF
  Reporter `0.1.0` → `0.2.0`;
- add ADR-0056, task/usage documentation, CLI/unit/schema/tamper tests.

### Security and policy boundaries

- default scan behavior remains report-only;
- only AgentSec Finding Severity `high|critical` is accepted;
- incomplete Coverage returns `2` and cannot be overridden by a threshold match;
- Confidence, SARIF level, CVSS, LLM output, and runtime state have no fail-on
  authority;
- `capability assess` does not expose severity fail-on and cannot bypass the
  existing qualified `capability enforce --policy` path;
- organization Policy and waivers remain P2-27/P2-28.

## Unreleased — 2026-08-25 — P2-25 SARIF Reporter

### Added

- add strict deterministic SARIF 2.1.0 subset models and safe JSON codec;
- add Phase 1 Assessment, Capability Assessment, and Overall Score SARIF
  renderers;
- add `agentsec scan --format sarif` and
  `agentsec capability assess --format sarif`;
- add restricted `.sarif` Capability Assessment artifact output;
- add stable Rule indexes, URI/line locations, versioned partial fingerprints,
  AgentSec score/Confidence/Correlation/CVSS/CVE/CWE/Gate/Coverage properties;
- add `SARIF_REPORTER_VERSION = 0.1.0`, ADR-0055, usage documentation, and
  focused regression tests.

### Security and policy boundaries

- SARIF excludes Evidence excerpts, Commands, URL values, Headers, environment
  values, credentials, tokens, memory content, and raw source values;
- SARIF selection does not change exit codes, enable `--fail-on`, or block CI;
- incomplete analysis still emits visible partial SARIF and returns `2`;
- Config Schema remains `output.format=text|json`; SARIF is an explicit CLI-only
  override in P2-25.

## Unreleased — 2026-08-24 — P2-CAL-04A-HUMAN-SUBSET-01 HG-CAPCHAIN-001 Review Package

### Added

- add `scripts/build-capchain-review-subset.py`;
- add `calibration/p2-15a-capchain-40/` with 40 opaque independent-review
  questions, two pending Reviewer templates, selection binding, package
  manifest, label schema, and reviewer instructions;
- add a deterministic 20 Positive + 20 Eligible Negative/Near-miss selection
  without distributing expected labels, Ground Truth, Seed labels, or Joint
  Expert Evidence;
- add `tests/test_capchain_review_subset.py` for packet count, binding,
  determinism, non-clobbering, and secret/label boundary checks.

### Boundaries

- this package is prepared for independent human review but is not yet formal
  Human Evidence; a scoped Import, Confidence report, Comparison, and
  Adjudication are still required;
- no Gate qualification, `hard_gate=true`, `--fail-on`, or CI blocking is
  enabled.

## Unreleased — 2026-08-24 — P2-15A-PILOT-03 Shadow Gate Demo and Coverage Report

### Added

- add `scripts/run-shadow-gate-demo.py` and the presenter-friendly
  `scripts/run-shadow-gate-demo.sh` wrapper;
- add five deterministic Shadow Gate scenarios covering same-target,
  parent-child, Agent-wide, relevant Unknown, and incomplete-Coverage behavior;
- add `agentsec-capability-shadow-gate-demo` report Schema `0.1.0` with
  Coverage statistics and seeded Matrix Match/No-match metadata;
- add ADR-0049, the P2-15A-PILOT-03 task document, and focused Demo tests.

### Boundaries

- the Demo runs only inert deterministic static analysis and never executes
  scanned code, Skills, Hooks, commands, MCP servers, or network requests;
- Matrix Match/No-match labels are seeded expected calibration metadata, not
  Human Evidence, Agreement, Adjudication, or P2-15A qualification;
- the Demo remains Shadow-only, report-only, non-clobbering, and non-blocking.

## Unreleased — 2026-08-24 — P2-15A-PILOT-02 Capability Shadow Gate

### Added

- add deterministic `HG-CAPCHAIN-001` Shadow Gate evaluation after the
  Capability Rule runner;
- require `same_target` or `parent_child` correlation, complete Coverage, and
  zero relevant Unknowns for a Shadow match;
- add strict Gate version, correlation, related-ID, Finding binding, and
  non-enforcement contract validation;
- add ADR-0048 and the P2-15A-PILOT-02 task document.

### Changed

- keep Shadow metadata at `CAPABILITY_SHADOW_GATE_VERSION = 0.1.0` and keep the
  Capability Risk Model at `0.1.0`;
- keep the Capability Assessment Output at `0.2.0` with
  `mode=shadow`, `qualification=pilot_only`, and `blocks=false`.

### Boundaries

- Shadow matches do not set `hard_gate=true`, change scores or Severity, alter
  Evidence Confidence, change CLI exit codes, enable `--fail-on`, or block CI;
- Shadow evaluation does not qualify P2-15A and does not replace independent
  Reviewer A/B evidence or Adjudication.

## Unreleased — 2026-08-24 — P2-15A-PILOT-01 Joint Expert Review Evidence

### Added

- add `import-joint-panel` operation to `scripts/pilot-review.py` and
  `import_joint_panel_review` to `agentsec.calibration.pilot_review`;
- add `agentsec-joint-expert-review-evidence` artifact format `0.1.0` with
  mandatory `joint_panel` metadata (`evidence_mode=joint_expert_review`,
  `review_panel_id`, `reviewer_count`, `independent_initial_labels=false`,
  `adjudication_required=false`, `qualification=pilot_only`);
- add content-addressed `evidence_id` and full Pilot binding-chain
  verification (Pack manifest hash, Selection binding, per-row
  corpus/question-set/case-fingerprint/source hashes); any Case, Corpus, or
  Pack change fails the import closed;
- add `calibration/pilot-review-100/joint-panel-pilot-input.json` and the
  formalized 50-row `joint-expert-evidence.json` for `expert-panel-001`;
- add `tests/test_pilot_joint_panel_import.py` and the P2-15A-PILOT-01 task
  document.

### Changed

- reset the 50 joint-panel rows in
  `calibration/pilot-review-100/reviewer-a-labels.template.json` to `pending`
  so joint consensus conclusions can no longer be mistaken for Reviewer A
  independent evidence.

### Boundaries

- Joint Expert Review Evidence is pilot-only: it is not Reviewer A/B
  independent evidence, feeds no agreement/Kappa statistics, is not formal
  P2-CAL-04 Human Evidence, and does not count toward P2-15A Hard Gate
  qualification;
- no `hard_gate=true`, CI blocking, or `--fail-on` is enabled.

## Unreleased — 2026-08-24 — P2-24 CVSS Report-only Hard Gate

### Added

- add deterministic CVSS High/Critical effective-score gate evaluation;
- add `CvssHardGateMatch`, `CvssHardGateAssessment`, and
  `Finding.cvss_hard_gate`;
- add `cvss_hard_gate_matches` to Assessment JSON summaries;
- add Text/JSON report visibility and automatic `agentsec scan` integration;
- add ADR-0047, P2-24 task documentation, and focused CVSS Gate tests.

### Changed

- preserve CVSS Gate as a separate report view from AgentSec score, Severity,
  and generic `hard_gate`;
- bump Domain Schema `0.7.0` → `0.8.0`;
- bump Assessment Output `0.6.0` → `0.7.0`;
- add `CVSS_HARD_GATE_VERSION = 0.1.0` to the version vector.

### Boundaries

- CVSS Gate remains report-only and never changes CLI exit codes;
- no `--fail-on`, CI Blocking, production enforcement, runtime verification,
  or exploitability proof is enabled.

## Unreleased — 2026-08-24 — P2-23 CVE/CWE Source Adapters

### Added

- add an offline `agentsec-vulnerability-catalog` `0.1.0` contract and
  `schemas/vulnerability-catalog/vulnerability-catalog.schema.json`;
- add a bounded no-follow local source reader with AgentSec catalog and NVD
  CVE JSON 2.0 adapters;
- add deterministic exact-CVE auto-association and CWE/CVSS enrichment;
- add `agentsec scan --vulnerability-source PATH`;
- add ADR-0046, P2-23 task documentation, source adapter tests, and CLI tests.

### Changed

- extend `VulnerabilityReference.association_method` with
  `deterministic_match`;
- bump Domain Schema `0.6.0` → `0.7.0`;
- bump Assessment Output `0.5.0` → `0.6.0`.

### Boundaries

- source loading remains offline and report-only;
- no remote database query, LLM semantic match, runtime verification,
  exploitability proof, CVSS Hard Gate, or CI Blocking is enabled.

## Unreleased — 2026-08-24 — P2-CAL-04A Documentation and QA Closure

### Added

- add `tests/test_p2_16_risk_score_contract.py`: cross-layer NIST → High-Water-
  Mark Impact → Base Score → Severity → Text/JSON regression coverage;
- add `docs/tasks/P2-16-02-capability-risk-score-contract-regression-hardening.md`
  with the P2-16-02 completion record and unchanged-version decision;
- add `docs/calibration-adjudication-reviewer-pack.md`: Reviewer recruitment,
  blind A/B review flow, Ground Truth isolation, Label lifecycle
  (`pending → reviewed → adjudicated`), disagreement handling, FP/FN
  vocabulary, Case reuse and Gate statistics rules, post-review CLI usage,
  P2-15A preconditions, and security boundaries;
- add `tests/test_phase2_calibration_docs.py` documentation regression tests
  for the P2-CAL-04A Task ID, the three Gate Candidate IDs, the 20 Positive /
  20 Negative-Near-miss sample requirement, Seed Label restrictions,
  `report_only` enforcement, and the disabled state of `hard_gate=true`;
- add README quick starts for Reviewer Pack validation and the report-only
  Gate Calibration Coverage Check CLI;
- add `docs/tasks/P2-CAL-04A-AGENT-04-completion-report.md` with the final
  documentation handoff, sample statistics, QA results, human-review gap, and
  P2-15A blocking status;
- add `calibration/pilot-review-100/`: a deterministic 100-question Demo-first
  selection, reviewer-facing draft templates, and pilot workflow boundaries;
- add `scripts/pilot-review.py` and the bounded Pilot Review validator/report/
  compare/adjudication-template/merge workflow without changing the formal
  431-question importer.

### Changed

- record P2-CAL-04A completion status in `docs/phase2-scope.md`,
  `docs/phase2-integration-plan.md`,
  `docs/capability-calibration-hard-gate-enforcement-plan.md`, and the
  multi-Agent work plan;
- document the Coverage Check CLI and human review guide in
  `calibration/README.md`;
- document the Adjudication Resolution Set Schema `0.1.0` and Adjudication
  Report Output `0.3.0` in `schemas/README.md`;
- document Pilot progress validation, label-only reporting, and non-clobbering
  merge snapshots in the Pilot Review README and Reviewer Guide.

### Boundaries

- P2-CAL-04A only prepares Cases and the Reviewer Pack; real Reviewers must be
  recruited by humans and must blind review independently;
- Seed Labels are not production review results and all three Gate Candidates
  remain `more_data_required`;
- no Hard Gate qualification conclusion is produced; `hard_gate=true`, CI
  blocking, and `--fail-on` remain disabled;
- no Capability Rule, Risk Model, P2-15A/P2-15B code, Reviewer Label, or
  Adjudication Label content is changed.

## Unreleased — 2026-08-21 — P2-CAL-04A Reviewer Evidence Provenance

### Added

- add ADR-0038 and a versioned `AdjudicationResolutionSet` `0.1.0`;
- add strict Reviewer Pack `0.3.0` file manifests with complete path, SHA-256,
  size, role, scope, and mode validation;
- add separate formal imports for independent Adjudication Reviews, Human
  Confidence Reviews, and final Adjudication Resolutions;
- add explicit `seed` and `human` evidence modes to P2-CAL-04;
- add adversarial extra/missing Pack file, disagreement-preservation, Human
  Confidence, Resolution, and no-seed-fallback tests.
- pass the complete repository gate with 904 tests, Ruff formatting/lint, and
  strict Mypy over 196 source files.

### Changed

- preserve Reviewer A/B labels after adjudication instead of copying the final
  resolution into both Reviewer rows;
- report original Reviewer agreement separately from adjudication-required and
  adjudication-completed state;
- derive Human Gate Candidate Confidence grades and Kappa from the explicitly
  supplied Human Confidence report;
- bump Calibration Adjudication Report Output `0.2.0` → `0.3.0`.

### Boundaries

- all behavior remains report-only with CI blocking disabled;
- real Reviewer recruitment, identity verification, independence, and final
  human sign-off remain operational work;
- no Capability Rule, Risk Model, Hard Gate, runtime verification, LLM, or
  automatic Rule publication is added.

## Unreleased — 2026-08-21 — P2-CAL-04A Gate Coverage CLI Hardening

### Added

- add a report-only Gate Calibration Coverage Check CLI with Text/JSON output
  and explicit `0/2/4/5` exit semantics;
- add 33 focused Corpus/Matrix, threshold, path-safety, source-binding,
  semantic-uniqueness, cross-Gate reuse, and macOS path-alias regression tests;
- add the Agent 3 completion report and handoff state for final documentation
  and QA.

### Changed

- pin the three approved candidate Gate definitions in trusted code and reject
  Gate, component Rule, floor, or threshold injection from the Matrix;
- bind Matrix metadata and Rows to Corpus ID, Rule Pack, Ground Truth, Review
  Status, deterministic Scenario identity, and the expected Case source view;
- recompute value-free semantic fingerprints from validated Corpus Ground Truth
  and count unique eligible samples independently per Gate;
- allow one multi-expectation Case to cover multiple Gates without permitting
  duplicate counting inside the same Gate;
- preserve lexical and resolved Corpus roots so macOS `/tmp` and `/var` aliases
  remain usable without weakening Corpus-internal symlink rejection.

### Boundaries

- the CLI remains `report_only` with `ci_blocking_enabled=false`;
- all labels remain `seeded`; independent human Review and Adjudication are
  still required;
- no Rule, Risk Model, Hard Gate, `--fail-on`, CI enforcement, runtime
  verification, LLM, automatic Rule publication, or vulnerability proof is
  added.

## Unreleased — 2026-08-21 — P2-CAL-04A Corpus Repair

### Changed

- replace duplicated Gate samples with semantically distinct synthetic contexts;
- exclude relevant-Unknown and incomplete Cases from confirmed-negative Gate
  sample counts;
- add 155 inert Markdown/JSON/YAML/TOML/Manifest source views for Reviewer Pack
  preparation while keeping deterministic replay on value-free Fact Bundles;
- add semantic fingerprints, eligible-negative metadata, expanded Corpus identity
  `p2-cal-04a-expanded-corpus`, and Labels Version `0.2.0`;
- update Adjudication Report Output to `0.2.0` for candidate-scoped eligible
  sample-count semantics;
- add the Agent 1 completion report and stronger semantic-uniqueness, source-view,
  and Unknown-boundary tests.

### Boundaries

- all generated review and adjudication labels remain `seeded`;
- actual independent human Review and Adjudication are still pending;
- no Rule, Risk Model, Hard Gate, `--fail-on`, or CI enforcement is enabled.

## Unreleased — 2026-08-21 — P2-CAL-04 Independent Adjudication

### Added

- add independent `AdjudicationReviewSet` Schema `0.1.0` with complete
  Case/Rule reviewer coverage, classification/category/disposition labels, and
  bounded safe loading;
- add `CalibrationAdjudicationReport` Output `0.1.0` with FP/FN category
  separation, consensus/unresolved states, deterministic Rule tuning
  recommendations, and three report-only Gate Candidate assessments;
- add bilingual Text/JSON delivery, adjudication Schema exports, and
  `scripts/run-calibration-adjudication.py`;
- add 122 seeded adjudication labels for the 61-Expectation corpus;
- add ADR-0037, P2-CAL-04 documentation, and regression tests.

### Boundaries

- seeded labels are not independent production adjudications;
- all current Gate Candidates remain `more_data_required` because sample
  thresholds are not met;
- no Rule mutation or publication, Hard Gate activation, `--fail-on`, CI
  enforcement, runtime verification, LLM, or vulnerability proof is added.


## Unreleased — 2026-08-21 — P2-CAL-03 Evidence Confidence Calibration

### Added

- add independent `ConfidenceReviewSet` Schema `0.1.0` with bounded seeded or
  reviewed A/B/C/D labels, reviewer identity, correlation, and safe loading;
- add `ConfidenceCalibrationReport` Output `0.1.0` with reviewer pair
  agreement, Cohen's Kappa, Expected-vs-Emitted agreement, grade matrices, and
  per Rule/Correlation metrics;
- add bilingual Text/JSON rendering, confidence Schema exports, and
  `scripts/run-confidence-calibration.py`;
- add ADR-0036 and P2-CAL-03 documentation and tests.

### Boundaries

- checked-in labels are seeded fixture labels, not independently adjudicated
  human review evidence;
- current static Rules do not produce A-level runtime evidence; D-confidence
  and incomplete evidence remain report-only signals;
- no Hard Gate, `--fail-on`, CI enforcement, runtime verification, LLM, Rule
  publication, or vulnerability proof is added by P2-CAL-03.


## Unreleased — 2026-08-21 — P2-CAL-02 Deterministic Evaluation Runner

### Added

- add deterministic Fact Bundle replay for all 29 Capability Rule IDs;
- add TP/FP/FN/TN, Precision, Recall, False Positive Rate, F1, Macro/Micro,
  Correlation, Evidence Confidence, Evidence, Coverage, Unknown, duplicate,
  failure, and sample-sufficiency metrics;
- add versioned Text/JSON Calibration Report Output `0.1.0`;
- add `scripts/run-calibration.py` and P2-CAL-02 documentation.

### Boundaries

- current evaluator is a fact-level seed adapter, not a production parser or
  runtime calibration claim;
- current seed metrics are perfect by construction and all Rules remain sample
  insufficient;
- no Hard Gate, CI enforcement, runtime verification, LLM, or Rule publication.

## Unreleased — 2026-08-21 — P2-CAL-01 Calibration Case Schema

### Added

- add strict `agentsec.calibration` Case and Corpus Index models with
  positive/negative/near-miss/incomplete/Unknown/conflict labels;
- add safe JSON codecs, Draft 2020-12 Schema exports, bounded UTF-8 loading,
  root containment, symlink rejection, and current Rule Pack coverage checks;
- add 61 inert seed Cases covering all 29 Capability Rule IDs with match and
  no-match labels, expected Correlation, and Evidence Confidence;
- add ADR-0035 and P2-CAL-01 documentation.

### Boundaries

- seed labels are not statistical Precision/Recall results; P2-CAL-02～04 still
  own replay, adjudication, Confidence calibration, and Hard Gate candidacy;
- no Capability Hard Gate, CI enforcement, runtime verification, or LLM is
  added by P2-CAL-01.

## Unreleased — 2026-08-20 — P2-14 Capability Rule Pack 0.2.0

### Added

- expand the structured Capability Rule Pack from six to 29 deterministic,
  bilingual, source-backed Rules;
- add dedicated production/external permission, automatic approval, missing
  guardrail, runtime-identity, memory/delegation, and relationship-Unknown Rules;
- add P2-14 inventory, production/identity/Unknown, benign negative,
  determinism, evidence, secret-omission, and report-only regression coverage;
- regenerate English and Chinese Capability Drift artifacts: the risky state now
  has 17 Findings across 16 Rule IDs, while baseline and remediation remain zero;
- add ADR-0034 and update Capability Rule, versioning, Demo, Phase 2 Scope, and
  integration documentation.

### Changed

- `CAPABILITY_RULE_PACK_VERSION` `0.1.0` → `0.2.0`;
- keep `CAPABILITY_RISK_MODEL_VERSION = 0.1.0`, Capability Assessment Output
  `0.1.0`, Capability Change Impact Output `0.1.0`, and Agent Manifest Schema
  `0.3.0` unchanged;
- keep all Capability Findings deterministic and report-only with
  `hard_gate=false` and no CI blocking.

### Boundaries

- Package remains `0.2.0` during source development; accepted `dist/0.2.0`
  artifacts are not rebuilt or replaced and still contain Rule Pack `0.1.0`;
- P2-14 does not add `--fail-on`, CI enforcement, runtime Tool/OAuth/Permission
  verification, LLM analysis, automatic Rule publication, or vulnerability proof.

## Unreleased — 2026-08-20 — P2-13 Capability Change Impact

### Added

- deterministic `CapabilityChangeImpactReport` Output `0.1.0` with canonical
  embedded Capability Diff, semantic Tool/Permission/Control before/after state,
  exposure direction, and report-only policy;
- logical Capability Finding Delta matching by `rule_id + related_ids`, with
  `added`, `resolved`, `changed`, and `unchanged` lifecycle states;
- `agentsec capability impact` Text/JSON CLI with bounded Manifest input,
  private atomic output, bilingual presentation, and incomplete-analysis exit `2`;
- English/Chinese Capability Drift Demo impact artifacts and management-summary
  Finding Delta metrics;
- ADR-0033 and P2-13 source-development documentation.

### Boundaries

- Package remains `0.2.0` during source development; P2-13 is not included in
  the accepted `dist/0.2.0/` artifacts;
- Capability Diff `0.1.0`, Capability Rule Pack `0.1.0`, and Capability Risk
  Model `0.1.0` remain unchanged;
- exposure direction is not a new risk score, authorization decision, runtime
  proof, Hard Gate, `--fail-on`, or CI block.

## 0.2.0 — 2026-08-20 — Phase 2 Integration MVP

### Added

- reviewed Simplified Chinese trigger variants for all 15 stable Markdown Rules;
- `agentsec rules list --language zh`;
- Chinese positive and benign negative regression for every Rule ID;
- five inert Chinese corpus Cases, bringing the current corpus to 45 Cases;
- fully Chinese Release Agent baseline, drift, injection, and remediation Demo.

### Changed

- Rule Pack `0.2.0` → `0.3.0`; Rule IDs and risk meanings remain stable.

### P2-01 structured Parser foundation

- add one deep `StructuredParser` interface and normalized source-backed node
  model;
- add deterministic JSON, safe YAML, and TOML Parser adapters;
- add duplicate-key, unsafe YAML, malformed input, source-location, determinism,
  and parser resource-limit regression tests;
- add Phase 2 Scope, ADR-0018, and structured Parser documentation;
- keep structured-file discovery, Agent Manifest, capability mapping, rules, and
  LLM analysis deferred to later Phase 2/3 tasks.

### P2-02 Rules and MCP specialized Parsers

- add a strict non-executing Parser for literal Codex `prefix_rule(...)`
  declarations and inline examples;
- add static MCP declaration parsing for top-level and plugin-bundled server
  tables, STDIO, Streamable HTTP, environment references, tool filters, approval
  modes, and timeouts;
- omit static environment/header values and URL query/fragment values from the
  specialized MCP model;
- retain unknown direct MCP fields by source location without copying values;
- add 34 targeted Rules/MCP parsing, malicious-expression, no-execution,
  no-network, secret-omission, line-location, limit, and determinism tests;
- add ADR-0019 and specialized Parser documentation.

### P2-03 Framework Adapter interface

- add a one-method `FrameworkAdapter.inspect()` Protocol with stable Adapter
  identity and version provenance;
- add portable project/user/plugin locators, neutral Asset roles and formats,
  precedence hints, parser-coherent records, and explicit Coverage models;
- validate deterministic ordering, uniqueness, line-count coherence, role/format
  compatibility, and MCP-role consistency;
- verify two independent fake Adapters through the same interface;
- keep framework inspection output separate from Phase 1 RuleContext and risk
  processing;
- add ADR-0020 and Framework Adapter interface documentation.

### P2-04 Codex Adapter

- add the first production `FrameworkAdapter` implementation for Codex;
- add explicit working-directory context to Framework inspection requests;
- discover project-chain and explicit user-scope Agent, Skill, `.rules`, TOML,
  and MCP configuration assets;
- preserve both base and Override instructions and deterministic precedence
  hints for later effective-configuration resolution;
- enforce root containment, internal-only symbolic links, bounded reads, strict
  UTF-8, depth limits, global asset limits, deterministic ordering, and explicit
  Coverage;
- keep commands, URLs, environment references, Skills, Rules, plugins, and MCP
  servers inert, with no LLM or network access;
- add ADR-0021, Codex Adapter documentation, and targeted discovery,
  non-execution, parser, limit, symlink, precedence, and Coverage tests.

### P2-05 Agent Manifest Schema

- add independent Agent Manifest Schema `0.1.0` without changing frozen Phase 1
  Domain, Baseline, Diff, Assessment, Rule Pack, or Risk Model versions;
- add strict immutable models for subject identity, portable sources,
  instruction candidates, tools, permissions, controls, runtime identities,
  relationships, Unknowns, and Manifest Coverage;
- add explicit unresolved/partial/resolved/unknown/not-applicable/conflict state
  so empty fields cannot silently imply absence or safety;
- add `AgentManifestBuilder` to normalize Framework source metadata, Coverage,
  instruction candidates, and future declaration sources without copying parsed
  source values;
- add deterministic JSON encoding, compatibility-first safe validation, and
  Draft 2020-12 JSON Schema export;
- add ADR-0022, Agent Manifest documentation, domain glossary terms, and
  targeted schema, provenance, safety, ordering, compatibility, and integration
  tests.

### P2-06 Instruction Inheritance / Override Resolver

- add deterministic `InstructionResolver` over Agent Manifest candidates;
- resolve same-directory Base/Override slots without reading instruction text;
- preserve user-before-project and root-before-nested application order;
- add `effective_order`, `overridden_sources`, and `resolution_trace`;
- mark incomplete Coverage as `partial` and fail closed for ambiguous candidates;
- increment Agent Manifest Schema `0.1.0` → `0.2.0`;
- add ADR-0023, Resolver documentation, and inheritance/security tests.

### P2-07 Configuration Precedence Resolver

- add source-level `ManifestConfigurationProfile` and configuration candidate
  kinds for Framework, Rules, and MCP sources;
- add deterministic `ConfigurationResolver` with user/project scope, precedence
  rank, portable path, and chain-key ordering;
- preserve canonical `effective_sources`, semantic `effective_order`, and a
  source-level resolution trace;
- mark incomplete configuration Coverage as `partial` and fail closed for
  duplicate candidate identities;
- keep field-level TOML/Rules/MCP value merging out of P2-07;
- increment Agent Manifest Schema `0.2.0` → `0.3.0`;
- add ADR-0024, Configuration Resolver documentation, and source-order,
  Coverage, no-value-read, and determinism tests.

### P2-08 Skill / MCP / Tool Association

- add deterministic `AssociationExtractor` (and `AssociationResolver` alias)
  over the existing Agent Manifest and Framework inspection seam;
- associate Skills, static MCP servers, and MCP tool filters/policies with
  source-backed `ManifestTool` items;
- add `uses_skill`, `uses_mcp`, and `uses_tool` relationships with declared
  state and exact field/line provenance;
- classify only conservative static MCP potential side effects: STDIO execute,
  Streamable HTTP network, and plugin-bundled unknown;
- normalize stable IDs with bounded collision disambiguation;
- retain explicit partial status for incomplete inspection Coverage;
- keep commands, endpoints, environment values, headers, Skill bodies, runtime
  enumeration, permissions, risk, and LLM analysis outside the boundary;
- keep Agent Manifest Schema at `0.3.0` because no serialized fields changed;
- add ADR-0025, association documentation, and five targeted regression tests.

### P2-09 Static Capability Profile

- add deterministic `CapabilityExtractor` for existing permission, control, and
  runtime identity Manifest profiles;
- map known Skill/MCP/tool side effects into conservative read/write/execute/
  network/secret/admin/unknown permission facts;
- map explicit `.rules` decisions into allow/prompt/deny execute permissions and
  Prefix Rule controls without evaluating commands;
- add MCP enablement, required, approval, tool-filter, timeout, network-policy,
  and secret-handling controls with field/line provenance;
- add credential-free MCP runtime identity hypotheses for OAuth, ChatGPT,
  bearer/environment, plugin-bundled, local, and external evidence;
- keep permission effect separate from Tool availability and runtime identity
  separate from attestation;
- preserve `partial` for incomplete Coverage or uncertain/unsupported facts;
- keep Agent Manifest Schema at `0.3.0` because no serialized fields changed;
- add ADR-0026, static capability documentation, and two targeted regression
  tests.

### P2-10 Sub-Agent / Memory Relationships

- add deterministic `RelationshipExtractor` (and `RelationshipResolver` alias)
  for explicit Markdown frontmatter declarations;
- associate delegation aliases with `delegates_to`;
- associate memory read/write/persist aliases and nested `memory` declarations
  with the existing memory relationship kinds;
- retain P2-08 Skill/MCP/tool relations and merge duplicate logical edges with
  deterministic source provenance;
- hash unsafe paths, URLs, control-character, whitespace, and oversized targets
  into bounded unknown IDs without serializing raw values;
- mark malformed/unsupported declarations and unsafe targets as partial/unknown;
- expand relationship declaration-source roles to Markdown instructions,
  Overrides, Skills, and MCP configuration;
- keep Agent Manifest Schema at `0.3.0` because no serialized fields changed;
- add ADR-0027, relationship documentation, and five targeted regression tests.

### P2-11 Explicit Unknowns and Capability Diff

- add idempotent `UnknownExtractor` (and `UnknownResolver` alias) for profile and
  item uncertainty, runtime verification requirements, and incomplete Coverage;
- map stable Unknown dimensions/reasons without copying source values;
- add versioned `CapabilityDiffer` for Tool, Permission, Control, Runtime
  Identity, Relationship, Unknown, profile-status, and Coverage changes;
- emit added/removed/modified entries with stable IDs, changed-field names,
  SHA-256 fingerprints, and before/after source provenance instead of full item
  values;
- preserve visible changes while marking Diff incomplete if either Manifest has
  incomplete Coverage;
- add independent `CAPABILITY_DIFF_SCHEMA_VERSION = 0.1.0`, deterministic JSON,
  compatibility-first validation, safe errors, and Draft 2020-12 Schema export;
- keep Agent Manifest Schema at `0.3.0` and Phase 1 Diff Output at `0.1.0`;
- add ADR-0028, Unknown/Capability Diff documentation, and five targeted tests.

### P2I-01 Full Agent Analysis Pipeline

- add injectable `AgentAnalysisPipeline` and `AgentAnalysisEngine` application
  seam for one-call P2-04 through P2-11 orchestration;
- add explicit request roots/limits, final Manifest result, current version
  vector, and bounded nine-stage operational trace;
- add safe required-stage error codes without copying dependency diagnostics;
- add `CapabilityExtractor.extract_associated()` and
  `RelationshipExtractor.extract_associated()` while preserving existing public
  `extract()` behavior;
- ensure Association extraction runs once inside the integrated Pipeline;
- retain valid Partial Manifest results and explicit Unknowns for incomplete
  Coverage;
- keep Agent Manifest, Capability Diff, Phase 1 Domain, Rule Pack, Risk Model,
  CLI, and enforcement versions unchanged;
- add Pipeline documentation and deterministic/order/partial/error-safety
  regression tests.

### P2I-02 Deterministic Capability Rule Pack

- add an independent framework-neutral `CapabilityRule` seam over finalized
  Agent Manifests;
- add immutable deterministic context indexes for Tools, Permissions, Controls,
  Runtime Identities, parent/child Tools, Relationships, Unknowns, and Sources;
- add Capability Rule Pack `0.1.0` with six stable bilingual Rule IDs for
  approval, execution/secret/network chain, Coverage, delegation, external MCP,
  and persistence risk;
- add Capability Risk Model `0.1.0` with correlation-based Evidence Confidence
  and static likelihood, NIST matrix scoring, FIPS-style high-water-mark impact,
  and FIRST CVSS Severity ranges;
- prefer same-target and MCP parent/child correlation, avoid Agent-wide Cartesian
  products, and lower Agent-wide/incomplete evidence to D Confidence;
- add value-free hash-backed evidence and deterministic Finding identity without
  source excerpts, commands, URLs, Headers, environment values, or credentials;
- add atomic per-Rule failure isolation and deterministic result ordering;
- keep `hard_gate=false`, CI blocking disabled, Phase 1 Rule/Risk versions
  unchanged, and no LLM/runtime/network/MCP behavior;
- add ADR-0029, Capability Rule documentation, version documentation, and
  positive/negative/Unknown/determinism/failure-isolation tests.

### P2I-03 Manifest, Capability Assessment, and Capability Diff Reports

- add `ManifestTextRenderer` and canonical `ManifestJsonRenderer`;
- add `CapabilityDiffTextRenderer` and canonical `CapabilityDiffJsonRenderer`;
- add `CapabilityAssessmentEngine` application composition for the full analysis
  Pipeline plus deterministic Capability Rule Pack;
- add independently versioned Capability Assessment Output `0.1.0` with strict
  JSON wrapper, derived summary/status validation, fixed report-only policy,
  canonical embedded Manifest, Findings, Stage Trace, and Rule failures;
- add deterministic Draft 2020-12 Capability Assessment Schema export and
  compatibility-first safe validation errors;
- add English and Simplified Chinese Text presentation for management summary and
  developer evidence;
- add per-section Text bounds, explicit omitted counts, secret redaction, and
  untrusted-text sanitization;
- retain Agent Manifest Schema `0.3.0`, Capability Diff Schema `0.1.0`, Phase 1
  Assessment Output `0.2.0`, and report-only/no-runtime-proof boundaries;
- add ADR-0030, report documentation, version documentation, and complete/partial/
  localization/determinism/non-disclosure tests.

### P2I-04 Manifest and Capability CLI

- add `agentsec manifest` with explicit project/working/user/Codex roots, Agent
  ID, Text/JSON, English/Chinese, output, and restricted force options;
- add `agentsec capability assess`, `capability diff`, and bilingual
  `capability rules list`;
- add `DeterministicManifestCapabilityDiffEngine` application seam;
- add bounded no-follow compatibility-first Agent Manifest file input;
- add kind-validated `.json`/`.txt` mode-0600 atomic report output;
- make no-clobber the default and limit `--force` to an existing valid artifact
  of the same kind and format;
- reject Diff output paths that equal either Manifest input;
- add `ARTIFACT_ERROR` as numeric exit-code-4 alias while retaining report-only
  Finding exit `0`, incomplete exit `2`, and reserved risk-policy exit `1`;
- add ADR-0031, CLI guide, help/exit/security documentation, and end-to-end CLI/
  storage regression tests;
- keep all Schema, Output, Rule Pack, Risk Model, and frozen distribution
  versions unchanged pending a separate Phase 2 release task.

### P2I-05 Capability Drift Story Demo

- add inert English and Chinese baseline, risky-drift, incomplete, and
  remediated Release Agent capability projects;
- demonstrate seven Findings across six Capability Rule IDs with highest High,
  complete Capability Diff, incomplete exit `2`, and remediation back to zero
  Findings;
- add live automated and seven-stage presenter runners with language, pause,
  output-directory, and offline options;
- add deterministic frozen Manifest, Capability Assessment, Capability Diff,
  localized Text, management summary, and SHA-256 checksum artifacts for both
  languages;
- add semantic validation for report-only policy, Coverage, Rule IDs, Diff,
  remediation, and synthetic secret/endpoint non-disclosure;
- add developer/management scripts, bilingual acceptance records, documentation,
  and E2E tests;
- keep all Schema, Output, Rule Pack, Risk Model, Hard Gate, enforcement, and
  frozen Phase 1 distribution versions unchanged.

### Phase 2 Integration Hardening and Release Review

- increment Package `0.1.0` → `0.2.0` while retaining every independent Schema,
  Output, Rule Pack, and Risk Model version;
- sanitize malicious Manifest/Capability Diff validation location keys;
- enforce no-follow regular-file reads when validating `--force` replacement;
- freeze Agent Manifest, Capability Diff, and Capability Assessment JSON Schemas;
- make build/install scripts derive the current source version and verify Phase 1
  plus Phase 2 CLI paths offline;
- add exact wheel/sdist checksum, metadata, required-content, and reviewed-source
  consistency tests for the preserved Phase 2 release candidate;
- replay both English and Chinese Capability Drift Demo tracks in live and
  checksum-verified offline modes during release checks;
- add ADR-0032, 0.2.0 release notes, known limitations, acceptance evidence, and
  preserved version-specific artifacts under `dist/0.2.0/`.

### Distribution boundary

The accepted 0.1.0 wheel/sdist remain preserved at the `dist/` root. AgentSec
0.2.0 artifacts and checksums are stored separately under `dist/0.2.0/`. No
remote publication, Git tag, or production deployment is claimed.

## 0.1.0 — 2026-08-19

First Phase 1 Markdown static-scanning PoC release.

### Added

- installable `agentsec` Python package and console entry point;
- `version`, `scan`, `baseline create`, `diff`, and `rules list` commands;
- safe Markdown collection, path containment, resource limits, CommonMark
  parsing, frontmatter/reference extraction, and obfuscation indicators;
- versioned Baseline Schema, atomic Baseline writer, Asset Diff, and bounded Text
  Diff;
- 15 deterministic Markdown Rules with isolated failure Coverage;
- NIST-style preliminary risk, high-water-mark Impact, 0–10 score, Severity,
  A/B/C/D Evidence Confidence, and report-only Hard Gate metadata;
- ANSI-free Rich Text and strict `agentsec-assessment` JSON reports;
- shared hardened secret redaction and control-character escaping;
- explicit Coverage reporting and stable exit codes;
- 40-Case Safe/Risky/Prompt Injection/Malformed corpus;
- frozen JSON Schemas;
- Release Agent developer/management Demo with offline fallback;
- README, complete PoC usage guide, release notes, known limitations, and
  acceptance records.

### Security policy

```text
enforcement_mode=report_only
ci_blocking_enabled=false
global_safety_claimed=false
```

### Compatibility vector

```text
Package 0.1.0
Config Schema 0.1.0
Domain Schema 0.3.0
Baseline Schema 0.1.0
Diff Output 0.1.0
Assessment Output 0.2.0
Rule Pack 0.2.0
Risk Model 0.4.0
```
