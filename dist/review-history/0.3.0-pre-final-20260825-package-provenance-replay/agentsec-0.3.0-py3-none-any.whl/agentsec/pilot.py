"""Bounded P2-30 pilot configuration, execution, and evidence reporting."""

from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Annotated, Any, Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from yaml.tokens import AliasToken, AnchorToken, TagToken

from agentsec.rules import BUILTIN_MARKDOWN_RULE_IDS

PILOT_PLAN_FORMAT = "agentsec-pilot-plan"
PILOT_PLAN_SCHEMA_VERSION = "0.1.0"
PILOT_REPORT_FORMAT = "agentsec-pilot-report"
PILOT_REPORT_OUTPUT_VERSION = "0.1.0"
PILOT_MAX_PLAN_BYTES = 2_097_152


class PilotError(ValueError):
    """Safe pilot plan or execution failure."""


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, str_strip_whitespace=True)


class PilotCase(_Strict):
    """One inert project state with reviewed expected scanner outcomes."""

    case_id: Annotated[str, Field(pattern=r"^[a-z][a-z0-9-]{0,63}$")]
    title: Annotated[str, Field(min_length=1, max_length=160)]
    project_root: Annotated[str, Field(min_length=1, max_length=512)]
    policy_path: Annotated[str, Field(min_length=1, max_length=512)]
    expected_exit: Literal[0, 1, 2]
    expected_coverage: Literal["complete", "incomplete"]
    expected_rule_ids: tuple[str, ...] = ()
    max_duration_ms: Annotated[int, Field(ge=1, le=600_000)] = 10_000

    @field_validator("project_root", "policy_path")
    @classmethod
    def paths_must_be_relative(cls, value: str) -> str:
        candidate = Path(value)
        if candidate.is_absolute() or ".." in candidate.parts:
            raise ValueError("pilot paths must be repository-relative")
        return candidate.as_posix()

    @field_validator("expected_rule_ids")
    @classmethod
    def rules_must_be_known_sorted_unique(
        cls, values: tuple[str, ...]
    ) -> tuple[str, ...]:
        if values != tuple(sorted(set(values))):
            raise ValueError("expected_rule_ids must be sorted and unique")
        if set(values) - set(BUILTIN_MARKDOWN_RULE_IDS):
            raise ValueError("expected_rule_ids contains unsupported Rule IDs")
        return values

    @model_validator(mode="after")
    def coverage_and_exit_must_agree(self) -> PilotCase:
        if self.expected_coverage == "incomplete" and self.expected_exit != 2:
            raise ValueError("incomplete pilot cases must expect exit 2")
        if self.expected_coverage == "complete" and self.expected_exit == 2:
            raise ValueError("complete pilot cases cannot expect exit 2")
        return self


class PilotPlan(_Strict):
    """Explicit local pilot contract; never discovered from scanned content."""

    format: Literal["agentsec-pilot-plan"]
    schema_version: Literal["0.1.0"]
    pilot_id: Annotated[str, Field(pattern=r"^[a-z][a-z0-9._-]{0,127}$")]
    project_name: Annotated[str, Field(min_length=1, max_length=160)]
    owner: Annotated[str, Field(min_length=1, max_length=128)]
    evidence_mode: Literal["internal_integration", "external_repository"]
    cases: Annotated[tuple[PilotCase, ...], Field(min_length=1, max_length=1000)]

    @model_validator(mode="after")
    def cases_must_be_sorted_unique(self) -> PilotPlan:
        case_ids = tuple(item.case_id for item in self.cases)
        if case_ids != tuple(sorted(set(case_ids))):
            raise ValueError("pilot cases must be sorted and unique by case_id")
        return self


class PilotCaseResult(_Strict):
    case_id: str
    title: str
    expected_exit: Literal[0, 1, 2]
    observed_exit: int
    expected_coverage: Literal["complete", "incomplete"]
    observed_coverage: Literal["complete", "incomplete", "unavailable"]
    expected_rule_ids: tuple[str, ...]
    observed_rule_ids: tuple[str, ...]
    true_positive_rule_ids: tuple[str, ...]
    false_positive_rule_ids: tuple[str, ...]
    false_negative_rule_ids: tuple[str, ...]
    duration_ms: int
    max_duration_ms: int
    json_bytes: int
    sarif_bytes: int
    sarif_valid: bool
    decision_agreement: bool
    coverage_agreement: bool
    detection_agreement: bool
    performance_within_limit: bool
    passed: bool


class PilotMetrics(_Strict):
    cases: int
    passed_cases: int
    failed_cases: int
    true_positives: int
    false_positives: int
    false_negatives: int
    precision: float | None
    recall: float | None
    decision_accuracy: float
    coverage_accuracy: float
    detection_accuracy: float
    total_duration_ms: int
    mean_duration_ms: float
    p50_duration_ms: int
    p95_duration_ms: int
    max_duration_ms: int


class PilotReport(_Strict):
    format: Literal["agentsec-pilot-report"] = "agentsec-pilot-report"
    format_version: Literal["0.1.0"] = "0.1.0"
    status: Literal["complete", "failed"]
    pilot_id: str
    project_name: str
    owner: str
    evidence_mode: Literal["internal_integration", "external_repository"]
    plan_sha256: Annotated[str, Field(pattern=r"^[0-9a-f]{64}$")]
    agentsec_executable: str
    metrics: PilotMetrics
    cases: tuple[PilotCaseResult, ...]
    limitations: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class LoadedPilotPlan:
    plan: PilotPlan
    path: Path
    sha256: str


class _UniqueKeyLoader(yaml.SafeLoader):
    pass


def _construct_mapping(
    loader: _UniqueKeyLoader, node: yaml.MappingNode, deep: bool = False
) -> dict[Any, Any]:
    mapping: dict[Any, Any] = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        if key in mapping:
            raise PilotError("pilot plan contains a duplicate YAML key")
        mapping[key] = loader.construct_object(value_node, deep=deep)
    return mapping


_UniqueKeyLoader.add_constructor(
    yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, _construct_mapping
)


def load_pilot_plan(path: Path, *, repository_root: Path) -> LoadedPilotPlan:
    """Load a bounded explicit plan and verify every referenced path."""

    resolved_path = path.resolve(strict=True)
    root = repository_root.resolve(strict=True)
    _require_within(resolved_path, root, "pilot plan")
    if path.is_symlink():
        raise PilotError("pilot plan cannot be a symbolic link")
    mode = os.stat(resolved_path, follow_symlinks=False).st_mode
    if not stat.S_ISREG(mode):
        raise PilotError("pilot plan must be a regular file")
    size_bytes = os.stat(resolved_path, follow_symlinks=False).st_size
    if size_bytes > PILOT_MAX_PLAN_BYTES:
        raise PilotError("pilot plan exceeds the maximum size")
    content = resolved_path.read_bytes()
    try:
        text = content.decode("utf-8")
    except UnicodeDecodeError as error:
        raise PilotError("pilot plan must be UTF-8") from error
    try:
        for token in yaml.scan(text):
            if isinstance(token, (AliasToken, AnchorToken, TagToken)):
                raise PilotError(
                    "pilot plan cannot contain YAML aliases, anchors, or tags"
                )
        raw = yaml.load(text, Loader=_UniqueKeyLoader)
        plan = PilotPlan.model_validate(raw)
    except PilotError:
        raise
    except Exception as error:
        raise PilotError("pilot plan is invalid") from error
    for case in plan.cases:
        project = (root / case.project_root).resolve(strict=True)
        policy = (root / case.policy_path).resolve(strict=True)
        _require_within(project, root, "pilot project")
        _require_within(policy, root, "pilot policy")
        if not project.is_dir() or (root / case.project_root).is_symlink():
            raise PilotError("pilot project must be a non-symlink directory")
        if not policy.is_file() or (root / case.policy_path).is_symlink():
            raise PilotError("pilot policy must be a non-symlink regular file")
    return LoadedPilotPlan(
        plan=plan,
        path=resolved_path,
        sha256=hashlib.sha256(content).hexdigest(),
    )


def _require_within(path: Path, root: Path, label: str) -> None:
    try:
        path.relative_to(root)
    except ValueError as error:
        raise PilotError(f"{label} escapes the repository root") from error


class PilotRunner:
    """Execute the reviewed CI wrapper and collect value-minimized pilot data."""

    def run(
        self,
        loaded: LoadedPilotPlan,
        *,
        repository_root: Path,
        agentsec_executable: Path,
        output_root: Path,
    ) -> PilotReport:
        root = repository_root.resolve(strict=True)
        executable = agentsec_executable.resolve(strict=True)
        runner = root / "scripts" / "run-agentsec-ci.sh"
        if not runner.is_file() or not os.access(runner, os.X_OK):
            raise PilotError("P2-29 CI Runner is unavailable")
        if not executable.is_file() or not os.access(executable, os.X_OK):
            raise PilotError("AgentSec executable is unavailable")
        if output_root.exists() and output_root.is_symlink():
            raise PilotError("pilot output root cannot be a symbolic link")
        output_root.mkdir(parents=True, exist_ok=True)

        results = tuple(
            self._run_case(
                case,
                root=root,
                runner=runner,
                executable=executable,
                output_root=output_root,
            )
            for case in loaded.plan.cases
        )
        metrics = _metrics(results)
        return PilotReport(
            status="complete" if metrics.failed_cases == 0 else "failed",
            pilot_id=loaded.plan.pilot_id,
            project_name=loaded.plan.project_name,
            owner=loaded.plan.owner,
            evidence_mode=loaded.plan.evidence_mode,
            plan_sha256=loaded.sha256,
            agentsec_executable=executable.name,
            metrics=metrics,
            cases=results,
            limitations=(
                (
                    "This checked-in run is an internal integration pilot, not "
                    "remote production repository evidence."
                ),
                (
                    "False-positive and false-negative metrics use reviewed "
                    "scenario-level unique Rule IDs, not runtime exploit labels."
                ),
                (
                    "Performance is local wall-clock integration latency and "
                    "varies by host and filesystem cache."
                ),
                (
                    "Static findings do not prove runtime Tool, OAuth, identity, "
                    "permission, or exploit reachability."
                ),
            ),
        )

    @staticmethod
    def _run_case(
        case: PilotCase,
        *,
        root: Path,
        runner: Path,
        executable: Path,
        output_root: Path,
    ) -> PilotCaseResult:
        case_output = output_root / case.case_id
        environment = os.environ.copy()
        environment["AGENTSEC_BIN"] = str(executable)
        started = time.perf_counter_ns()
        completed = subprocess.run(
            [
                str(runner),
                str(root / case.project_root),
                str(root / case.policy_path),
                str(case_output),
            ],
            cwd=root,
            env=environment,
            check=False,
            capture_output=True,
            text=True,
        )
        duration_ms = max(1, (time.perf_counter_ns() - started) // 1_000_000)
        json_path = case_output / "agentsec-assessment.json"
        sarif_path = case_output / "agentsec-results.sarif"
        observed_rules: tuple[str, ...] = ()
        observed_coverage: Literal["complete", "incomplete", "unavailable"] = (
            "unavailable"
        )
        if json_path.is_file() and json_path.stat().st_size:
            try:
                payload = json.loads(json_path.read_text(encoding="utf-8"))
                assessment = payload["assessment_report"]["assessment"]
                observed_rules = tuple(
                    sorted({item["rule_id"] for item in assessment["findings"]})
                )
                observed_coverage = (
                    "complete" if assessment["coverage"]["complete"] else "incomplete"
                )
            except (KeyError, TypeError, ValueError, json.JSONDecodeError):
                observed_rules = ()
                observed_coverage = "unavailable"
        expected = set(case.expected_rule_ids)
        observed = set(observed_rules)
        true_positive = tuple(sorted(expected & observed))
        false_positive = tuple(sorted(observed - expected))
        false_negative = tuple(sorted(expected - observed))
        decision_agreement = completed.returncode == case.expected_exit
        coverage_agreement = observed_coverage == case.expected_coverage
        detection_agreement = not false_positive and not false_negative
        performance_within_limit = duration_ms <= case.max_duration_ms
        sarif_valid = _sarif_is_valid(sarif_path)
        passed = (
            decision_agreement
            and coverage_agreement
            and detection_agreement
            and performance_within_limit
            and sarif_valid
        )
        return PilotCaseResult(
            case_id=case.case_id,
            title=case.title,
            expected_exit=case.expected_exit,
            observed_exit=completed.returncode,
            expected_coverage=case.expected_coverage,
            observed_coverage=observed_coverage,
            expected_rule_ids=case.expected_rule_ids,
            observed_rule_ids=observed_rules,
            true_positive_rule_ids=true_positive,
            false_positive_rule_ids=false_positive,
            false_negative_rule_ids=false_negative,
            duration_ms=duration_ms,
            max_duration_ms=case.max_duration_ms,
            json_bytes=json_path.stat().st_size if json_path.is_file() else 0,
            sarif_bytes=sarif_path.stat().st_size if sarif_path.is_file() else 0,
            sarif_valid=sarif_valid,
            decision_agreement=decision_agreement,
            coverage_agreement=coverage_agreement,
            detection_agreement=detection_agreement,
            performance_within_limit=performance_within_limit,
            passed=passed,
        )


def _sarif_is_valid(path: Path) -> bool:
    if not path.is_file() or not path.stat().st_size:
        return False
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return False
    return (
        isinstance(payload, dict)
        and payload.get("version") == "2.1.0"
        and isinstance(payload.get("runs"), list)
        and bool(payload["runs"])
    )


def _ratio(numerator: int, denominator: int) -> float:
    return round(numerator / denominator, 4) if denominator else 0.0


def _percentile(values: tuple[int, ...], percentile: float) -> int:
    ordered = tuple(sorted(values))
    index = max(0, min(len(ordered) - 1, int((len(ordered) - 1) * percentile + 0.5)))
    return ordered[index]


def _metrics(results: tuple[PilotCaseResult, ...]) -> PilotMetrics:
    durations = tuple(item.duration_ms for item in results)
    true_positives = sum(len(item.true_positive_rule_ids) for item in results)
    false_positives = sum(len(item.false_positive_rule_ids) for item in results)
    false_negatives = sum(len(item.false_negative_rule_ids) for item in results)
    precision_denominator = true_positives + false_positives
    recall_denominator = true_positives + false_negatives
    return PilotMetrics(
        cases=len(results),
        passed_cases=sum(item.passed for item in results),
        failed_cases=sum(not item.passed for item in results),
        true_positives=true_positives,
        false_positives=false_positives,
        false_negatives=false_negatives,
        precision=(
            _ratio(true_positives, precision_denominator)
            if precision_denominator
            else None
        ),
        recall=(
            _ratio(true_positives, recall_denominator) if recall_denominator else None
        ),
        decision_accuracy=_ratio(
            sum(item.decision_agreement for item in results), len(results)
        ),
        coverage_accuracy=_ratio(
            sum(item.coverage_agreement for item in results), len(results)
        ),
        detection_accuracy=_ratio(
            sum(item.detection_agreement for item in results), len(results)
        ),
        total_duration_ms=sum(durations),
        mean_duration_ms=round(sum(durations) / len(durations), 2),
        p50_duration_ms=_percentile(durations, 0.5),
        p95_duration_ms=_percentile(durations, 0.95),
        max_duration_ms=max(durations),
    )


def encode_pilot_report_json(report: PilotReport) -> str:
    """Encode a stable key-sorted report without source excerpts."""

    return (
        json.dumps(
            report.model_dump(mode="json"),
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
        + "\n"
    )


def render_pilot_report_markdown(report: PilotReport) -> str:
    """Render a compact pilot readout for developers and management."""

    metrics = report.metrics
    lines = [
        f"# AgentSec Pilot Report: {report.project_name}",
        "",
        f"- Pilot ID: `{report.pilot_id}`",
        f"- Status: **{report.status.upper()}**",
        f"- Evidence mode: `{report.evidence_mode}`",
        f"- Cases: {metrics.passed_cases}/{metrics.cases} passed",
        f"- Decision accuracy: {metrics.decision_accuracy:.2%}",
        f"- Detection accuracy: {metrics.detection_accuracy:.2%}",
        f"- Precision: {_metric_text(metrics.precision)}",
        f"- Recall: {_metric_text(metrics.recall)}",
        f"- FP/FN: {metrics.false_positives}/{metrics.false_negatives}",
        f"- Performance p50/p95/max: {metrics.p50_duration_ms}/"
        f"{metrics.p95_duration_ms}/{metrics.max_duration_ms} ms",
        "",
        "| Case | Exit E/O | Coverage E/O | Rules E/O | Duration | Result |",
        "|---|---:|---|---:|---:|---|",
    ]
    for item in report.cases:
        lines.append(
            f"| {item.case_id} | {item.expected_exit}/{item.observed_exit} | "
            f"{item.expected_coverage}/{item.observed_coverage} | "
            f"{len(item.expected_rule_ids)}/{len(item.observed_rule_ids)} | "
            f"{item.duration_ms} ms | {'PASS' if item.passed else 'FAIL'} |"
        )
    lines.extend(["", "## Limitations", ""])
    lines.extend(f"- {item}" for item in report.limitations)
    return "\n".join(lines) + "\n"


def _metric_text(value: float | None) -> str:
    return "N/A" if value is None else f"{value:.2%}"


def export_pilot_plan_schema() -> str:
    """Export the strict pilot plan JSON Schema."""

    return json.dumps(PilotPlan.model_json_schema(), indent=2, sort_keys=True) + "\n"


def export_pilot_report_schema() -> str:
    """Export the strict pilot report JSON Schema."""

    return json.dumps(PilotReport.model_json_schema(), indent=2, sort_keys=True) + "\n"


def export_pilot_json_schemas(output_dir: Path) -> tuple[Path, Path]:
    """Write both public pilot Schemas to a caller-selected directory."""

    output_dir.mkdir(parents=True, exist_ok=True)
    plan_path = output_dir / "pilot-plan.schema.json"
    report_path = output_dir / "pilot-report.schema.json"
    plan_path.write_text(export_pilot_plan_schema(), encoding="utf-8")
    report_path.write_text(export_pilot_report_schema(), encoding="utf-8")
    return plan_path, report_path
