# Changelog

## 0.2.0 — 2026-08-20 — Phase 2 Integration MVP

### Added

- reviewed Simplified Chinese trigger variants for all 15 stable Markdown Rules;
- `agentsec rules list --language zh`;
- Chinese positive and benign negative regression for every Rule ID;
- five inert Chinese corpus Cases, bringing the current corpus to 45 Cases;
- fully Chinese Release Agent baseline, drift, injection, and remediation Demo.

### Changed

- Rule Pack `0.2.0` → `0.3.0`; Rule IDs and risk meanings remain stable.

### P2-01 structured Parser foundation

- add one deep `StructuredParser` interface and normalized source-backed node
  model;
- add deterministic JSON, safe YAML, and TOML Parser adapters;
- add duplicate-key, unsafe YAML, malformed input, source-location, determinism,
  and parser resource-limit regression tests;
- add Phase 2 Scope, ADR-0018, and structured Parser documentation;
- keep structured-file discovery, Agent Manifest, capability mapping, rules, and
  LLM analysis deferred to later Phase 2/3 tasks.

### P2-02 Rules and MCP specialized Parsers

- add a strict non-executing Parser for literal Codex `prefix_rule(...)`
  declarations and inline examples;
- add static MCP declaration parsing for top-level and plugin-bundled server
  tables, STDIO, Streamable HTTP, environment references, tool filters, approval
  modes, and timeouts;
- omit static environment/header values and URL query/fragment values from the
  specialized MCP model;
- retain unknown direct MCP fields by source location without copying values;
- add 34 targeted Rules/MCP parsing, malicious-expression, no-execution,
  no-network, secret-omission, line-location, limit, and determinism tests;
- add ADR-0019 and specialized Parser documentation.

### P2-03 Framework Adapter interface

- add a one-method `FrameworkAdapter.inspect()` Protocol with stable Adapter
  identity and version provenance;
- add portable project/user/plugin locators, neutral Asset roles and formats,
  precedence hints, parser-coherent records, and explicit Coverage models;
- validate deterministic ordering, uniqueness, line-count coherence, role/format
  compatibility, and MCP-role consistency;
- verify two independent fake Adapters through the same interface;
- keep framework inspection output separate from Phase 1 RuleContext and risk
  processing;
- add ADR-0020 and Framework Adapter interface documentation.

### P2-04 Codex Adapter

- add the first production `FrameworkAdapter` implementation for Codex;
- add explicit working-directory context to Framework inspection requests;
- discover project-chain and explicit user-scope Agent, Skill, `.rules`, TOML,
  and MCP configuration assets;
- preserve both base and Override instructions and deterministic precedence
  hints for later effective-configuration resolution;
- enforce root containment, internal-only symbolic links, bounded reads, strict
  UTF-8, depth limits, global asset limits, deterministic ordering, and explicit
  Coverage;
- keep commands, URLs, environment references, Skills, Rules, plugins, and MCP
  servers inert, with no LLM or network access;
- add ADR-0021, Codex Adapter documentation, and targeted discovery,
  non-execution, parser, limit, symlink, precedence, and Coverage tests.

### P2-05 Agent Manifest Schema

- add independent Agent Manifest Schema `0.1.0` without changing frozen Phase 1
  Domain, Baseline, Diff, Assessment, Rule Pack, or Risk Model versions;
- add strict immutable models for subject identity, portable sources,
  instruction candidates, tools, permissions, controls, runtime identities,
  relationships, Unknowns, and Manifest Coverage;
- add explicit unresolved/partial/resolved/unknown/not-applicable/conflict state
  so empty fields cannot silently imply absence or safety;
- add `AgentManifestBuilder` to normalize Framework source metadata, Coverage,
  instruction candidates, and future declaration sources without copying parsed
  source values;
- add deterministic JSON encoding, compatibility-first safe validation, and
  Draft 2020-12 JSON Schema export;
- add ADR-0022, Agent Manifest documentation, domain glossary terms, and
  targeted schema, provenance, safety, ordering, compatibility, and integration
  tests.

### P2-06 Instruction Inheritance / Override Resolver

- add deterministic `InstructionResolver` over Agent Manifest candidates;
- resolve same-directory Base/Override slots without reading instruction text;
- preserve user-before-project and root-before-nested application order;
- add `effective_order`, `overridden_sources`, and `resolution_trace`;
- mark incomplete Coverage as `partial` and fail closed for ambiguous candidates;
- increment Agent Manifest Schema `0.1.0` → `0.2.0`;
- add ADR-0023, Resolver documentation, and inheritance/security tests.

### P2-07 Configuration Precedence Resolver

- add source-level `ManifestConfigurationProfile` and configuration candidate
  kinds for Framework, Rules, and MCP sources;
- add deterministic `ConfigurationResolver` with user/project scope, precedence
  rank, portable path, and chain-key ordering;
- preserve canonical `effective_sources`, semantic `effective_order`, and a
  source-level resolution trace;
- mark incomplete configuration Coverage as `partial` and fail closed for
  duplicate candidate identities;
- keep field-level TOML/Rules/MCP value merging out of P2-07;
- increment Agent Manifest Schema `0.2.0` → `0.3.0`;
- add ADR-0024, Configuration Resolver documentation, and source-order,
  Coverage, no-value-read, and determinism tests.

### P2-08 Skill / MCP / Tool Association

- add deterministic `AssociationExtractor` (and `AssociationResolver` alias)
  over the existing Agent Manifest and Framework inspection seam;
- associate Skills, static MCP servers, and MCP tool filters/policies with
  source-backed `ManifestTool` items;
- add `uses_skill`, `uses_mcp`, and `uses_tool` relationships with declared
  state and exact field/line provenance;
- classify only conservative static MCP potential side effects: STDIO execute,
  Streamable HTTP network, and plugin-bundled unknown;
- normalize stable IDs with bounded collision disambiguation;
- retain explicit partial status for incomplete inspection Coverage;
- keep commands, endpoints, environment values, headers, Skill bodies, runtime
  enumeration, permissions, risk, and LLM analysis outside the boundary;
- keep Agent Manifest Schema at `0.3.0` because no serialized fields changed;
- add ADR-0025, association documentation, and five targeted regression tests.

### P2-09 Static Capability Profile

- add deterministic `CapabilityExtractor` for existing permission, control, and
  runtime identity Manifest profiles;
- map known Skill/MCP/tool side effects into conservative read/write/execute/
  network/secret/admin/unknown permission facts;
- map explicit `.rules` decisions into allow/prompt/deny execute permissions and
  Prefix Rule controls without evaluating commands;
- add MCP enablement, required, approval, tool-filter, timeout, network-policy,
  and secret-handling controls with field/line provenance;
- add credential-free MCP runtime identity hypotheses for OAuth, ChatGPT,
  bearer/environment, plugin-bundled, local, and external evidence;
- keep permission effect separate from Tool availability and runtime identity
  separate from attestation;
- preserve `partial` for incomplete Coverage or uncertain/unsupported facts;
- keep Agent Manifest Schema at `0.3.0` because no serialized fields changed;
- add ADR-0026, static capability documentation, and two targeted regression
  tests.

### P2-10 Sub-Agent / Memory Relationships

- add deterministic `RelationshipExtractor` (and `RelationshipResolver` alias)
  for explicit Markdown frontmatter declarations;
- associate delegation aliases with `delegates_to`;
- associate memory read/write/persist aliases and nested `memory` declarations
  with the existing memory relationship kinds;
- retain P2-08 Skill/MCP/tool relations and merge duplicate logical edges with
  deterministic source provenance;
- hash unsafe paths, URLs, control-character, whitespace, and oversized targets
  into bounded unknown IDs without serializing raw values;
- mark malformed/unsupported declarations and unsafe targets as partial/unknown;
- expand relationship declaration-source roles to Markdown instructions,
  Overrides, Skills, and MCP configuration;
- keep Agent Manifest Schema at `0.3.0` because no serialized fields changed;
- add ADR-0027, relationship documentation, and five targeted regression tests.

### P2-11 Explicit Unknowns and Capability Diff

- add idempotent `UnknownExtractor` (and `UnknownResolver` alias) for profile and
  item uncertainty, runtime verification requirements, and incomplete Coverage;
- map stable Unknown dimensions/reasons without copying source values;
- add versioned `CapabilityDiffer` for Tool, Permission, Control, Runtime
  Identity, Relationship, Unknown, profile-status, and Coverage changes;
- emit added/removed/modified entries with stable IDs, changed-field names,
  SHA-256 fingerprints, and before/after source provenance instead of full item
  values;
- preserve visible changes while marking Diff incomplete if either Manifest has
  incomplete Coverage;
- add independent `CAPABILITY_DIFF_SCHEMA_VERSION = 0.1.0`, deterministic JSON,
  compatibility-first validation, safe errors, and Draft 2020-12 Schema export;
- keep Agent Manifest Schema at `0.3.0` and Phase 1 Diff Output at `0.1.0`;
- add ADR-0028, Unknown/Capability Diff documentation, and five targeted tests.

### P2I-01 Full Agent Analysis Pipeline

- add injectable `AgentAnalysisPipeline` and `AgentAnalysisEngine` application
  seam for one-call P2-04 through P2-11 orchestration;
- add explicit request roots/limits, final Manifest result, current version
  vector, and bounded nine-stage operational trace;
- add safe required-stage error codes without copying dependency diagnostics;
- add `CapabilityExtractor.extract_associated()` and
  `RelationshipExtractor.extract_associated()` while preserving existing public
  `extract()` behavior;
- ensure Association extraction runs once inside the integrated Pipeline;
- retain valid Partial Manifest results and explicit Unknowns for incomplete
  Coverage;
- keep Agent Manifest, Capability Diff, Phase 1 Domain, Rule Pack, Risk Model,
  CLI, and enforcement versions unchanged;
- add Pipeline documentation and deterministic/order/partial/error-safety
  regression tests.

### P2I-02 Deterministic Capability Rule Pack

- add an independent framework-neutral `CapabilityRule` seam over finalized
  Agent Manifests;
- add immutable deterministic context indexes for Tools, Permissions, Controls,
  Runtime Identities, parent/child Tools, Relationships, Unknowns, and Sources;
- add Capability Rule Pack `0.1.0` with six stable bilingual Rule IDs for
  approval, execution/secret/network chain, Coverage, delegation, external MCP,
  and persistence risk;
- add Capability Risk Model `0.1.0` with correlation-based Evidence Confidence
  and static likelihood, NIST matrix scoring, FIPS-style high-water-mark impact,
  and FIRST CVSS Severity ranges;
- prefer same-target and MCP parent/child correlation, avoid Agent-wide Cartesian
  products, and lower Agent-wide/incomplete evidence to D Confidence;
- add value-free hash-backed evidence and deterministic Finding identity without
  source excerpts, commands, URLs, Headers, environment values, or credentials;
- add atomic per-Rule failure isolation and deterministic result ordering;
- keep `hard_gate=false`, CI blocking disabled, Phase 1 Rule/Risk versions
  unchanged, and no LLM/runtime/network/MCP behavior;
- add ADR-0029, Capability Rule documentation, version documentation, and
  positive/negative/Unknown/determinism/failure-isolation tests.

### P2I-03 Manifest, Capability Assessment, and Capability Diff Reports

- add `ManifestTextRenderer` and canonical `ManifestJsonRenderer`;
- add `CapabilityDiffTextRenderer` and canonical `CapabilityDiffJsonRenderer`;
- add `CapabilityAssessmentEngine` application composition for the full analysis
  Pipeline plus deterministic Capability Rule Pack;
- add independently versioned Capability Assessment Output `0.1.0` with strict
  JSON wrapper, derived summary/status validation, fixed report-only policy,
  canonical embedded Manifest, Findings, Stage Trace, and Rule failures;
- add deterministic Draft 2020-12 Capability Assessment Schema export and
  compatibility-first safe validation errors;
- add English and Simplified Chinese Text presentation for management summary and
  developer evidence;
- add per-section Text bounds, explicit omitted counts, secret redaction, and
  untrusted-text sanitization;
- retain Agent Manifest Schema `0.3.0`, Capability Diff Schema `0.1.0`, Phase 1
  Assessment Output `0.2.0`, and report-only/no-runtime-proof boundaries;
- add ADR-0030, report documentation, version documentation, and complete/partial/
  localization/determinism/non-disclosure tests.

### P2I-04 Manifest and Capability CLI

- add `agentsec manifest` with explicit project/working/user/Codex roots, Agent
  ID, Text/JSON, English/Chinese, output, and restricted force options;
- add `agentsec capability assess`, `capability diff`, and bilingual
  `capability rules list`;
- add `DeterministicManifestCapabilityDiffEngine` application seam;
- add bounded no-follow compatibility-first Agent Manifest file input;
- add kind-validated `.json`/`.txt` mode-0600 atomic report output;
- make no-clobber the default and limit `--force` to an existing valid artifact
  of the same kind and format;
- reject Diff output paths that equal either Manifest input;
- add `ARTIFACT_ERROR` as numeric exit-code-4 alias while retaining report-only
  Finding exit `0`, incomplete exit `2`, and reserved risk-policy exit `1`;
- add ADR-0031, CLI guide, help/exit/security documentation, and end-to-end CLI/
  storage regression tests;
- keep all Schema, Output, Rule Pack, Risk Model, and frozen distribution
  versions unchanged pending a separate Phase 2 release task.

### P2I-05 Capability Drift Story Demo

- add inert English and Chinese baseline, risky-drift, incomplete, and
  remediated Release Agent capability projects;
- demonstrate seven Findings across six Capability Rule IDs with highest High,
  complete Capability Diff, incomplete exit `2`, and remediation back to zero
  Findings;
- add live automated and seven-stage presenter runners with language, pause,
  output-directory, and offline options;
- add deterministic frozen Manifest, Capability Assessment, Capability Diff,
  localized Text, management summary, and SHA-256 checksum artifacts for both
  languages;
- add semantic validation for report-only policy, Coverage, Rule IDs, Diff,
  remediation, and synthetic secret/endpoint non-disclosure;
- add developer/management scripts, bilingual acceptance records, documentation,
  and E2E tests;
- keep all Schema, Output, Rule Pack, Risk Model, Hard Gate, enforcement, and
  frozen Phase 1 distribution versions unchanged.

### Phase 2 Integration Hardening and Release Review

- increment Package `0.1.0` → `0.2.0` while retaining every independent Schema,
  Output, Rule Pack, and Risk Model version;
- sanitize malicious Manifest/Capability Diff validation location keys;
- enforce no-follow regular-file reads when validating `--force` replacement;
- freeze Agent Manifest, Capability Diff, and Capability Assessment JSON Schemas;
- make build/install scripts derive the current source version and verify Phase 1
  plus Phase 2 CLI paths offline;
- add ADR-0032, 0.2.0 release notes, known limitations, acceptance evidence, and
  preserved version-specific artifacts under `dist/0.2.0/`.

### Distribution boundary

The accepted 0.1.0 wheel/sdist remain preserved at the `dist/` root. AgentSec
0.2.0 artifacts and checksums are stored separately under `dist/0.2.0/`. No
remote publication, Git tag, or production deployment is claimed.

## 0.1.0 — 2026-08-19

First Phase 1 Markdown static-scanning PoC release.

### Added

- installable `agentsec` Python package and console entry point;
- `version`, `scan`, `baseline create`, `diff`, and `rules list` commands;
- safe Markdown collection, path containment, resource limits, CommonMark
  parsing, frontmatter/reference extraction, and obfuscation indicators;
- versioned Baseline Schema, atomic Baseline writer, Asset Diff, and bounded Text
  Diff;
- 15 deterministic Markdown Rules with isolated failure Coverage;
- NIST-style preliminary risk, high-water-mark Impact, 0–10 score, Severity,
  A/B/C/D Evidence Confidence, and report-only Hard Gate metadata;
- ANSI-free Rich Text and strict `agentsec-assessment` JSON reports;
- shared hardened secret redaction and control-character escaping;
- explicit Coverage reporting and stable exit codes;
- 40-Case Safe/Risky/Prompt Injection/Malformed corpus;
- frozen JSON Schemas;
- Release Agent developer/management Demo with offline fallback;
- README, complete PoC usage guide, release notes, known limitations, and
  acceptance records.

### Security policy

```text
enforcement_mode=report_only
ci_blocking_enabled=false
global_safety_claimed=false
```

### Compatibility vector

```text
Package 0.1.0
Config Schema 0.1.0
Domain Schema 0.3.0
Baseline Schema 0.1.0
Diff Output 0.1.0
Assessment Output 0.2.0
Rule Pack 0.2.0
Risk Model 0.4.0
```
