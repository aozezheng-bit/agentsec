# AgentSec Phase 2 Integration Closure Plan

- Status: Integration implementation complete; hardening pending
- Date: 2026-08-20
- Scope: Full analysis pipeline, Manifest/Capability Diff CLI, Text/JSON reports,
  Capability Drift Demo, and deterministic combination-risk rules
- Current foundation: P2-01 through P2-11 and P2I-01～P2I-05 complete
- Primary audiences: developers, security reviewers, and management

## 1. Objective

Turn the completed Phase 2 static-analysis modules into one usable product path:

```text
Project / explicit user roots
→ AgentAnalysisPipeline
→ final Agent Manifest
→ deterministic capability Findings
→ Manifest Text/JSON Report
→ saved before/after Manifest
→ Capability Diff Text/JSON Report
→ repeatable Capability Drift Demo
```

The integration must preserve these boundaries:

```text
no scanned execution
no MCP connection
no network access
no environment or credential value read
no memory-store access
no LLM requirement
report-only by default
incomplete Coverage never appears clean
```

## 2. Recommended delivery order

Although the product features are commonly described as Pipeline → CLI → Report
→ Demo → Rules, the lowest-rework implementation order is:

```text
P2I-01 Full AgentAnalysisPipeline
P2I-02 Capability Rule seam and initial combination Rule Pack
P2I-03 Manifest / Capability Assessment / Capability Diff reports
P2I-04 Manifest and Capability CLI integration
P2I-05 Capability Drift Demo and acceptance
```

Rules precede final report/CLI contracts because Findings, summaries, version
metadata, and exit policy must be known before freezing report schemas.

## 3. Target architecture

```text
CLI
├── agentsec manifest
├── agentsec capability assess
└── agentsec capability diff
        │
        ▼
Application services
├── AgentAnalysisPipeline
├── CapabilityAssessmentEngine
└── ManifestCapabilityDiffEngine
        │
        ▼
Deterministic core
├── CodexAdapter
├── AgentManifestBuilder
├── InstructionResolver
├── ConfigurationResolver
├── AssociationExtractor
├── CapabilityExtractor
├── RelationshipExtractor
├── UnknownExtractor
├── CapabilityRuleRunner
└── CapabilityDiffer
        │
        ▼
Delivery
├── ManifestTextRenderer / canonical Manifest JSON
├── CapabilityAssessmentTextRenderer / JSON
└── CapabilityDiffTextRenderer / canonical Capability Diff JSON
```

The application layer owns orchestration. Framework Adapters, Manifest models,
Rules, and Diff remain independent deep modules.

---

# 4. P2I-01: AgentAnalysisPipeline

- Status: Complete (2026-08-20)

## 4.1 Public request/result

Recommended module:

```text
src/agentsec/application/agent_analysis.py
```

Recommended interfaces:

```python
@dataclass(frozen=True, slots=True)
class AgentAnalysisRequest:
    project_root: Path
    working_directory: Path | None = None
    user_home: Path | None = None
    codex_home: Path | None = None
    agent_id: str | None = None
    limits: FrameworkInspectionLimits = FrameworkInspectionLimits()


@dataclass(frozen=True, slots=True)
class AgentAnalysisResult:
    manifest: AgentManifest
    stages: tuple[AnalysisStageResult, ...]
    complete: bool
    versions: VersionSet


class AgentAnalysisEngine(Protocol):
    def analyze(self, request: AgentAnalysisRequest) -> AgentAnalysisResult: ...
```

`FrameworkInspectionResult` may be retained internally for later stages, but it
should not be exposed by default in reports because it contains parser-backed
in-memory values that require separate redaction review.

## 4.2 Pipeline order

```text
1. CodexAdapter.inspect
2. AgentManifestBuilder.build
3. InstructionResolver.resolve
4. ConfigurationResolver.resolve
5. AssociationExtractor.extract
6. CapabilityExtractor.extract
7. RelationshipExtractor.extract
8. UnknownExtractor.extract
9. AgentManifest final validation
```

## 4.3 Avoid repeated extraction

Current P2-09 and P2-10 compatibility APIs can rerun P2-08 association. During
integration, preserve their public APIs but add internal already-normalized
entry points, for example:

```python
CapabilityExtractor.extract_associated(manifest, inspection)
RelationshipExtractor.extract_associated(manifest, inspection)
```

The Pipeline should invoke every semantic stage once. Regression tests should
use spies/counters to prevent accidental duplicate work.

## 4.4 Stage trace

Every stage should emit safe operational metadata:

```text
stage
status: completed / partial / skipped / failed
input item count
output item count
safe error code
```

Do not include source text, exception text from dependencies, commands, URLs, or
secret-bearing values.

## 4.5 Failure policy

| Condition | Behavior |
|---|---|
| Coverage issue | Return a valid partial Manifest and exit-equivalent `2` |
| Unsupported/unknown declaration | Preserve partial + ManifestUnknown |
| Incompatible internal Manifest | Fail with safe stage/code |
| Adapter catastrophic failure | Required analysis failure |
| Rule failure later | Isolate per Rule; preserve other Findings and Coverage |

## 4.6 Acceptance criteria

- one call produces the final P2-11 Manifest;
- repeated calls over identical input are byte-deterministic except where the
  future wrapper deliberately includes timestamps;
- no stage executes scanned content;
- every stage is invoked once;
- incomplete inspection produces a usable partial result;
- direct stage APIs remain backward compatible;
- targeted, integration, Ruff, Mypy, and full Pytest pass.

---

# 5. P2I-02: Deterministic Combination-Risk Rules

- Status: Complete (2026-08-20)

## 5.1 Separate Rule seam

Do not force Manifest rules into the existing Markdown `RuleContext`. Add a
framework-neutral capability Rule seam:

```text
src/agentsec/capability_rules/base.py
src/agentsec/capability_rules/pipeline.py
src/agentsec/capability_rules/builtin.py
```

Recommended interface:

```python
@dataclass(frozen=True, slots=True)
class CapabilityRuleContext:
    manifest: AgentManifest
    tools_by_id: Mapping[str, ManifestTool]
    permissions_by_target: Mapping[str, tuple[ManifestPermission, ...]]
    controls_by_target: Mapping[str, tuple[ManifestControl, ...]]
    identities_by_tool: Mapping[str, tuple[ManifestRuntimeIdentity, ...]]
    child_tools_by_parent: Mapping[str, tuple[ManifestTool, ...]]
    relations_by_kind: Mapping[ManifestRelationKind, tuple[ManifestRelation, ...]]
    unknowns_by_dimension: Mapping[
        ManifestUnknownDimension, tuple[ManifestUnknown, ...]
    ]


class CapabilityRule(Protocol):
    metadata: CapabilityRuleMetadata

    def evaluate(self, context: CapabilityRuleContext) -> CapabilityRuleEvaluation: ...
```

The context contains only the finalized Manifest. It has no filesystem, command,
network, environment, MCP, memory, import, or LLM dependencies.

## 5.2 Correlation rule

Avoid naive Agent-wide Cartesian combinations. Rules should prefer:

```text
same Tool target
same MCP Server
MCP parent/child Tool relationship
same Source declaration
explicit Agent relationship
```

Agent-wide combinations may be emitted only with lower Evidence Confidence and
an explicit explanation that reachability between capabilities is unverified.

## 5.3 Independent versions

Implemented independent versions:

```text
CAPABILITY_RULE_PACK_VERSION = 0.1.0
CAPABILITY_RISK_MODEL_VERSION = 0.1.0
```

Do not silently redefine the frozen Phase 1 Markdown Rule Pack or Risk Model.
Formal integration into the common Assessment model should receive a separate
Version Impact Review.

## 5.4 Initial reviewed Rule Pack

### `CAP-CHAIN-001`: Execute + Secret + External Network

Condition:

```text
execute permission
+ secret_access permission
+ external network permission
correlated to the same MCP Server or parent/child tool set
```

Meaning: the declarations form a potential local execution → credential access
→ external transmission chain.

Recommended classification:

```text
Category: secret_access / network_access
Likelihood: Moderate for same target, Low for Agent-wide only
Impact: Very High
Initial Severity: High
Hard Gate: false in first report-only release
```

### `CAP-APPROVAL-001`: State-changing capability without effective prompt

Condition:

```text
write / execute / deploy / publish / admin
+ enablement not disabled
+ approval control allow/unknown or missing
```

Meaning: a state-changing capability lacks an explicit human confirmation
control in the static profile.

### `CAP-PERSIST-001`: Persistent memory combined with sensitive capability

Condition:

```text
persists_memory
+ secret_access, external network, write, or privileged/admin capability
```

Meaning: sensitive data or instructions may survive beyond one task/session.

### `CAP-DELEGATE-001`: Delegation into powerful capability without approval

Condition:

```text
delegates_to
+ execute/admin/deploy/publish/persist capability
+ no prompt/deny approval evidence
```

Current limitation: until a Sub-Agent Manifest is independently available, this
is Agent-level correlation and should use lower confidence.

### `CAP-EXTERNAL-001`: Enabled required external MCP with credentialed identity

Condition:

```text
MCP server enabled
+ required
+ environment/OAuth/ChatGPT authentication
+ external network scope
```

Meaning: the Agent declares a mandatory external integration with a credentialed
identity.

### `CAP-COVERAGE-001`: High-impact capability under incomplete analysis

Condition:

```text
execute/network/secret/admin/deploy/persist capability
+ Coverage incomplete or relevant Unknowns
```

Meaning: a sensitive capability is visible while the full capability set or
controls could not be determined. This is a Coverage Finding, not proof of an
exploit.

## 5.5 Evidence and confidence

Capability Findings should use Manifest source references directly. Recommended
evidence fields:

```text
scope
root_id
path
field_path
start_line
end_line
content_sha256 resolved from Manifest.sources
```

Do not require a raw excerpt. Evidence Confidence remains independent from
Severity:

```text
B: exact same-target static combination
C: parent/child or explicit relation correlation
D: Agent-wide correlation or incomplete Coverage
```

## 5.6 Rule acceptance

Every Rule requires:

- stable Rule ID and immutable meaning;
- one positive same-target test;
- one safe negative test;
- one incomplete/Unknown test;
- one ordering/determinism test;
- source provenance assertions;
- no critical result diluted by averaging;
- no CI blocking in the first release.

---

# 6. P2I-03: Text and JSON Reports

- Status: Complete (2026-08-20)
- Decision: `docs/decisions/0030-capability-assessment-report-contract.md`
- Detailed design: `docs/capability-reports.md`

## 6.1 Keep canonical artifacts separate from presentation

Use three artifacts:

```text
AgentManifest                 schema 0.3.0
CapabilityDiffResult          schema 0.1.0
CapabilityAssessmentReport    new report wrapper
```

For Manifest and Diff JSON, use existing canonical codecs rather than creating a
second JSON representation:

```python
encode_agent_manifest_json(manifest)
encode_capability_diff_json(diff)
```

Combination-risk Findings require a new wrapper, recommended version:

```text
CAPABILITY_ASSESSMENT_OUTPUT_VERSION = 0.1.0
```

## 6.2 Manifest Text Report

Recommended sections:

```text
Agent and Framework
Version vector
Coverage and stage status
Profile resolution matrix
Effective instruction sources
Tools and MCP parent/child tree
Permissions
Controls
Runtime identities
Relationships
Explicit Unknowns
Boundary statement
```

Suggested summary:

```text
Agent: release-agent
Framework: Codex
Coverage: COMPLETE
Profiles: 6 resolved / 1 partial / 1 unknown
Tools: 5
Permissions: execute=1 network=1 secret=1 unknown=2
Controls: approval=prompt enablement=enabled
Relations: delegates=1 persists_memory=1
Unknowns: 4
```

## 6.3 Capability Diff Text Report

Recommended sections:

```text
Before/after Manifest versions
Completeness warning
Added/removed/modified counts
Profile transitions
Changes grouped by dimension
Changed fields
Before/after source locations
Before/after value-omission boundary
```

Example:

```text
[MODIFIED] tool mcp-server:release
  availability: enabled → disabled
  source: .codex/config.toml:2-8

[ADDED] permission permission:network:mcp-server:telemetry
  scope: external
  source: .codex/config.toml:10-14
```

The renderer may display before/after enum values only after a separate output
safety review. The canonical Capability Diff artifact currently exposes field
names and hashes, not full values.

## 6.4 Capability Assessment Report

Recommended summary:

```text
Finding count
highest Severity
Hard Gate matches
Evidence Confidence distribution
Coverage completeness
high-impact capability counts
version vector
report-only policy
```

The JSON wrapper should include:

```text
format
format_version
status
versions
policy
summary
manifest
findings
stage_trace
rule_failures
```

## 6.5 Output safety and limits

- Text rendering always uses the shared `SecretRedactor` and
  `sanitize_untrusted_text` boundary.
- Canonical JSON uses strict already-normalized models and version validation.
- Text sections have display limits, for example 100 items per section, with
  explicit omitted counts.
- JSON remains complete within parser/inspection resource limits.
- No ANSI in redirected output.
- Every incomplete report contains persistent visible wording; not only color.

## 6.6 Report acceptance

- deterministic Text and JSON ordering;
- JSON Schema export and validation;
- no raw Secret/Command/URL query/environment value;
- complete and partial snapshots;
- management summary under one screen;
- developer detail includes exact source provenance;
- no global safety claim;
- report-only policy is explicit.

---

# 7. P2I-04: Manifest and Capability CLI

- Status: Complete (2026-08-20)
- Decision: `docs/decisions/0031-manifest-capability-cli-artifact-io.md`
- User/developer guide: `docs/capability-cli.md`

## 7.1 Recommended command surface

```bash
agentsec manifest PROJECT [OPTIONS]
agentsec capability assess PROJECT [OPTIONS]
agentsec capability diff --before BEFORE.json --after AFTER.json [OPTIONS]
agentsec capability rules list [--language en|zh]
```

### Manifest

```bash
agentsec manifest . --format text
agentsec manifest . --format json --output agent-manifest.json
```

Options:

```text
--working-directory PATH
--user-home PATH
--codex-home PATH
--agent-id ID
--format text|json
--output PATH
--force
```

User/Codex roots remain explicit. Do not infer a home directory from process
environment in the application core.

### Capability assessment

```bash
agentsec capability assess . --format text
agentsec capability assess . --format json --output capability-assessment.json
```

Runs Pipeline + deterministic capability Rule Pack.

### Capability Diff

```bash
agentsec capability diff \
  --before baseline.manifest.json \
  --after risky.manifest.json \
  --format text
```

Version 1 should compare two validated Manifest files. A later convenience mode
may scan the current project against a saved Manifest, but it should not be
combined into the first CLI task.

## 7.2 Application services

Recommended modules:

```text
src/agentsec/application/agent_analysis.py
src/agentsec/application/capability_assessment.py
src/agentsec/application/capability_diff.py
src/agentsec/cli/manifest.py
src/agentsec/cli/capability.py
```

CLI functions perform argument/config translation and output only. They should
not construct the semantic pipeline inline.

## 7.3 Artifact I/O

Add bounded, atomic file adapters:

```text
AgentManifestFileReader / Writer
CapabilityDiffFileWriter (optional; stdout is canonical)
CapabilityAssessmentFileWriter
```

Rules:

- compatibility-first validation;
- bounded file size before JSON decode;
- atomic temporary-file replace;
- no overwrite unless `--force`;
- no full rejected payload in errors;
- output parent symlink/path policy reviewed.

## 7.4 Exit codes

Reuse current meanings:

| Outcome | Exit |
|---|---:|
| Complete report-only analysis | `0` |
| Risk Findings in report-only mode | `0` |
| Incomplete Coverage / incomplete Diff | `2` |
| Invalid config/options | `3` |
| Invalid/incompatible before Manifest | `4` |
| Required analysis failure | `5` |
| Usage error | `64` |

Exit `1` remains reserved for a future explicit risk-threshold policy. Do not
activate it as part of this integration.

## 7.5 CLI acceptance

- help text documents declaration-vs-runtime boundary;
- Text and JSON both work through normal production services;
- stdout contains only requested output; errors use stderr;
- JSON redirects cleanly to a file;
- complete returns `0`, incomplete returns `2`;
- findings remain report-only;
- Manifest files round-trip through validation;
- Capability Diff rejects different Agent IDs and incompatible schemas;
- all command paths have Typer integration tests.

---

# 8. P2I-05: Capability Drift Story Demo

- Status: Complete and accepted (2026-08-20)
- Detailed guide: `docs/capability-drift-demo.md`
- English assets: `demos/capability-drift-agent/`
- Chinese assets: `demos/capability-drift-agent-zh/`

## 8.1 Story

Use a Release Agent or Change Agent that begins with a reviewed local profile,
then gains a dangerous capability chain through configuration drift.

### Baseline

```text
one review Skill
local-only behavior
Prefix Rule requires prompt
no remote MCP
no environment credential reference
no persistent memory
no Sub-Agent delegation
```

Expected:

```text
Coverage complete
Manifest generated
no combination-risk Findings
```

### Risky drift

Add:

```text
STDIO MCP with execute potential
remote HTTP MCP
bearer/environment credential reference
approval mode auto
enabled write/publish tool
Sub-Agent delegation to deployer
persistent release memory
```

Expected Capability Diff:

```text
new MCP Servers and Tools
new execute/network/secret permissions
approval control prompt → allow or missing
new external runtime identity
new delegates_to relation
new persists_memory relation
new/changed Unknowns if any
```

Expected combination Findings:

```text
Execute + Secret + External Network
State-changing capability without prompt
Persistent memory + sensitive capability
Delegation + powerful capability
Credentialed required external MCP
```

### Remediation

```text
remove remote MCP and environment credential reference
restore prompt approval
remove persistent memory
remove deployment delegation
restrict/disable write tool
```

Expected:

```text
Capability Diff visibly removes risky capabilities
combination Findings return to zero or accepted low residual state
Coverage complete
```

## 8.2 Demo command flow

```bash
agentsec manifest demos/capability-drift/baseline \
  --format json --output /tmp/baseline.manifest.json

agentsec capability assess demos/capability-drift/risky \
  --format text

agentsec manifest demos/capability-drift/risky \
  --format json --output /tmp/risky.manifest.json

agentsec capability diff \
  --before /tmp/baseline.manifest.json \
  --after /tmp/risky.manifest.json \
  --format text

agentsec capability assess demos/capability-drift/remediated \
  --format text
```

## 8.3 Presenter flow

Recommended seven-minute story:

```text
1. Show the reviewed baseline Manifest
2. Show the risky configuration changes
3. Show Capability Diff, not just file Diff
4. Show deterministic combination Findings
5. Explain source provenance and confidence
6. Apply remediation
7. Show capability removal and zero/high-risk reduction
8. Close with report-only and static-analysis boundaries
```

## 8.4 Developer and management views

Developer view:

```text
Tool/Permission/Control/Identity/Relation IDs
changed fields
source paths, fields, and lines
Rule IDs and exact correlated facts
Coverage and Unknowns
JSON artifacts
```

Management view:

```text
What capability was added
Why the combination matters
Potential blast radius
Whether human approval remains
Whether external identity/credential/persistence exists
What remediation removes the chain
AgentSec remains report-only
```

## 8.5 Demo assets

Recommended layout:

```text
demos/capability-drift-agent/
├── README.md
├── demo-script.md
├── acceptance.md
├── baseline/
├── risky-drift/
├── malformed-or-partial/
├── remediated/
└── expected/

demos/capability-drift-agent-zh/
└── matching Chinese presenter assets
```

All examples remain inert. Commands and endpoints are synthetic/non-routable;
fixtures contain no real credentials, internal hostnames, or executable helper
files.

## 8.6 Demo acceptance

- under eight minutes;
- English and Chinese presenter tracks;
- one-screen management summary;
- developer source-level evidence;
- complete and incomplete Coverage examples;
- repeatable script with optional pause;
- offline expected-output fallback;
- checksums for frozen expected artifacts;
- no real execution/network/credential access;
- report-only exit behavior explained.

---

# 9. Work breakdown and estimates

| Task | Status | Main output | Dependency | One-engineer estimate |
|---|---|---|---|---:|
| P2I-01 | Complete | AgentAnalysisPipeline + stage trace | P2-11 | 3–5 days |
| P2I-02 | Complete | Capability Rule interface + six reviewed Rules | P2I-01 | 7–10 days |
| P2I-03 | Complete | Manifest, Assessment, Diff Text/JSON reports | P2I-01, P2I-02 | 4–7 days |
| P2I-04 | Complete | CLI, bounded artifact I/O, exit mapping | P2I-03 | 4–6 days |
| P2I-05 | Complete | Bilingual Demo, scripts, expected outputs, acceptance | P2I-04 | 4–6 days |
| Hardening | Pending | integration tests, docs, release/version review | all | 3–5 days |

Expected total:

```text
1 engineer: approximately 5–7 weeks
2 engineers with disjoint write scopes: approximately 3–4 weeks
```

Suggested parallelization after P2I-01:

```text
Engineer A: Capability Rules
Engineer B: report models/renderers and artifact I/O
Then integrate CLI and Demo
```

# 10. Definition of Done

The integration milestone is complete when:

1. one Pipeline call produces a final validated Manifest;
2. Manifest Text/JSON CLI is usable and deterministic;
3. two saved Manifests can be compared through Capability Diff CLI;
4. capability assessment reports deterministic combination Findings;
5. all outputs expose Coverage, Unknowns, versions, provenance, and report-only
   policy;
6. risky, incomplete, and remediated Demo states are repeatable offline;
7. no scanned content is executed or dereferenced;
8. no secret/environment/header value reaches logs, artifacts, or reports;
9. risk Severity and Evidence Confidence remain separate;
10. Critical/High combination Findings are never diluted through averaging;
11. targeted, integration, CLI E2E, Ruff, Mypy, and complete Pytest pass;
12. version-impact ADRs and user/developer documentation are complete.

# 11. Key risks and mitigations

| Risk | Mitigation |
|---|---|
| Pipeline reruns Association extraction | Add already-associated entry points and stage invocation tests |
| Combination Rules over-correlate unrelated Tools | Require same-target/parent-child correlation; lower confidence for Agent-wide joins |
| Manifest JSON and Report JSON diverge | Canonical artifacts remain source of truth; wrappers reference them |
| Huge Text output | Section limits and explicit omitted counts |
| Incomplete scan looks clean | Persistent incomplete status, Unknowns, exit `2` |
| New rules silently alter Phase 1 semantics | Independent Capability Rule/Risk versions |
| CLI accidentally enables blocking | Keep report-only; reserve exit `1` |
| Demo implies runtime exploit | Repeat static-declaration and no-runtime-proof boundary in every view |

# 12. Recommended immediate next task

`P2I-01` through `P2I-05` are complete. Start the Integration Hardening and
Phase 2 release review next.

Hardening should replay the bilingual Demo, review package/version publication,
freeze any new release Schemas and distribution artifacts only through an
explicit release task, and then return to the original P2-13～P2-15 gaps: Change
Impact, structured Rule Pack expansion, and reviewed report-only Capability Hard
Gates before any CI enforcement.
