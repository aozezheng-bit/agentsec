# AgentSec Phase 2 Scope

- Phase: Structured Capability Profile MVP
- Status: In progress
- Start date: 2026-08-20
- First task: `P2-01`
- Phase 1 release boundary: AgentSec 0.1.0 remains frozen and report-only

## 1. Purpose

Phase 2 converts explicit structured Agent configuration into deterministic,
source-backed facts that later Framework Adapters can normalize into an Agent
Manifest and Effective Capability Profile.

The phase does not begin with LLM inference. It first establishes safe parsing,
framework mapping, precedence resolution, capability provenance, deterministic
Capability Diff, and explicit Unknown values.

## 2. Planned inputs

Phase 2 may add reviewed support for:

```text
Markdown
JSON
YAML
TOML
Rules configuration
MCP manifests
Framework-specific Agent and tool configuration
```

Support is introduced task by task. P2-01 supplies general JSON, YAML, and
TOML Parser modules. P2-02 adds specialized Codex `.rules` and MCP declaration
Parsers. Neither task makes these files discoverable by `agentsec scan` yet.

## 3. Planned deterministic pipeline

```text
Bounded collected text
→ format-specific safe Parser
→ StructuredDocument
→ Framework Adapter
→ normalized declarations
→ inheritance / Override Resolver
→ Agent Manifest
→ Effective Capability Profile
→ Capability Diff
→ deterministic capability and combination Rules
```

## 4. Security invariants

Phase 2 retains every Phase 1 invariant and adds:

1. Structured Parsers never interpolate environment variables or templates.
2. Parsers never follow include/import/reference fields.
3. Parsers never instantiate YAML objects or custom tags.
4. Parsers never launch a configured command, MCP server, Hook, Skill, or tool.
5. Duplicate keys never silently overwrite security-significant values.
6. Unsupported or ambiguous values become explicit errors or Unknown fields.
7. Source file, structured field path, and line range remain traceable.
8. Parser depth, node count, and scalar size are bounded.
9. Framework differences remain behind Adapter interfaces and do not leak into
   the common rule engine.
10. Deterministic rules continue to own formal CI decisions.
11. LLM output, when added in Phase 3, remains inferred evidence rather than an
    authorization decision.

## 5. P2-01 boundary

P2-01 implements only:

- one small `StructuredParser` interface;
- normalized immutable `StructuredDocument` and `StructuredNode` values;
- 1-based inclusive source line ranges;
- JSON, YAML, and TOML Parser adapters;
- deterministic JSONPath-like field paths;
- duplicate-key detection;
- safe parser failure codes;
- depth, node-count, and scalar-length limits;
- focused positive, malformed, adversarial, and limit tests.

P2-01 does not implement:

- filesystem discovery of `.json`, `.yaml`, `.yml`, or `.toml`;
- new public `AssetType` values;
- Baseline or Diff integration for structured files;
- Framework Adapter behavior;
- Agent Manifest or Capability Profile;
- MCP-specific semantic extraction;
- risk rules or scoring changes;
- LLM analysis;
- CI blocking.

## 6. P2-01 exit criteria

P2-01 is complete when:

1. all three Parser adapters satisfy the same interface;
2. nested objects, arrays, scalar types, field paths, and line ranges are stable;
3. JSON duplicate keys are rejected;
4. YAML aliases, anchors, explicit tags, non-string keys, and multiple documents
   are rejected safely;
5. TOML tables, arrays of tables, quoted dotted keys, multiline values, dates,
   times, and datetimes are represented;
6. malformed input never copies source content into an exception message;
7. parser resource limits have regression tests;
8. no parsed declaration is executed or dereferenced;
9. Ruff, Ruff Format, strict Mypy, and the complete Pytest suite pass;
10. no Phase 1 Schema, Risk Model, enforcement, or frozen release artifact is
    silently changed.
## 7. P2-02 completion boundary

P2-02 adds:

- a non-executing literal `prefix_rule(...)` Parser for `.rules`;
- typed allow/prompt/forbidden decisions and inline example provenance;
- static top-level and plugin-bundled MCP declaration parsing;
- STDIO command/argument/environment declarations;
- sanitized Streamable HTTP endpoint and authentication declarations;
- tool filters, approval modes, timeouts, and enabled/required state;
- unknown-field locations without copied values;
- specialized resource limits and safe error codes.

P2-02 still does not discover files, evaluate a command against a prefix rule,
connect to MCP, enumerate runtime tools, build an Agent Manifest, or assign risk.
P2-03 defines the Framework Adapter interface required to bind parser results to
framework-specific assets.
## 8. P2-03 completion boundary

P2-03 adds one `FrameworkAdapter.inspect(request)` seam and neutral immutable
models for Adapter metadata, explicit roots/limits, portable asset locators,
formats, roles, parser-coherent asset records, precedence hints, and explicit
Coverage.

The interface does not contain command, environment, network, MCP, model, plugin,
Hook, or Skill execution dependencies. Framework results are intended for the
future Agent Manifest builder and are not passed to the Phase 1 `RuleContext`.

P2-03 has no concrete production Adapter. P2-04 implements Codex discovery and
parsing behind the interface.

## 9. P2-04 completion boundary

P2-04 adds a production `CodexAdapter` that safely discovers and parses:

```text
project-chain AGENTS.md and AGENTS.override.md
project-chain .codex/config.toml
project-chain .codex/rules/*.rules
project-chain .agents/skills/*/SKILL.md
explicit user Codex-home Agent/config/Rules assets
explicit user-home .agents/skills/*/SKILL.md
static MCP declarations contained in Codex TOML configuration
```

The Framework request now has an optional working directory, which defaults to
the project root and must remain inside it. User and Codex roots remain
explicit; the Adapter does not read process environment or infer a home
directory.

P2-04 preserves base and Override files, records precedence hints, enforces path
containment, UTF-8, file-size, depth, and asset-count limits, and returns
explicit Coverage. It does not execute instructions, load Skills, evaluate
Rules, start/connect to MCP, dereference URLs, read environment-variable values,
load plugins, import project code, or call an LLM.

P2-04 still does not build an Agent Manifest, resolve effective configuration,
assign capability risk, serialize structured assets into current reports, or
change the Phase 1 CLI. P2-05 owns the Agent Manifest boundary.

## 10. P2-05 completion boundary

P2-05 introduces independently versioned Agent Manifest Schema `0.1.0` with
strict immutable models for:

```text
metadata and Agent subject identity
portable source inventory and exact source references
instruction candidates and effective-source placeholders
tool inventory and side-effect vocabulary
permission action/effect/resource/scope
approval, sandbox, policy, trust, timeout, and tool controls
credential-free runtime identities
Agent/Skill/MCP/tool/memory relationships
explicit Unknown dimensions and reasons
Manifest Coverage
```

Every major dimension carries an explicit `unresolved`, `partial`, `resolved`,
`unknown`, `not_applicable`, or `conflict` status. Empty tuples therefore do not
silently imply that a capability is absent or safe.

`AgentManifestBuilder` consumes `FrameworkInspectionResult`, normalizes safe
source metadata and Coverage, creates base/Override instruction candidates, and
records declaration sources for future extraction. It deliberately does not
copy parsed source values or implement P2-06～P2-11 early.

P2-05 also adds deterministic JSON encoding, compatibility-first safe
validation, and Draft 2020-12 JSON Schema export. P2-06 consumes the Manifest
instruction candidates and adds deterministic inheritance/Override resolution,
effective application order, superseded-source provenance, and resolution
trace. The Manifest remains outside the current Phase 1 CLI, Assessment,
Baseline, Diff, Rule, and Risk paths.

P2-06 extends the Manifest Schema to `0.2.0`, and P2-07 extends it to `0.3.0`
because the instruction profile carries effective application order and
resolution provenance, while the configuration profile carries source-level
precedence order and trace.

## 11. P2-06 completion boundary

P2-06 adds `InstructionResolver.resolve(manifest) -> AgentManifest`.

The Resolver groups candidates by:

```text
source scope + root_id + parent directory
```

and applies:

```text
User before Project
root directory before nested directories
same-directory Override over Base
```

It retains both canonical `effective_sources` and semantic `effective_order`,
as well as `overridden_sources` and a safe `resolution_trace`. Complete Coverage
produces `resolved`; incomplete Coverage produces `partial`; no candidates stay
`unknown`; ambiguous candidate sets fail closed as `conflict`.

P2-06 never reads or executes instruction content and does not implement
configuration precedence, tool extraction, permissions, runtime identity,
relationships, risk, or LLM analysis. P2-07 owns configuration precedence.

## 12. P2-07 completion boundary

P2-07 adds `ConfigurationResolver.resolve(manifest) -> AgentManifest` and the
required Manifest `configuration` profile. It orders source-level Framework,
Rules, and MCP declarations by:

```text
User Scope before Project Scope
Adapter precedence rank
Root ID, portable path, chain key, configuration kinds
```

The output preserves canonical `effective_sources`, semantic
`effective_order`, and a full source-level `resolution_trace`. Complete Coverage
produces `resolved`; incomplete Coverage produces `partial`; no candidates stay
`unknown`; ambiguous candidate identities fail closed as `conflict`.

P2-07 does not merge individual TOML fields, evaluate `.rules`, select active
MCP servers, read environment values, determine runtime authentication, assign
permissions, or call an LLM. P2-08 owns Skill/MCP/Tool Association.

## 13. P2-08 Skill / MCP / Tool Association

P2-08 adds `AssociationExtractor.extract(manifest, inspection)`, which consumes
the same parser-coherent `FrameworkInspectionResult` used to build the Manifest
and populates existing `ManifestTool` and `ManifestRelation` fields. It creates
source-backed associations for:

```text
Skill → skill tool + uses_skill relation
MCP server → mcp_server tool + uses_mcp relation
static MCP tool filters/policies → mcp_tool child + uses_tool relation
```

MCP server side-effect classification is conservative and static:

```text
stdio           → execute
streamable_http → network
plugin_bundled  → unknown
```

Skill bodies, MCP commands, arguments, URLs, headers, environment values, and
other parser values are not copied into the Manifest. MCP filters and policies
are associated by exact field path and line range, but approval modes remain
evidence only and do not become permissions or controls.

All generated tools and relationships have stable deterministic IDs, source
provenance, and declared (not active) relationship state. Colliding normalized
names receive a bounded SHA-256 suffix derived from portable source identity.
Complete Coverage produces `resolved`; incomplete Coverage produces `partial`.
No MCP process is launched, no endpoint is contacted, no Skill or command is
executed, no environment value is read, and no LLM is called.

P2-08 does not change the Manifest Schema version (`0.3.0`) because it activates
existing fields without adding serialized fields or enum values. P2-09 owns
permission, control, and runtime-identity extraction.

## 14. P2-09 Static Permission, Control, and Runtime Identity Extraction

P2-09 adds `CapabilityExtractor.extract(manifest, inspection)` and populates the
existing Manifest profiles:

```text
ManifestPermission
ManifestControl
ManifestRuntimeIdentity
```

Known static Tool side effects become conservative permissions:

```text
read            → read / tool
write           → write / tool
MCP stdio       → execute / shell
MCP HTTP        → network / network
secret reference → secret_access / environment or secret_store
privileged      → admin / other
unknown         → unknown / tool
```

Permission effect remains `unknown` for inferred Tool side effects. Parsed `.rules`
decisions are the exception: allow/prompt/forbidden become allow/prompt/deny
permission effects and matching Prefix Rule controls. Rules are not evaluated
against commands.

P2-09 adds source-backed controls for MCP enablement, required state, approval
modes, Tool filters, network endpoint declaration, timeouts, and environment or
header references. It adds one credential-free runtime identity per static MCP
server. OAuth, ChatGPT, bearer/environment references, transport, and sanitized
endpoint locality are mapped to principal, authentication, and environment kinds
without reading credential values.

Complete Coverage with no unresolved static facts produces `resolved`; incomplete
Coverage or unknown/unsupported reviewed facts produces `partial`. Relevant
sources with no recognized facts remain `partial` rather than becoming a silent
absence. No new fields or enum values are added, so the Manifest Schema remains
`0.3.0`.

P2-09 does not execute commands or Skills, launch/connect to MCP, read
environment values, enumerate runtime tools, generate risk Findings, call an LLM,
or make CI/authorization decisions. P2-10 owns Sub-Agent and memory relations;
P2-11 owns systematic Unknown generation and later Capability Diff integration.

## 15. P2-10 Sub-Agent and Memory Relationships

P2-10 adds `RelationshipExtractor.extract(manifest, inspection)` and populates
the existing relationship kinds:

```text
delegates_to
reads_memory
writes_memory
persists_memory
```

Only explicit valid Markdown frontmatter declarations are recognized. Supported
forms include delegation aliases such as `delegates_to`/`sub_agents`, memory
aliases such as `reads_memory`/`writes_memory`/`persists_memory`, and the nested
form:

```yaml
memory:
  read: session
  write: scratch
  persist: long-term
```

Free-form prose, headings, link labels, and relative paths are not inferred as
relationships. Valid values create `declared` relations with field-path and
line-range provenance. Duplicate logical edges merge provenance. Unsafe target
values become hashed `unknown` targets and make the profile `partial`; raw target
values are never serialized. Malformed frontmatter and unsupported recognized
values also fail closed to `partial`.

Relationship declaration sources now include `AGENTS.md`,
`AGENTS.override.md`, and `SKILL.md` Markdown assets in addition to existing MCP
sources. P2-10 preserves P2-08 Skill/MCP/tool relationships and does not mark
any relation `active`. It never dereferences paths, reads memory stores, executes
Sub-Agents/Skills/Commands, connects to MCP, accesses environment values, calls
an LLM, or emits risk/CI decisions. The Manifest Schema remains `0.3.0`.

P2-11 owns systematic Unknown generation and later Capability Diff integration.

## 16. P2-11 Explicit Unknowns and Capability Diff

P2-11 adds `UnknownExtractor.extract(manifest)` and systematically materializes
profile- and item-level uncertainty into existing `ManifestUnknown` entries.
It maps unresolved/unknown/partial/conflict status, unknown Tool/Permission/
Control/Identity/Relationship fields, runtime `privileged=null`, and incomplete
Coverage to stable reason codes. Extraction is deterministic and idempotent.

P2-11 also adds `CapabilityDiffer.compare(before, after)` for compatible
Manifests representing the same Agent and Framework. It compares Tools,
Permissions, Controls, Runtime Identities, Relationships, Unknowns, profile
resolution transitions, and Coverage transitions. Added/removed/modified entries
contain stable IDs, safe changed-field names, canonical SHA-256 fingerprints, and
source provenance rather than complete item payloads.

Capability Diff remains visible but incomplete when either input Coverage is
incomplete. It uses a new independent versioned interface:

```text
CAPABILITY_DIFF_SCHEMA_VERSION = 0.1.0
```

with deterministic JSON encoding, compatibility-first safe validation, and
Draft 2020-12 Schema export. Agent Manifest Schema remains `0.3.0`; Phase 1
Diff Output remains `0.1.0` because no CLI contract is changed.

P2-11 performs no filesystem/source-content read, execution, path dereference,
network/MCP connection, environment/memory/credential access, Risk Finding, CI
blocking, or LLM call. Phase 2 static capability modeling is structurally
complete; later phases own deterministic combination-risk rules, semantic/LLM
evidence, CLI/report integration, and Demo presentation.

## 17. P2I-01 Full Agent Analysis Pipeline

P2I-01 adds `AgentAnalysisPipeline.analyze(request)` as the application-layer
composition of P2-04 through P2-11:

```text
CodexAdapter.inspect
→ AgentManifestBuilder.build
→ InstructionResolver.resolve
→ ConfigurationResolver.resolve
→ AssociationExtractor.extract
→ CapabilityExtractor.extract_associated
→ RelationshipExtractor.extract_associated
→ UnknownExtractor.extract
→ final strict AgentManifest validation
```

The result contains the final Manifest, Coverage-derived completion state,
current version vector, and a deterministic nine-stage trace with only safe
status, counts, and stable error codes. Incomplete Coverage returns a valid
Partial Manifest rather than a false clean result. Required dependency failures
raise a safe `AgentAnalysisError` without copying dependency diagnostics.

Standalone `CapabilityExtractor.extract()` and `RelationshipExtractor.extract()`
remain backward compatible. The Pipeline uses new already-associated entry points
so Association is executed once. P2I-01 changes no serialized Schema, Risk Model,
Rule Pack, CLI, report, enforcement, or LLM boundary. P2I-02 owns deterministic
combination-risk rules.

## 18. P2I-02 Deterministic Capability Rules

P2I-02 adds an independent `agentsec.capability_rules` package over the final
P2I-01 Manifest. The initial Rule Pack contains six stable bilingual Rules for
approval gaps, execute/secret/network chains, incomplete analysis, delegation,
required credentialed external MCP, and persistent memory combinations.

Correlation distinguishes same-target B evidence, parent/child C evidence,
Agent-wide D evidence, and incomplete/Unknown D evidence. The runner avoids
Agent-wide Cartesian products, retains hash-backed value-free provenance,
calculates impact by high-water mark, uses the explicit NIST likelihood-impact
matrix and existing score/Severity mappings, and isolates Rule failures
atomically. Severity and Evidence Confidence remain separate.

Independent versions are:

```text
CAPABILITY_RULE_PACK_VERSION = 0.1.0
CAPABILITY_RISK_MODEL_VERSION = 0.1.0
```

Phase 1 Rule Pack `0.3.0` and Risk Model `0.4.0` remain unchanged. P2I-02 is
report-only: `hard_gate=false`, no CI blocking, no LLM, no source reread, no
execution, and no network/MCP/environment/memory access. ADR-0029 records the
risk-model decision. P2I-03 owns public Text/JSON reporting.

## 19. P2I-03 Manifest, Capability Assessment, and Capability Diff Reports

P2I-03 adds deterministic bilingual Text delivery for Agent Manifest,
Capability Assessment, and Capability Diff, while preserving existing canonical
Manifest Schema `0.3.0` and Capability Diff Schema `0.1.0` JSON codecs.

It introduces an independently versioned strict Capability Assessment wrapper:

```text
CAPABILITY_ASSESSMENT_OUTPUT_VERSION = 0.1.0
format = agentsec-capability-assessment
```

The wrapper embeds the canonical Manifest and adds policy, management summary,
Capability Findings, complete nine-stage trace, and isolated Rule failures.
Status is complete only when Manifest Coverage and Rule execution are both
complete. Policy is fixed to report-only, CI blocking disabled, no global-safety
claim, and runtime capability not verified.

Text output supports English and Simplified Chinese, applies shared secret
redaction and untrusted-text sanitization, bounds every detail section, and
shows exact omission counts. JSON remains complete within Parser and inspection
limits. No report contains source excerpts, parsed Command/URL/Header/environment
values, credentials, or dependency error messages.

P2I-03 performs no execution, path dereference, network/MCP connection,
environment/memory/credential access, LLM call, runtime verification, Hard Gate,
or CI enforcement. ADR-0030 records the report contract. P2I-04 owns CLI and
bounded artifact file I/O.

## 20. P2I-04 Manifest and Capability CLI

P2I-04 exposes the completed static capability analysis through:

```text
agentsec manifest
agentsec capability assess
agentsec capability diff
agentsec capability rules list
```

Manifest and Assessment commands accept explicit project, working-directory,
user-home, Codex-home, Agent ID, format, language, output, and force options. The
application core never infers user/Codex roots from process environment.
Capability Diff reads two bounded, regular, non-symlink, compatibility-validated
Manifest JSON files and rejects incompatible Agent, Framework, or Schema inputs.

`ReportArtifactWriter` validates the selected artifact kind, requires `.json` or
`.txt`, creates mode-0600 atomic output, does not overwrite by default, and lets
`--force` replace only an existing valid artifact of the same kind and format. A
Diff output may not replace either input Manifest. Stdout contains only the
requested report when no output file is selected; errors use stderr.

Complete report-only analysis returns `0`; incomplete Manifest Coverage, Rule
execution, or Capability Diff returns `2`; invalid/unsafe artifacts return `4`;
required analysis failure returns `5`. Findings never select exit `1`.

P2I-04 changes no Manifest, Capability Diff, Capability Assessment, Rule Pack,
Risk Model, or Phase 1 serialized version. It performs no execution, network/MCP
connection, environment/memory/credential access, runtime verification, LLM
analysis, Hard Gate, or CI blocking. ADR-0031 records the CLI and Artifact I/O
contract. P2I-05 owns the Capability Drift Demo.

## 21. P2I-05 Capability Drift Story Demo

P2I-05 adds inert English and Chinese Release Agent stories with baseline, risky
drift, incomplete, and remediated states. Both tracks use the production
`manifest`, `capability assess`, and `capability diff` commands. Baseline and
remediated states have complete Coverage and zero Capability Findings; risky
drift has seven Findings across six Rule IDs with highest Severity High; the
invalid UTF-8 Override returns incomplete exit `2`.

The Demo includes automated and presenter-friendly runners, optional pauses, an
offline mode, frozen deterministic Manifest/Assessment/Diff Text and JSON, a
one-screen management summary, SHA-256 checksums, and acceptance records. Output
omits the synthetic token and `.invalid` endpoint value. Fixtures contain no
executable helper, real credential, internal hostname, or personal data.

P2I-05 performs no scanned execution, MCP/network connection, environment or
credential read, runtime verification, LLM call, Hard Gate, or CI enforcement.
It changes no Schema, Output, Rule Pack, Risk Model, or frozen Phase 1 release
version. The integration implementation is complete; hardening and a separate
Phase 2 release review remain.

