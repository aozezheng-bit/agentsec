# AgentSec

AgentSec is an evidence-backed CLI for static security analysis of Agent
instruction and configuration assets.

The frozen Phase 1 PoC scans Markdown with 15 deterministic Rules. The current
source tree also builds structured Agent Manifests, evaluates deterministic
Capability Rules, compares Capability Drift, and produces bilingual Text or
versioned JSON reports without executing scanned content.

> AgentSec reports security-relevant declarations. It does not prove runtime
> exploitability or claim that an Agent is globally safe.

## Current status

Phase 1 completed through **P1-31** and released locally on 2026-08-19:

```text
Markdown discovery and safe parsing
→ Baseline and bounded Text Diff
→ 15 deterministic Rules
→ NIST-style Risk and A/B/C/D Evidence Confidence
→ Report-Only Hard Gate stage
→ Rich Text and versioned JSON reports
→ Hardened secret redaction and Coverage reporting
→ 45-Case bilingual corpus and full CLI integration regression
→ README and PoC usage guide
→ Frozen Schemas, accepted Demo, wheel/sdist release artifacts
```

Current package version:

```text
0.2.0
```

Final local release verification:

```text
Ruff / Ruff Format / Mypy: passed
Pytest: 563 passed
Release Agent Demo E2E: passed
Non-editable wheel installation: passed
```

AgentSec 0.2.0 includes Rule Pack `0.3.0`, the 45-Case bilingual Markdown
corpus, the complete Phase 2 integration chain, and local Phase 2 release
artifacts. The accepted 0.1.0 wheel/sdist remain preserved at the `dist/` root;
0.2.0 artifacts are stored under `dist/0.2.0/`.

Phase 2 task P2-01 now adds parser-only JSON, YAML, and TOML support through a
common source-location-preserving interface. These formats are not yet selected
by `agentsec scan`; structured Asset discovery and Agent Manifest mapping remain
subsequent tasks.

P2-02 now adds non-executing Codex `.rules` `prefix_rule(...)` parsing and static
MCP server declaration parsing for STDIO, Streamable HTTP, and plugin-bundled
configurations. It does not evaluate commands, launch servers, connect to URLs,
or expose static environment/header values.

P2-03 defines a one-method Framework Adapter interface with portable asset
locators, neutral roles/formats, parser-coherent records, precedence hints, and
explicit Coverage.

P2-04 now provides the first production `CodexAdapter`. It discovers explicit
project-chain and user-scope Agent, Skill, Rules, TOML, and MCP assets through
bounded, UTF-8, symlink-contained reads. The Adapter does not execute commands,
load Skills, connect to MCP, read environment-variable values, call an LLM, or
change the current Phase 1 CLI.

P2-05 through P2-11 now define independently versioned Agent Manifest Schema `0.3.0`, with
strict source provenance, identity, instruction, tool, permission, control,
runtime identity, relationship, Unknown, and Coverage models. The initial
Builder copies no parsed source values and marks not-yet-resolved dimensions
explicitly instead of treating empty data as safe.

P2-07 adds a source-level `ConfigurationResolver` for Framework, Rules, and MCP
configuration. It preserves source precedence and application order without
merging raw configuration values or claiming that a complete file replaces all
lower-level fields.


P2-08 adds deterministic `AssociationExtractor` support for Skill, static MCP
server, and MCP tool declarations. It creates source-backed tool inventory and
`uses_skill`/`uses_mcp`/`uses_tool` relationships, classifies only conservative
static `stdio=execute`, `HTTP=network`, and bundled=`unknown` potential effects,
and preserves declared-vs-runtime boundaries. It never executes Skills or
commands, launches/connects to MCP, reads environment or secret values, or calls
an LLM.


P2-09 adds deterministic `CapabilityExtractor` support for static permissions,
controls, and credential-free MCP runtime identity hypotheses. It maps known
Tool side effects into read/write/execute/network/secret/admin permission facts,
converts explicit `.rules` decisions into allow/prompt/deny permission and
Prefix Rule control facts, and records MCP enablement, approval, filter, timeout,
network, secret-handling, authentication, and environment evidence. It keeps
permission effect separate from Tool availability and never reads credentials,
executes commands, connects to MCP, or calls an LLM.


P2-10 adds deterministic `RelationshipExtractor` support for explicit Markdown
frontmatter declarations of Sub-Agent delegation and memory read/write/persist
edges. It preserves Skill/MCP/tool relationships, merges duplicate edges with
full provenance, hashes unsafe targets, and does not infer relationships from
free-form prose or dereference paths. It never executes Sub-Agents, reads memory
stores, accesses environment values, connects to MCP, or calls an LLM.


P2-11 adds idempotent `UnknownExtractor` support and a versioned
`CapabilityDiffer`. Unknowns now explicitly identify unresolved profiles,
unknown item fields, runtime verification requirements, and incomplete Coverage.
Capability Diff compares tools, permissions, controls, identities, relationships,
Unknowns, and profile status using stable IDs, SHA-256 fingerprints, safe field
names, and source references without copying complete item values. The new
`CAPABILITY_DIFF_SCHEMA_VERSION` is `0.1.0`; it is not yet part of the CLI.

P2I-01 now adds `AgentAnalysisPipeline`, a single injectable application service
that runs P2-04 through P2-11 in a fixed order, validates the final Manifest,
and returns a bounded safe Stage Trace plus the current version vector. The
Pipeline invokes Association once and uses compatible already-associated
Capability/Relationship entry points to avoid repeated semantic extraction. It
remains static, report-only, non-LLM, and outside the current CLI.

P2I-02 now adds an independent deterministic Capability Rule Pack and Risk
Model, both version `0.1.0`. Six bilingual Rules detect approval gaps,
execute/secret/network chains, incomplete analysis, delegation, required
credentialed external MCP, and persistent-memory combinations. Correlation
distinguishes same-target, parent/child, Agent-wide, and incomplete evidence;
Findings remain value-free, report-only, non-LLM, and outside the current CLI.

P2I-03 adds deterministic English/Chinese Text and JSON delivery for Agent
Manifest, Capability Assessment, and Capability Diff. Manifest and Diff JSON use
their canonical codecs; the strict Capability Assessment Output `0.1.0` embeds
the canonical Manifest and exposes report-only policy, management summary,
Findings, Stage Trace, and Rule failures.

P2I-04 now exposes this path through `agentsec manifest`, `agentsec capability
assess`, `agentsec capability diff`, and `agentsec capability rules list`. Saved
Manifest input is bounded and compatibility-validated; file output is private,
atomic, no-clobber by default, and restricts `--force` to the same valid artifact
kind. Findings remain report-only and the CLI never claims runtime verification
or global Agent safety.

P2I-05 now adds an accepted English/Chinese Capability Drift Demo with reviewed
baseline, risky, incomplete, and remediated states. The risky state produces
seven Findings across six Capability Rule IDs with highest High; remediation
returns to zero current Findings. Live and offline presenter flows preserve
report-only and no-runtime-proof boundaries.

## Phase 2 capability CLI quick start

From a source checkout, build and assess one static Agent profile:

```bash
agentsec manifest . --agent-id local-agent --format text
agentsec capability assess . --agent-id local-agent --format text
agentsec capability rules list --language zh
```

Save two canonical Manifests and compare normalized capability drift:

```bash
agentsec manifest /path/to/before --agent-id release-agent \
  --format json --output /tmp/before.manifest.json
agentsec manifest /path/to/after --agent-id release-agent \
  --format json --output /tmp/after.manifest.json
agentsec capability diff \
  --before /tmp/before.manifest.json \
  --after /tmp/after.manifest.json
```

Complete report-only analysis returns `0`; incomplete Coverage or Rule execution
returns `2`; unsafe or incompatible artifacts return `4`. See
[`docs/capability-cli.md`](docs/capability-cli.md).

Run the Capability Drift story:

```bash
scripts/run-capability-demo.sh --language en
scripts/demo-capability-drift.sh --language zh
```

Use `--offline --no-pause` on the presenter script for the checksum-validated
fallback.

## Requirements

- Python 3.12 or newer;
- a local source checkout of this repository;
- Git is optional and is used only for local Baseline provenance when available.

AgentSec does not require an LLM, model API key, MCP connection, or network
service. Rule Pack 0.3.0 supports reviewed English and Simplified Chinese
trigger phrases.

## Install from the source checkout

### macOS or Linux

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install --editable .
agentsec version
```

Expected output:

```text
agentsec 0.2.0
```

### Windows PowerShell

```powershell
py -3.12 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --editable .
agentsec version
```

Without installation, a source-checkout smoke test is also available:

```bash
PYTHONPATH=src python3.12 -m agentsec version
```

## Five-minute quick start

### 0. Inspect the Chinese Rule inventory

```bash
agentsec rules list --language zh
```

Run the Chinese presenter Demo with:

```bash
scripts/demo-developer.sh --case-language zh --show-rules
```

See [`docs/rule-pack-zh.md`](docs/rule-pack-zh.md) and
[`demos/release-agent-zh/`](demos/release-agent-zh/README.md).

### 1. Scan a safe example

From the repository root:

```bash
agentsec scan testdata/safe/minimal-agent
```

Expected outcome:

```text
Status: COMPLETE
Assets: 1
Findings: 0
Exit code: 0
```

Zero Findings means only that no current deterministic Rule matched within the
supported scope. It is not a global safety guarantee.

### 2. Scan a risky example

```bash
agentsec scan testdata/risky/shell-secret-network
```

This Case produces four Findings covering:

```text
shell execution
secret or environment access
external network transmission
removed human confirmation
```

The highest current Severity is High. The command still returns exit code `0`
because Phase 1 is report-only and does not block CI based on Findings.

### 3. Produce machine-readable JSON

```bash
agentsec scan testdata/risky/shell-secret-network \
  --format json \
  > assessment.json
```

The output format is:

```text
format = agentsec-assessment
format_version = 0.2.0
```

The JSON explicitly records:

```text
enforcement_mode = report_only
ci_blocking_enabled = false
global_safety_claimed = false
```

### 4. Observe incomplete Coverage

```bash
agentsec scan testdata/malformed/invalid-utf8 --format json
```

Expected outcome:

```text
status = incomplete
coverage issue = unsupported_encoding
exit code = 2
```

Incomplete Coverage is a partial result and must not be treated as a clean pass.

## Scan your own project

```bash
agentsec scan /path/to/project
agentsec scan /path/to/project --format text
agentsec scan /path/to/project --format json
agentsec scan /path/to/project --config /path/to/config.yaml
```

Phase 1 automatically discovers these exact filenames recursively:

```text
AGENTS.md
AGENTS.override.md
SKILL.md
```

Additional lowercase `.md` files can be explicitly included through project
configuration.

## Inspect the built-in Rule Pack

```bash
agentsec rules list
```

The command lists all 15 stable Rule IDs, categories, and titles from Rule Pack
`0.2.0`. It reads trusted packaged metadata and does not scan a project.

## Minimal project configuration

Create `<project-root>/.agentsec/config.yaml`:

```yaml
version: "0.1.0"

discovery:
  include:
    - AGENTS.md
    - AGENTS.override.md
    - SKILL.md
    - "**/AGENTS.md"
    - "**/AGENTS.override.md"
    - "**/SKILL.md"
  exclude:
    - ".git/**"
    - ".venv/**"
    - "node_modules/**"
    - "dist/**"
    - "build/**"

limits:
  max_file_size_bytes: 1048576
  max_depth: 20
  max_assets: 1000

output:
  format: text
  redact_secrets: true
```

Configuration precedence is:

```text
explicit --config
→ <project-root>/.agentsec/config.yaml
→ secure built-in defaults
```

Output format precedence for `scan` and `diff` is:

```text
--format text|json
→ config output.format
→ text
```

Secret redaction cannot be disabled in Phase 1.

## Baseline and Diff workflow

Create a trusted local snapshot only after reviewing the current Agent assets:

```bash
agentsec baseline create /path/to/project
```

The default output is:

```text
/path/to/project/.agentsec/baseline.json
```

After the Agent files change, compare them with the snapshot:

```bash
agentsec diff /path/to/project
agentsec diff /path/to/project --format json
```

Use an explicit Baseline location when required:

```bash
agentsec baseline create /path/to/project \
  --output /trusted/location/baseline.json

agentsec diff /path/to/project \
  --baseline /trusted/location/baseline.json
```

Important distinctions:

- `scan` reports current deterministic security Findings;
- `baseline create` captures exact bounded UTF-8 content and metadata;
- `diff` reports textual drift and does not assign risk by itself;
- a Baseline is sensitive plaintext and is not an approval signature;
- changed files alone do not cause a nonzero risk-policy exit.

## How to read a Finding

| Field | Meaning |
|---|---|
| Rule | Stable deterministic detection identity |
| Category | Type of declared security-relevant behavior |
| Likelihood | Preliminary NIST-style likelihood profile |
| Impact | Highest reviewed impact dimension; not an average |
| Score | Preliminary AgentSec 0–10 mapping |
| Severity | Risk magnitude derived from the current Risk Model |
| Confidence | Strength of available Evidence, independent from Severity |
| Hard Gate | Whether a deterministic risk floor matched; report-only in Phase 1 |
| Evidence | Project-relative file, line range, hash, field, and safe excerpt |
| Recommendations | Reviewed follow-up actions |

All 15 Markdown Rules currently use static source evidence and therefore report
Confidence `D`. A High/D Finding remains High: weak evidence confidence does not
lower or erase possible impact.

## Coverage is separate from risk

Coverage answers whether the selected input was successfully evaluated.
Findings answer which deterministic Rules matched.

```text
COMPLETE + Findings     → analysis completed and signals were found
COMPLETE + no Findings  → no current Rule matched; not a safety guarantee
INCOMPLETE              → partial result; review every Coverage Issue
```

Coverage problems include invalid UTF-8, unreadable or oversized files, unsafe
paths, traversal limits, parser failures, and isolated Rule failures.

## Exit codes

| Code | Meaning |
|---:|---|
| `0` | Command succeeded; Findings remain report-only |
| `1` | Reserved for a future enforcing risk threshold; not produced in Phase 1 |
| `2` | Scan or Diff Coverage is incomplete |
| `3` | Project configuration is invalid or incompatible |
| `4` | Baseline is missing, invalid, incompatible, or unsafe |
| `5` | A required analysis stage failed safely |
| `64` | Invalid CLI syntax through the installed/module entry point |

Automation must use exit codes and JSON fields rather than parsing Rich Text.

## Security boundaries

AgentSec:

- never executes scanned code blocks, scripts, Hooks, Skills, commands, or tools;
- never connects to an MCP server declared by scanned content;
- performs no external network access by default;
- does not interpolate scanned text into shell commands;
- does not follow a symbolic link outside the selected root by default;
- bounds file size, traversal depth, asset count, matching, Diff, and Text output;
- redacts recognized secrets before escaping control characters;
- makes incomplete Coverage visible;
- requires direct Evidence for every final Finding;
- keeps Severity, Confidence, Hard Gate state, and CI policy separate.

## Current limitations

Phase 1 does not provide:

- general TOML, YAML, JSON, plugin, or MCP-manifest parsing;
- effective capability or permission resolution;
- runtime identity, OAuth-scope, or tool availability verification;
- semantic Diff or LLM analysis;
- production Hard Gate combination detectors;
- `--fail-on`, CI blocking, waivers, or automatic remediation;
- SARIF, HTML, or a Web console;
- financial-loss estimates or a global safety verdict;

## Release artifacts and full PoC guide

The local release includes:

- frozen Schemas under [`schemas/`](schemas/README.md);
- Release Agent Demo under [`demos/release-agent/`](demos/release-agent/README.md);
- [0.1.0 release notes](docs/releases/0.1.0.md);
- [known limitations](docs/releases/0.1.0-known-limitations.md);
- [release acceptance record](docs/releases/0.1.0-acceptance.md);
- wheel, sdist, and SHA-256 files under `dist/`.

Rebuild and verify the local artifacts with:

```bash
scripts/build-release.sh
scripts/verify-release-install.sh
```

See [`docs/poc-usage.md`](docs/poc-usage.md) for:

- a complete first-run walkthrough;
- Safe, Risky, Prompt Injection, and Malformed examples;
- Text and JSON interpretation;
- Python JSON validation;
- Baseline lifecycle and Diff review;
- automation patterns;
- troubleshooting and residual risks.

## Development setup

Install the development dependencies:

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install --editable '.[dev]'
```

Run the complete local/CI quality gate:

```bash
scripts/check.sh
```

The gate runs Ruff linting, Ruff formatting verification, strict Mypy, and
Pytest. A different Python 3.12 executable can be selected with:

```bash
PYTHON=/path/to/python scripts/check.sh
```

## Documentation map

### Start here

- [PoC usage guide](docs/poc-usage.md)
- [Phase 1 scope](docs/scope.md)
- [Project configuration](docs/configuration.md)
- [CLI integration](docs/cli-integration.md)
- [Exit codes](docs/exit-codes.md)

### Reports and security interpretation

- [Assessment Text report](docs/assessment-text-report.md)
- [Assessment JSON report](docs/assessment-json-report.md)
- [Phase 2 Capability reports](docs/capability-reports.md)
- [Manifest and Capability CLI](docs/capability-cli.md)
- [Capability Drift Demo](docs/capability-drift-demo.md)
- [Coverage reporting](docs/coverage-report.md)
- [Risk Model](docs/risk-model.md)
- [Evidence Confidence](docs/confidence-model.md)
- [Hard Gate semantics](docs/hard-gate.md)
- [Secret redaction](docs/secret-redaction.md)

### Collection, Baseline, and Diff

- [Path safety](docs/path-safety.md)
- [Resource limits](docs/resource-limits.md)
- [Markdown parser](docs/markdown-parser.md)
- [Phase 2 scope](docs/phase2-scope.md)
- [JSON/YAML/TOML structured parsers](docs/structured-parsers.md)
- [Rules and MCP specialized parsers](docs/rules-mcp-parsers.md)
- [Framework Adapter interface](docs/framework-adapter-interface.md)
- [Codex Adapter](docs/codex-adapter.md)
- [Agent Manifest Schema](docs/agent-manifest-schema.md)
- [Instruction Resolver](docs/instruction-resolver.md)
- [Configuration Precedence Resolver](docs/configuration-precedence-resolver.md)
- [Baseline creation](docs/baseline-create.md)
- [Baseline Schema](docs/baseline-schema.md)
- [Asset Diff](docs/asset-diff.md)
- [Text Diff](docs/text-diff.md)
- [Diff CLI](docs/diff-cli.md)

### Rules, tests, and project governance

- [Rule Pack](docs/rule-pack.md)
- [中文 Rule Pack](docs/rule-pack-zh.md)
- [Rule pipeline](docs/rule-pipeline.md)
- [Test corpus](docs/test-corpus.md)
- [Threat model](docs/threat-model.md)
- [Versioning](docs/versioning.md)
- [Skill / MCP / Tool Association](docs/skill-mcp-tool-association.md)
- [Static Capability Profile](docs/static-capability-profile.md)
- [Sub-Agent / Memory Relationships](docs/sub-agent-memory-relationships.md)
- [Explicit Unknowns / Capability Diff](docs/manifest-unknowns-capability-diff.md)
- [Full Agent Analysis Pipeline](docs/agent-analysis-pipeline.md)
- [Deterministic Capability Rules](docs/capability-rules.md)
- [Phase 2 Integration Closure Plan](docs/phase2-integration-plan.md)
- [Developer and management Demo plan](docs/demo-plan.md)
- [Domain glossary](CONTEXT.md)

## Release status

AgentSec 0.1.0 remains the accepted local Phase 1 PoC release. AgentSec 0.2.0 is
the accepted local Phase 2 Integration MVP, containing P2-01 through P2-11 and
P2I-01 through P2I-05: structured Parsers, Rules/MCP Parsers, Framework and
Codex Adapters, Agent Manifest, deterministic resolution/extraction, explicit
Unknowns, Capability Diff, one full analysis Pipeline, six Capability Rules,
bilingual reports, restricted Manifest/Capability CLI Artifact I/O, and the
accepted bilingual Capability Drift Demo.

This workspace is not a Git repository and has no configured remote publication
target. No Git tag, signed commit, PR, package-index upload, remote Release
object, production deployment, or CI enforcement is claimed.
