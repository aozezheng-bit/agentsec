# P3-11: Real Provider Semantic Shadow Pilot / Semantic Quality Qualification

- Status: In Progress（A 阶段启动）
- Date: 2026-08-31
- Depends on: P3-01～P3-10
- Mode: Shadow-only; real invocation is decision-gated

## Objective

Establish the first evidence-backed semantic Quality Qualification over
human-labeled gold data, and run a Real Provider Shadow Pilot only after an
explicit endpoint decision. The task must not grant Provider, Finding, Rule,
Policy, CI, Hard Gate, or release authority.

## Sub-task decomposition

### P3-11A Human-labeled semantic evaluation set (offline, no dependency)

- [ ] Build a blinded reviewer pack from real (non-synthetic) corpus excerpts:
      Homi Pilot states, prompt-injection testdata, and demo workspaces.
- [ ] Sanitize and bound every excerpt through `build_semantic_evidence_chunk`.
- [ ] Emit an evidence-ID mapping table so the reviewer can bind judgments
      without seeing raw payloads in any report.
- [ ] Ship a Chinese reviewer workflow doc, a submission template JSON, and a
      strict import validator producing `SemanticEvaluationCase` labels.
- [ ] Target 30～50 cases with bilingual (Chinese/English/mixed) coverage.
- Acceptance: labels are human-authored; no secret or raw excerpt is retained;
  cases are content-addressed and reproducible.

### P3-11B Semantic quality qualification gate (offline)

- [ ] Wire the imported labeled cases into `SemanticEvaluationHarness`.
- [ ] Evaluate against the offline fixture Provider first; the live Provider
      path stays injectable and offline-replayable.
- [ ] Compare harness metrics with `ProviderQualityThresholds` and emit a
      report-only qualification report (qualified / not_qualified with visible
      failure reasons).
- [ ] Include offline/live parity metrics from `SemanticParityHarness` when a
      live transport is injected in tests.
- Acceptance: thresholds failing produces `not_qualified` evidence only; every
  authority boolean stays `false`; no target execution; no raw payloads.

### P3-11C Real Provider Shadow Pilot (decision-gated)

Prerequisites (organizational, must be recorded before invocation):

```text
approved HTTPS endpoint URL
approved Provider ID and Model ID binding
credential environment-variable name (value never stored)
cost limit and attempt budget confirmation
data-residency and retention confirmation
ADR record of the approval
```

- [ ] Run `agentsec semantic trial --provider live_https --allow-live`
      with the approved binding over the labeled set.
- [ ] Archive evaluation, parity, and qualification reports.
- [ ] No automatic Provider promotion and no authority change.

## Authority boundary

```text
operating_mode          shadow_only
candidate_evidence_only true
report_only             true
blocks                  false
policy_authority        false
release_authority       false
provider_promotion_authority false
raw_payloads_retained   false
```

## Non-goals

- No LLM finding publication, Severity assignment, or gate influence.
- No mutation of Findings, Rules, Policy, or baselines.
- No network access outside the explicitly approved endpoint.
- No quality-number claims against synthetic fixtures alone.

## Verification commands

```bash
PYTHONPATH=src .venv/bin/python scripts/export_release_schemas.py
.venv/bin/python -m pytest tests/test_semantic_p3_11.py -q
./scripts/check.sh
PYTHONPATH=src .venv/bin/python scripts/verify-package-hardening.py
PYTHONPATH=src .venv/bin/python scripts/verify-reproducible-build.py
```
