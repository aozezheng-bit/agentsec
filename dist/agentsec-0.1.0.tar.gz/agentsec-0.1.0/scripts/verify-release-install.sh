#!/usr/bin/env bash

set -euo pipefail

repository_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
base_python="${PYTHON_BASE:-python3.12}"
wheel="$(find "$repository_root/dist" -maxdepth 1 -type f -name 'agentsec-0.1.0-*.whl' -print -quit)"

if [[ -z "$wheel" ]]; then
  echo "AgentSec 0.1.0 wheel not found; run scripts/build-release.sh first." >&2
  exit 2
fi

venv_dir="$(mktemp -d "${TMPDIR:-/tmp}/agentsec-release-install.XXXXXX")"
trap 'rm -rf "$venv_dir"' EXIT

"$base_python" -m venv "$venv_dir"
"$venv_dir/bin/python" -m pip install "$wheel"
"$venv_dir/bin/agentsec" version
"$venv_dir/bin/agentsec" rules list >/dev/null
"$venv_dir/bin/agentsec" scan \
  "$repository_root/testdata/safe/minimal-agent" \
  --format json \
  > "$venv_dir/safe-scan.json"
"$venv_dir/bin/python" - <<PY
import json
from pathlib import Path
payload = json.loads(Path("$venv_dir/safe-scan.json").read_text(encoding="utf-8"))
assert payload["format"] == "agentsec-assessment"
assert payload["status"] == "complete"
assert payload["summary"]["findings"] == 0
print("Non-editable wheel installation verified")
PY
