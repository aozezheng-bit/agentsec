#!/usr/bin/env bash

set -euo pipefail

repository_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
python_executable="${PYTHON:-$repository_root/.venv/bin/python}"
dist_dir="$repository_root/dist"

if [[ ! -x "$python_executable" ]]; then
  echo "Python executable not found: $python_executable" >&2
  exit 2
fi

mkdir -p "$dist_dir"
find "$dist_dir" -maxdepth 1 -type f \
  \( -name 'agentsec-*.whl' -o -name 'agentsec-*.tar.gz' -o -name 'SHA256SUMS' \) \
  -delete

cd "$repository_root"
"$python_executable" -m pip wheel . \
  --no-deps \
  --no-build-isolation \
  --wheel-dir "$dist_dir"

PYTHONPATH="$repository_root/src" "$python_executable" - <<'PY'
from pathlib import Path
from setuptools import build_meta

repository_root = Path.cwd()
filename = build_meta.build_sdist(str(repository_root / "dist"))
print(f"Built {filename}")
PY

"$python_executable" - <<'PY'
from __future__ import annotations

import hashlib
import tarfile
import zipfile
from pathlib import Path

root = Path.cwd()
dist_dir = root / "dist"
artifacts = sorted(
    path
    for path in dist_dir.iterdir()
    if path.is_file() and path.name != "SHA256SUMS"
)
if len([path for path in artifacts if path.suffix == ".whl"]) != 1:
    raise SystemExit("release build must produce exactly one wheel")
if len([path for path in artifacts if path.name.endswith(".tar.gz")]) != 1:
    raise SystemExit("release build must produce exactly one sdist")

wheel = next(path for path in artifacts if path.suffix == ".whl")
with zipfile.ZipFile(wheel) as archive:
    names = set(archive.namelist())
    required = {
        "agentsec/__init__.py",
        "agentsec/cli/app.py",
        "agentsec/cli/rules.py",
    }
    if not required <= names:
        raise SystemExit("wheel is missing required package files")
    metadata_name = next(name for name in names if name.endswith(".dist-info/METADATA"))
    entry_name = next(name for name in names if name.endswith(".dist-info/entry_points.txt"))
    metadata = archive.read(metadata_name).decode("utf-8")
    entry_points = archive.read(entry_name).decode("utf-8")
    if "Version: 0.1.0" not in metadata:
        raise SystemExit("wheel metadata version is not 0.1.0")
    if "agentsec = agentsec.cli:main" not in entry_points:
        raise SystemExit("wheel console script is missing")

sdist = next(path for path in artifacts if path.name.endswith(".tar.gz"))
with tarfile.open(sdist, "r:gz") as archive:
    names = set(archive.getnames())
    required_suffixes = {
        "LICENSE",
        "README.md",
        "CHANGELOG.md",
        "docs/releases/0.1.0.md",
        "schemas/assessment/assessment-report.schema.json",
        "demos/release-agent/expected/risky-findings.json",
    }
    for suffix in required_suffixes:
        if not any(name.endswith(suffix) for name in names):
            raise SystemExit(f"sdist is missing {suffix}")

lines = []
for path in artifacts:
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    lines.append(f"{digest}  {path.name}")
(dist_dir / "SHA256SUMS").write_text("\n".join(lines) + "\n", encoding="utf-8")
for line in lines:
    print(line)
PY
