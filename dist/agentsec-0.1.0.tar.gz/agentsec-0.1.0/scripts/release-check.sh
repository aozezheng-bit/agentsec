#!/usr/bin/env bash

set -euo pipefail

repository_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
python_executable="${PYTHON:-$repository_root/.venv/bin/python}"

cd "$repository_root"
"$repository_root/scripts/check.sh"
PYTHONPATH="$repository_root/src" "$python_executable" \
  "$repository_root/scripts/export_release_schemas.py"
"$python_executable" -m pytest \
  tests/test_release_artifacts.py \
  tests/test_rules_cli.py \
  tests/test_poc_documentation.py
"$repository_root/scripts/run-demo.sh" >/tmp/agentsec-release-demo.log
cat /tmp/agentsec-release-demo.log
"$repository_root/scripts/build-release.sh"

echo "Offline release checks passed."
echo "Run scripts/verify-release-install.sh for dependency-resolving wheel install verification."
