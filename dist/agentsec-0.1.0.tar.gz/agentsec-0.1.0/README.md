# AgentSec

AgentSec is a **Phase 1 proof-of-concept CLI** for evidence-backed security
analysis of Agent instruction assets.

It discovers supported Markdown control files, parses them without execution,
runs 15 deterministic security rules, assigns preliminary risk and Evidence
Confidence, and produces secret-redacted Text or versioned JSON reports.

> AgentSec reports security-relevant declarations. It does not prove runtime
> exploitability or claim that an Agent is globally safe.

## Current status

Phase 1 completed through **P1-31** and released locally on 2026-08-19:

```text
Markdown discovery and safe parsing
→ Baseline and bounded Text Diff
→ 15 deterministic Rules
→ NIST-style Risk and A/B/C/D Evidence Confidence
→ Report-Only Hard Gate stage
→ Rich Text and versioned JSON reports
→ Hardened secret redaction and Coverage reporting
→ 40-Case corpus and full CLI integration regression
→ README and PoC usage guide
→ Frozen Schemas, accepted Demo, wheel/sdist release artifacts
```

Current package version:

```text
0.1.0
```

Final local release verification:

```text
Ruff / Ruff Format / Mypy: passed
Pytest: 563 passed
Release Agent Demo E2E: passed
Non-editable wheel installation: passed
```

## Requirements

- Python 3.12 or newer;
- a local source checkout of this repository;
- Git is optional and is used only for local Baseline provenance when available.

AgentSec does not require an LLM, model API key, MCP connection, or network
service.

## Install from the source checkout

### macOS or Linux

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install --editable .
agentsec version
```

Expected output:

```text
agentsec 0.1.0
```

### Windows PowerShell

```powershell
py -3.12 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --editable .
agentsec version
```

Without installation, a source-checkout smoke test is also available:

```bash
PYTHONPATH=src python3.12 -m agentsec version
```

## Five-minute quick start

### 1. Scan a safe example

From the repository root:

```bash
agentsec scan testdata/safe/minimal-agent
```

Expected outcome:

```text
Status: COMPLETE
Assets: 1
Findings: 0
Exit code: 0
```

Zero Findings means only that no current deterministic Rule matched within the
supported scope. It is not a global safety guarantee.

### 2. Scan a risky example

```bash
agentsec scan testdata/risky/shell-secret-network
```

This Case produces four Findings covering:

```text
shell execution
secret or environment access
external network transmission
removed human confirmation
```

The highest current Severity is High. The command still returns exit code `0`
because Phase 1 is report-only and does not block CI based on Findings.

### 3. Produce machine-readable JSON

```bash
agentsec scan testdata/risky/shell-secret-network \
  --format json \
  > assessment.json
```

The output format is:

```text
format = agentsec-assessment
format_version = 0.2.0
```

The JSON explicitly records:

```text
enforcement_mode = report_only
ci_blocking_enabled = false
global_safety_claimed = false
```

### 4. Observe incomplete Coverage

```bash
agentsec scan testdata/malformed/invalid-utf8 --format json
```

Expected outcome:

```text
status = incomplete
coverage issue = unsupported_encoding
exit code = 2
```

Incomplete Coverage is a partial result and must not be treated as a clean pass.

## Scan your own project

```bash
agentsec scan /path/to/project
agentsec scan /path/to/project --format text
agentsec scan /path/to/project --format json
agentsec scan /path/to/project --config /path/to/config.yaml
```

Phase 1 automatically discovers these exact filenames recursively:

```text
AGENTS.md
AGENTS.override.md
SKILL.md
```

Additional lowercase `.md` files can be explicitly included through project
configuration.

## Inspect the built-in Rule Pack

```bash
agentsec rules list
```

The command lists all 15 stable Rule IDs, categories, and titles from Rule Pack
`0.2.0`. It reads trusted packaged metadata and does not scan a project.

## Minimal project configuration

Create `<project-root>/.agentsec/config.yaml`:

```yaml
version: "0.1.0"

discovery:
  include:
    - AGENTS.md
    - AGENTS.override.md
    - SKILL.md
    - "**/AGENTS.md"
    - "**/AGENTS.override.md"
    - "**/SKILL.md"
  exclude:
    - ".git/**"
    - ".venv/**"
    - "node_modules/**"
    - "dist/**"
    - "build/**"

limits:
  max_file_size_bytes: 1048576
  max_depth: 20
  max_assets: 1000

output:
  format: text
  redact_secrets: true
```

Configuration precedence is:

```text
explicit --config
→ <project-root>/.agentsec/config.yaml
→ secure built-in defaults
```

Output format precedence for `scan` and `diff` is:

```text
--format text|json
→ config output.format
→ text
```

Secret redaction cannot be disabled in Phase 1.

## Baseline and Diff workflow

Create a trusted local snapshot only after reviewing the current Agent assets:

```bash
agentsec baseline create /path/to/project
```

The default output is:

```text
/path/to/project/.agentsec/baseline.json
```

After the Agent files change, compare them with the snapshot:

```bash
agentsec diff /path/to/project
agentsec diff /path/to/project --format json
```

Use an explicit Baseline location when required:

```bash
agentsec baseline create /path/to/project \
  --output /trusted/location/baseline.json

agentsec diff /path/to/project \
  --baseline /trusted/location/baseline.json
```

Important distinctions:

- `scan` reports current deterministic security Findings;
- `baseline create` captures exact bounded UTF-8 content and metadata;
- `diff` reports textual drift and does not assign risk by itself;
- a Baseline is sensitive plaintext and is not an approval signature;
- changed files alone do not cause a nonzero risk-policy exit.

## How to read a Finding

| Field | Meaning |
|---|---|
| Rule | Stable deterministic detection identity |
| Category | Type of declared security-relevant behavior |
| Likelihood | Preliminary NIST-style likelihood profile |
| Impact | Highest reviewed impact dimension; not an average |
| Score | Preliminary AgentSec 0–10 mapping |
| Severity | Risk magnitude derived from the current Risk Model |
| Confidence | Strength of available Evidence, independent from Severity |
| Hard Gate | Whether a deterministic risk floor matched; report-only in Phase 1 |
| Evidence | Project-relative file, line range, hash, field, and safe excerpt |
| Recommendations | Reviewed follow-up actions |

All 15 Markdown Rules currently use static source evidence and therefore report
Confidence `D`. A High/D Finding remains High: weak evidence confidence does not
lower or erase possible impact.

## Coverage is separate from risk

Coverage answers whether the selected input was successfully evaluated.
Findings answer which deterministic Rules matched.

```text
COMPLETE + Findings     → analysis completed and signals were found
COMPLETE + no Findings  → no current Rule matched; not a safety guarantee
INCOMPLETE              → partial result; review every Coverage Issue
```

Coverage problems include invalid UTF-8, unreadable or oversized files, unsafe
paths, traversal limits, parser failures, and isolated Rule failures.

## Exit codes

| Code | Meaning |
|---:|---|
| `0` | Command succeeded; Findings remain report-only |
| `1` | Reserved for a future enforcing risk threshold; not produced in Phase 1 |
| `2` | Scan or Diff Coverage is incomplete |
| `3` | Project configuration is invalid or incompatible |
| `4` | Baseline is missing, invalid, incompatible, or unsafe |
| `5` | A required analysis stage failed safely |
| `64` | Invalid CLI syntax through the installed/module entry point |

Automation must use exit codes and JSON fields rather than parsing Rich Text.

## Security boundaries

AgentSec:

- never executes scanned code blocks, scripts, Hooks, Skills, commands, or tools;
- never connects to an MCP server declared by scanned content;
- performs no external network access by default;
- does not interpolate scanned text into shell commands;
- does not follow a symbolic link outside the selected root by default;
- bounds file size, traversal depth, asset count, matching, Diff, and Text output;
- redacts recognized secrets before escaping control characters;
- makes incomplete Coverage visible;
- requires direct Evidence for every final Finding;
- keeps Severity, Confidence, Hard Gate state, and CI policy separate.

## Current limitations

Phase 1 does not provide:

- general TOML, YAML, JSON, plugin, or MCP-manifest parsing;
- effective capability or permission resolution;
- runtime identity, OAuth-scope, or tool availability verification;
- semantic Diff or LLM analysis;
- production Hard Gate combination detectors;
- `--fail-on`, CI blocking, waivers, or automatic remediation;
- SARIF, HTML, or a Web console;
- financial-loss estimates or a global safety verdict;

## Release artifacts and full PoC guide

The local release includes:

- frozen Schemas under [`schemas/`](schemas/README.md);
- Release Agent Demo under [`demos/release-agent/`](demos/release-agent/README.md);
- [0.1.0 release notes](docs/releases/0.1.0.md);
- [known limitations](docs/releases/0.1.0-known-limitations.md);
- [release acceptance record](docs/releases/0.1.0-acceptance.md);
- wheel, sdist, and SHA-256 files under `dist/`.

Rebuild and verify the local artifacts with:

```bash
scripts/build-release.sh
scripts/verify-release-install.sh
```

See [`docs/poc-usage.md`](docs/poc-usage.md) for:

- a complete first-run walkthrough;
- Safe, Risky, Prompt Injection, and Malformed examples;
- Text and JSON interpretation;
- Python JSON validation;
- Baseline lifecycle and Diff review;
- automation patterns;
- troubleshooting and residual risks.

## Development setup

Install the development dependencies:

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install --editable '.[dev]'
```

Run the complete local/CI quality gate:

```bash
scripts/check.sh
```

The gate runs Ruff linting, Ruff formatting verification, strict Mypy, and
Pytest. A different Python 3.12 executable can be selected with:

```bash
PYTHON=/path/to/python scripts/check.sh
```

## Documentation map

### Start here

- [PoC usage guide](docs/poc-usage.md)
- [Phase 1 scope](docs/scope.md)
- [Project configuration](docs/configuration.md)
- [CLI integration](docs/cli-integration.md)
- [Exit codes](docs/exit-codes.md)

### Reports and security interpretation

- [Assessment Text report](docs/assessment-text-report.md)
- [Assessment JSON report](docs/assessment-json-report.md)
- [Coverage reporting](docs/coverage-report.md)
- [Risk Model](docs/risk-model.md)
- [Evidence Confidence](docs/confidence-model.md)
- [Hard Gate semantics](docs/hard-gate.md)
- [Secret redaction](docs/secret-redaction.md)

### Collection, Baseline, and Diff

- [Path safety](docs/path-safety.md)
- [Resource limits](docs/resource-limits.md)
- [Markdown parser](docs/markdown-parser.md)
- [Baseline creation](docs/baseline-create.md)
- [Baseline Schema](docs/baseline-schema.md)
- [Asset Diff](docs/asset-diff.md)
- [Text Diff](docs/text-diff.md)
- [Diff CLI](docs/diff-cli.md)

### Rules, tests, and project governance

- [Rule Pack](docs/rule-pack.md)
- [Rule pipeline](docs/rule-pipeline.md)
- [Test corpus](docs/test-corpus.md)
- [Threat model](docs/threat-model.md)
- [Versioning](docs/versioning.md)
- [Developer and management Demo plan](docs/demo-plan.md)
- [Domain glossary](CONTEXT.md)

## Release status

AgentSec 0.1.0 is accepted as a **local Phase 1 PoC release**. This workspace is
not a Git repository and has no configured remote publication target, so no Git
tag, commit, PR, package-index upload, or remote Release object is claimed.

Future work starts from the Phase 2 structured capability-profile plan; it must
not weaken the 0.1.0 report-only and non-execution boundaries.
