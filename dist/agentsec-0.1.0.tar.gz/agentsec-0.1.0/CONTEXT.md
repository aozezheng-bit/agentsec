# AgentSec Domain Glossary

## Finding

An independently actionable, evidence-backed security result produced from one
stable detection meaning.

## Severity

The potential harm level of a Finding. Severity is independent from Evidence
Confidence and may be raised by a Hard Gate floor.

## Evidence Confidence

The strength of evidence supporting a Finding. Confidence never lowers Severity
and never disables a Hard Gate.

## Hard Gate

A deterministic policy condition that establishes a minimum risk level which
cannot be reduced by averaging or lower-scored signals. A matched Hard Gate is
metadata about the Finding; it is not itself a CI enforcement decision.

## Hard Gate Floor

The minimum High or Critical risk level established by a matched Hard Gate.
The effective risk is the greater of the base risk and the floor.

## Triggered Hard Gate

A Hard Gate with at least one matched deterministic condition. Triggered status
is independent from whether an external policy engine blocks delivery.

## Report-Only

A policy mode that records and applies Hard Gate metadata to the reported risk
but does not block CI or change process exit policy.
