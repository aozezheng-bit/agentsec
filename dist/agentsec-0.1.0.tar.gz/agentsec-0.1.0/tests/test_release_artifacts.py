"""P1-31 release, Schema, and frozen Demo acceptance tests."""

from __future__ import annotations

import hashlib
import json
import re
import subprocess
from pathlib import Path

from agentsec.baselines import (
    decode_baseline_json,
    export_baseline_json_schema,
)
from agentsec.domain import export_json_schemas
from agentsec.reporting import (
    AssessmentJsonReport,
    SecretRedactor,
    export_assessment_json_schema,
)
from agentsec.versioning import PACKAGE_VERSION

REPOSITORY_ROOT = Path(__file__).parents[1]
SCHEMA_ROOT = REPOSITORY_ROOT / "schemas"
DEMO_ROOT = REPOSITORY_ROOT / "demos" / "release-agent"
RELEASE_ROOT = REPOSITORY_ROOT / "docs" / "releases"
URL_HOST_PATTERN = re.compile(r"https?://([^/\s`]+)", re.IGNORECASE)


def test_package_is_the_final_phase_one_poc_release() -> None:
    """P1-31 removes the unreleased development suffix."""

    assert PACKAGE_VERSION == "0.1.0"


def test_frozen_release_schemas_match_current_exporters(tmp_path: Path) -> None:
    """Published Schemas are byte-identical to current source-of-truth models."""

    domain_dir = tmp_path / "domain"
    baseline_dir = tmp_path / "baseline"
    assessment_dir = tmp_path / "assessment"
    domain_paths = export_json_schemas(domain_dir)
    baseline_path = export_baseline_json_schema(baseline_dir)
    assessment_path = export_assessment_json_schema(assessment_dir)

    for generated in domain_paths:
        assert (
            generated.read_bytes()
            == (SCHEMA_ROOT / "domain" / generated.name).read_bytes()
        )
    assert (
        baseline_path.read_bytes()
        == (SCHEMA_ROOT / "baseline" / baseline_path.name).read_bytes()
    )
    assert (
        assessment_path.read_bytes()
        == (SCHEMA_ROOT / "assessment" / assessment_path.name).read_bytes()
    )


def test_frozen_demo_reports_are_valid_and_match_the_story() -> None:
    """Offline fallback output retains the approved report-only semantics."""

    expected = DEMO_ROOT / "expected"
    baseline = AssessmentJsonReport.model_validate_json(
        (expected / "baseline-scan.json").read_text(encoding="utf-8")
    )
    risky = AssessmentJsonReport.model_validate_json(
        (expected / "risky-findings.json").read_text(encoding="utf-8")
    )
    injection = AssessmentJsonReport.model_validate_json(
        (expected / "injection-findings.json").read_text(encoding="utf-8")
    )
    malformed = AssessmentJsonReport.model_validate_json(
        (expected / "malformed-scan.json").read_text(encoding="utf-8")
    )
    remediated = AssessmentJsonReport.model_validate_json(
        (expected / "remediated-scan.json").read_text(encoding="utf-8")
    )

    assert baseline.status == "complete"
    assert baseline.summary.findings == 0
    assert risky.status == "complete"
    assert risky.summary.findings == 10
    assert risky.summary.highest_severity.value == "high"
    assert sorted({item.rule_id for item in risky.assessment.findings}) == [
        "MD-APPROVAL-001",
        "MD-DEPLOY-001",
        "MD-EXEC-001",
        "MD-INSTR-001",
        "MD-INSTR-002",
        "MD-NET-001",
        "MD-PRIV-001",
        "MD-SECRET-001",
        "MD-TOOL-001",
    ]
    assert injection.status == "complete"
    assert [item.rule_id for item in injection.assessment.findings] == [
        "MD-INSTR-001",
        "MD-INSTR-002",
    ]
    assert malformed.status == "incomplete"
    assert malformed.assessment.coverage.issues[0].code.value == (
        "unsupported_encoding"
    )
    assert remediated.status == "complete"
    assert remediated.summary.findings == 0
    for report in (baseline, risky, injection, malformed, remediated):
        assert report.policy.enforcement_mode == "report_only"
        assert report.policy.ci_blocking_enabled is False
        assert report.policy.global_safety_claimed is False


def test_frozen_demo_baseline_and_diff_are_valid() -> None:
    """The approved Baseline and redacted Diff remain replayable release assets."""

    expected = DEMO_ROOT / "expected"
    baseline = decode_baseline_json(
        (expected / "baseline.json").read_text(encoding="utf-8")
    )
    diff = json.loads((expected / "risky-diff.json").read_text(encoding="utf-8"))

    assert len(baseline.assets) == 2
    assert diff["format"] == "agentsec-diff"
    assert diff["format_version"] == "0.1.0"
    assert diff["status"] == "complete"
    assert diff["summary"] == {
        "added": 0,
        "changes": 2,
        "modified": 2,
        "omitted_text_diff_assets": 0,
        "removed": 0,
        "text_diff_complete": True,
    }


def test_demo_assets_are_inert_secret_free_and_use_reserved_hosts() -> None:
    """The narrative Demo cannot introduce executable payloads or real secrets."""

    redactor = SecretRedactor()
    allowed_suffixes = {".md", ".json", ".sha256"}
    for path in DEMO_ROOT.rglob("*"):
        assert not path.is_symlink(), path
        if not path.is_file():
            continue
        assert path.suffix.lower() in allowed_suffixes, path
        if path == DEMO_ROOT / "malformed" / "AGENTS.md":
            continue
        text = path.read_text(encoding="utf-8")
        assert redactor.redact(text) == text, path
        for host in URL_HOST_PATTERN.findall(text):
            assert host.lower().endswith(".invalid"), path


def test_frozen_demo_checksums_match_every_expected_artifact() -> None:
    """Offline fallback files cannot drift silently after acceptance."""

    expected_dir = DEMO_ROOT / "expected"
    checksum_path = expected_dir / "checksums.sha256"
    entries = {}
    for line in checksum_path.read_text(encoding="utf-8").splitlines():
        digest, filename = line.split("  ", maxsplit=1)
        entries[filename] = digest

    artifact_names = sorted(
        path.name
        for path in expected_dir.iterdir()
        if path.is_file() and path.name != checksum_path.name
    )
    assert sorted(entries) == artifact_names
    for filename, expected_digest in entries.items():
        actual = hashlib.sha256((expected_dir / filename).read_bytes()).hexdigest()
        assert actual == expected_digest


def test_release_documents_record_acceptance_and_limitations() -> None:
    """The PoC release is explicit about policy and residual risk."""

    required = (
        REPOSITORY_ROOT / "CHANGELOG.md",
        RELEASE_ROOT / "0.1.0.md",
        RELEASE_ROOT / "0.1.0-known-limitations.md",
        RELEASE_ROOT / "0.1.0-acceptance.md",
        DEMO_ROOT / "README.md",
        DEMO_ROOT / "demo-script.md",
        DEMO_ROOT / "acceptance.md",
    )
    for path in required:
        assert path.is_file(), path

    combined = "\n".join(path.read_text(encoding="utf-8") for path in required)
    assert "report-only" in combined.lower()
    assert "ci_blocking_enabled=false" in combined
    assert "agentsec rules list" in combined
    assert "does not prove" in combined.lower()
    assert "--fail-on high" not in combined


def test_release_demo_runner_passes_end_to_end(tmp_path: Path) -> None:
    """The accepted Demo runner uses the real CLI and validates its live output."""

    output_dir = tmp_path / "demo-output"
    result = subprocess.run(
        [str(REPOSITORY_ROOT / "scripts" / "run-demo.sh"), str(output_dir)],
        check=False,
        capture_output=True,
        text=True,
        timeout=30,
    )

    assert result.returncode == 0
    assert "Release Agent Demo validation passed" in result.stdout
    assert "ci_blocking_enabled=false" in result.stdout
    assert result.stderr == ""
    assert (output_dir / "risky-findings.json").is_file()
    assert (output_dir / "malformed-scan.json").is_file()
