"""Tests for AgentSec version sources and compatibility policy."""

from __future__ import annotations

from importlib.metadata import version

import pytest

import agentsec
from agentsec.versioning import (
    ASSESSMENT_OUTPUT_VERSION,
    BASELINE_SCHEMA_VERSION,
    CONFIG_SCHEMA_VERSION,
    DIFF_OUTPUT_VERSION,
    DOMAIN_SCHEMA_VERSION,
    PACKAGE_VERSION,
    RISK_MODEL_VERSION,
    RULE_PACK_VERSION,
    InterfaceVersion,
    can_read_interface_version,
    current_versions,
    parse_interface_version,
)


def test_package_metadata_uses_the_central_version() -> None:
    """Source, import, and installed distribution versions do not drift."""

    assert agentsec.__version__ == PACKAGE_VERSION
    assert version("agentsec") == PACKAGE_VERSION


def test_current_versions_returns_the_complete_vector() -> None:
    """Reports can capture all independently evolving identifiers."""

    versions = current_versions()

    assert versions.package == PACKAGE_VERSION
    assert versions.config_schema == CONFIG_SCHEMA_VERSION
    assert versions.domain_schema == DOMAIN_SCHEMA_VERSION
    assert versions.baseline_schema == BASELINE_SCHEMA_VERSION
    assert versions.diff_output == DIFF_OUTPUT_VERSION
    assert versions.assessment_output == ASSESSMENT_OUTPUT_VERSION
    assert ASSESSMENT_OUTPUT_VERSION == "0.2.0"
    assert versions.rule_pack == RULE_PACK_VERSION
    assert RULE_PACK_VERSION == "0.2.0"
    assert versions.risk_model == RISK_MODEL_VERSION
    assert RISK_MODEL_VERSION == "0.4.0"


def test_parse_interface_version_requires_exact_semver() -> None:
    """Serialized interfaces reject ambiguous or package-style versions."""

    assert parse_interface_version("1.2.3") == InterfaceVersion(1, 2, 3)

    for invalid in ("1", "1.2", "01.2.3", "1.2.3.dev0", "v1.2.3"):
        with pytest.raises(ValueError):
            parse_interface_version(invalid)


@pytest.mark.parametrize(
    ("produced", "supported", "expected"),
    [
        ("0.1.0", "0.1.5", True),
        ("0.1.9", "0.2.0", False),
        ("0.2.0", "0.1.9", False),
        ("1.1.0", "1.3.0", True),
        ("1.4.0", "1.3.9", False),
        ("1.0.0", "2.0.0", False),
    ],
)
def test_interface_compatibility_policy(
    produced: str, supported: str, expected: bool
) -> None:
    """Compatibility follows the documented pre-1.0 and stable rules."""

    assert (
        can_read_interface_version(produced=produced, supported=supported) is expected
    )
