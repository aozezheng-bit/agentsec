# AgentSec 0.1.0 Frozen JSON Schemas

These files are generated from the P1-31 release source of truth:

```bash
PYTHONPATH=src python3.12 scripts/export_release_schemas.py
```

Layout:

```text
schemas/domain/       Public Domain models, Domain Schema 0.3.0
schemas/baseline/     Baseline Schema 0.1.0
schemas/assessment/   Assessment Output 0.2.0
```

The Diff JSON contract remains documented and versioned as Diff Output 0.1.0,
but the current implementation does not expose an independent Diff JSON Schema
exporter.

Consumers must verify the appropriate format/schema version before interpreting
security-significant fields.
