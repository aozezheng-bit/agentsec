"""CLI delivery for the reviewed deterministic Rule Pack inventory."""

from __future__ import annotations

import typer

from agentsec.rules import builtin_markdown_rules
from agentsec.versioning import RULE_PACK_VERSION


def register_rules_commands(application: typer.Typer) -> None:
    """Register the required Phase 1 `rules list` command group."""

    rules_application = typer.Typer(
        help="Inspect the built-in deterministic security Rule Pack.",
        add_completion=False,
        no_args_is_help=True,
        rich_markup_mode="rich",
        context_settings={"help_option_names": ["-h", "--help"]},
    )

    @rules_application.command("list")
    def list_rules() -> None:
        """List stable Rule IDs, categories, and titles."""

        rules = builtin_markdown_rules()
        typer.echo(
            f"Rule Pack {RULE_PACK_VERSION}: {len(rules)} deterministic Markdown rules"
        )
        typer.echo("RULE_ID\tCATEGORY\tTITLE")
        for rule in rules:
            metadata = rule.metadata
            typer.echo(
                f"{metadata.rule_id}\t{metadata.category.value}\t{metadata.title}"
            )

    application.add_typer(rules_application, name="rules")
