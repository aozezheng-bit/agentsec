"""Stable process exit codes for AgentSec CLI automation."""

from __future__ import annotations

from enum import IntEnum

from agentsec.application import ProjectDiffResult
from agentsec.domain import Assessment


class ExitCode(IntEnum):
    """Documented outcomes returned by the installed AgentSec command."""

    SUCCESS = 0
    RISK_THRESHOLD_EXCEEDED = 1
    SCAN_INCOMPLETE = 2
    CONFIGURATION_ERROR = 3
    BASELINE_ERROR = 4
    REQUIRED_ANALYSIS_FAILED = 5
    USAGE_ERROR = 64


def exit_code_for_assessment(assessment: Assessment) -> ExitCode:
    """Map current Phase 1 assessment completeness to a process outcome.

    Risk-threshold decisions are introduced by the later policy task. Until
    then, a complete assessment succeeds even if it contains findings.
    """

    if not assessment.coverage.complete:
        return ExitCode.SCAN_INCOMPLETE
    return ExitCode.SUCCESS


def exit_code_for_project_diff(result: ProjectDiffResult) -> ExitCode:
    """Map Diff comparability and evidence completeness to stable outcomes."""

    if not result.asset_diff.collection_config_matches:
        return ExitCode.BASELINE_ERROR
    if not result.text_diff.complete:
        return ExitCode.SCAN_INCOMPLETE
    return ExitCode.SUCCESS
