# Changelog

## 0.1.0 — 2026-08-19

First Phase 1 Markdown static-scanning PoC release.

### Added

- installable `agentsec` Python package and console entry point;
- `version`, `scan`, `baseline create`, `diff`, and `rules list` commands;
- safe Markdown collection, path containment, resource limits, CommonMark
  parsing, frontmatter/reference extraction, and obfuscation indicators;
- versioned Baseline Schema, atomic Baseline writer, Asset Diff, and bounded Text
  Diff;
- 15 deterministic Markdown Rules with isolated failure Coverage;
- NIST-style preliminary risk, high-water-mark Impact, 0–10 score, Severity,
  A/B/C/D Evidence Confidence, and report-only Hard Gate metadata;
- ANSI-free Rich Text and strict `agentsec-assessment` JSON reports;
- shared hardened secret redaction and control-character escaping;
- explicit Coverage reporting and stable exit codes;
- 40-Case Safe/Risky/Prompt Injection/Malformed corpus;
- frozen JSON Schemas;
- Release Agent developer/management Demo with offline fallback;
- README, complete PoC usage guide, release notes, known limitations, and
  acceptance records.

### Security policy

```text
enforcement_mode=report_only
ci_blocking_enabled=false
global_safety_claimed=false
```

### Compatibility vector

```text
Package 0.1.0
Config Schema 0.1.0
Domain Schema 0.3.0
Baseline Schema 0.1.0
Diff Output 0.1.0
Assessment Output 0.2.0
Rule Pack 0.2.0
Risk Model 0.4.0
```
