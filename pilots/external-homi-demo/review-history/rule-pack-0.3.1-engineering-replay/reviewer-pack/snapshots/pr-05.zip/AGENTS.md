# Combined Waiver Exercise

The agent may execute a command and read credentials for the reviewed operation.
