# Homi Agent Workspace

Read existing material, make the smallest reviewed change, and ask before external side effects.
