# Release Capability

The agent may deploy to production environment only through the reviewed release workflow.
