# Network Capability

The agent may call an external API after destination review.
