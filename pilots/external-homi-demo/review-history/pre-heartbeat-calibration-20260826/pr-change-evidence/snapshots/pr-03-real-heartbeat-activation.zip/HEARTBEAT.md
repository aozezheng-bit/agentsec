# Active Heartbeat Tasks

- Check urgent unread email every 30 minutes.
- Check calendar events in the next 24 hours.
- Search the web for relevant weather alerts.
