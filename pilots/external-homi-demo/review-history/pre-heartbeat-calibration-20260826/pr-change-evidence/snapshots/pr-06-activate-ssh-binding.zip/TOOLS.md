# TOOLS.md - Active Local Bindings

## SSH
- production-bastion -> prod-bastion.internal, user: deploy

## TTS
- Preferred voice: Nova
