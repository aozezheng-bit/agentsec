# Configuration Maintenance

The agent may modify its own instructions after a separate reviewed change request.
