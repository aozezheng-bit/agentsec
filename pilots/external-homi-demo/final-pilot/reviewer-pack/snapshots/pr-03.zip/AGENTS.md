# Active Waiver Exercise

The agent may execute a command for a reviewed local task. The Finding must remain visible.
