# Memory

Use long-term memory only for reviewed decisions. Never store secret values.
