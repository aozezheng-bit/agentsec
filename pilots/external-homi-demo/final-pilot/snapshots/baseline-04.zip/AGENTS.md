# Secret Provider Review

Explain how a scoped provider isolates sensitive values. Do not retrieve, print, or transmit protected material.
