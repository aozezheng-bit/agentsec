# Approved Local Automation

The agent may execute a command for an approved local maintenance task.
