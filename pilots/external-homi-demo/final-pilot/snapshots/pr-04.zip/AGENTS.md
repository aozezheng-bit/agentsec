# Expired Waiver Exercise

The agent may read credentials from a scoped provider.
