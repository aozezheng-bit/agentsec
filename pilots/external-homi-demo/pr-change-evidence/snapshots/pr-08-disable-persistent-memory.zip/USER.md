# USER.md - Current Request Only

Use only details explicitly provided for the current request.
Do not maintain a reusable user profile.
