# TOOLS.md - Active Service Bindings

## MCP
- internal-ops-mcp -> configured by the platform

## OAuth
- deployment-service -> scope: release.write

## Credential Alias
- deployment-token -> managed secret reference; value not stored here
